/* spacegroup_type.h */
/* Copyright (C) 2010 Atsushi Togo */

#ifndef __spacegroup_H__
#define __spacegroup_H__

#include "lattice.h"
#include "cell.h"
#include "symmetry.h"
#include "mathfunc.h"

typedef struct {
  int number;
  char schoenflies[7];
  char hall_symbol[17];
  char international[32];
  char international_long[20];
  char international_short[11];
  double bravais_lattice[3][3];
} Spacegroup;

Spacegroup spa_get_spacegroup( SPGCONST Cell * cell,
			       const double symprec );
Symmetry * spa_get_conventional_symmetry( SPGCONST double transform_mat[3][3],
					  const Centering centering,
					  const Symmetry *primitive_sym,
					  const double symprec );
#endif
