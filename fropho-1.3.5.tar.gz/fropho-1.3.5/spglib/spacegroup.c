/* spacegroup.c */
/* Copyright (C) 2010 Atsushi Togo */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "spacegroup.h"
#include "spg_database.h"
#include "cell.h"
#include "lattice.h"
#include "mathfunc.h"
#include "pointgroup.h"
#include "primitive.h"
#include "symmetry.h"
#include "hall_symbol.h"

#include "debug.h"

static Spacegroup get_spacegroup( SPGCONST Cell * cell,
				  const double symprec );
static SpacegroupType get_spacegroup_type( SPGCONST double trans_mat[3][3],
					   const Centering centering,
					   const Symmetry * symmetry,
					   const double symprec );
static Centering get_transformation_matrix( double trans_mat[3][3],
					    Symmetry * symmetry,
					    const double symprec );
static Cell * get_primitive( SPGCONST Cell * cell,
			     const double symprec );
static Symmetry * get_conventional_symmetry( SPGCONST double transform_mat[3][3],
					     const Centering centering,
					     const Symmetry *primitive_sym,
					     const double symprec );

Spacegroup spa_get_spacegroup( SPGCONST Cell * cell,
			       const double symprec )
{
  return get_spacegroup( cell, symprec );
}

Symmetry * spa_get_conventional_symmetry( SPGCONST double transform_mat[3][3],
					  const Centering centering,
					  const Symmetry *primitive_sym,
					  const double symprec )
{
  return get_conventional_symmetry( transform_mat,
				    centering,
				    primitive_sym,
				    symprec );
}

static Spacegroup get_spacegroup( SPGCONST Cell * cell,
				  const double symprec )
{
  double trans_mat[3][3],conv_lattice[3][3];
  Centering centering;
  Cell * primitive;
  Symmetry *symmetry;
  Spacegroup spacegroup;
  SpacegroupType spacegroup_type;

  primitive = get_primitive( cell, symprec );
  symmetry = sym_get_operation_direct( primitive, symprec );
  centering = get_transformation_matrix( trans_mat, symmetry, symprec );
  mat_multiply_matrix_d3( conv_lattice, primitive->lattice, trans_mat );

#ifdef DEBUG
  int i;
  printf("Input structure\n");
  printf("lattice:\n");
  debug_print_matrix_d3( cell->lattice );
  debug_print("Metric tensor:\n");
  double metric[3][3];
  mat_get_metric( metric, cell->lattice );
  debug_print_matrix_d3( metric );
  printf("positions:\n");
  for ( i = 0; i < cell->size; i++ ) {
    printf("%f %f %f\n",
	   cell->position[i][0],
	   cell->position[i][1],
	   cell->position[i][2]);
  }
  double tmp_lattice[3][3];
  debug_print("transformation matrix\n");
  debug_print_matrix_d3( trans_mat );
  debug_print("transformed lattice after correction\n");
  debug_print_matrix_d3( conv_lattice );
  debug_print("metric tensor\n");
  mat_get_metric( tmp_lattice, conv_lattice );
  debug_print_matrix_d3( tmp_lattice );
#endif

  spacegroup_type = get_spacegroup_type( trans_mat, centering,
					 symmetry, symprec );

  cel_free_cell( primitive );
  sym_free_symmetry( symmetry );
  
  if ( spacegroup_type.number > 0 ) {
    mat_copy_matrix_d3( spacegroup.bravais_lattice, conv_lattice );
    spacegroup.number = spacegroup_type.number;
    strcpy(spacegroup.schoenflies,
	   spacegroup_type.schoenflies);
    strcpy(spacegroup.hall_symbol,
	   spacegroup_type.hall_symbol);
    strcpy(spacegroup.international,
	   spacegroup_type.international);
    strcpy(spacegroup.international_long,
	   spacegroup_type.international_full);
    strcpy(spacegroup.international_short,
	   spacegroup_type.international_short);
  } else {
    spacegroup.number = 0;
    fprintf(stderr, "spglib BUG: Space group could not be found.\n");
  }

  return spacegroup;
}

static SpacegroupType get_spacegroup_type( SPGCONST double trans_mat[3][3],
					   const Centering centering,
					   const Symmetry * symmetry,
					   const double symprec )
{
  int hall_number;
  Symmetry *conv_symmetry;
  double origin_shift[3];

  conv_symmetry = spa_get_conventional_symmetry( trans_mat,
						 centering,
						 symmetry,
						 symprec );
  hall_number = hal_get_hall_symbol( origin_shift,
				     centering,
				     conv_symmetry,
				     symprec );
  sym_free_symmetry( conv_symmetry );

  return spgdb_get_spacegroup_type( hall_number );
}
					    

static Centering get_transformation_matrix( double trans_mat[3][3],
					    Symmetry * symmetry,
					    const double symprec )
{
  int i;
  int pg_order[32];
  double correction_mat[3][3];
  Centering centering;
  Symmetry *sym_cast;
  Pointgroup pointgroup;

  ptg_get_pointgroup_order( pg_order, symmetry );
  pointgroup = ptg_get_pointgroup( pg_order[0] );
  sym_cast = ptg_get_symmetry( pg_order[0], symmetry );
  ptg_get_transformation_matrix( &pointgroup, sym_cast );

  /* Symmetry operations may change if ill-defined symmetry */
  /* operations in the sense of point group are given. */
  symmetry->size = sym_cast->size;
  for ( i = 0; i < sym_cast->size; i++ ) {
    mat_copy_matrix_i3( symmetry->rot[i], sym_cast->rot[i] );
    mat_copy_vector_d3( symmetry->trans[i], sym_cast->trans[i] );
  }
  sym_free_symmetry( sym_cast );

  /* Centering is not determined only from symmetry operations */
  /* sometimes. Therefore centering and transformation matrix are */
  /* related. */
  centering = lat_get_centering( correction_mat,
				 pointgroup.transform_mat,
				 pointgroup.laue,
				 symprec );
  mat_multiply_matrix_id3( trans_mat, pointgroup.transform_mat,
			   correction_mat );

  debug_print("correction matrix\n");
  debug_print_matrix_d3( correction_mat );

  return centering;
}

static Cell * get_primitive( SPGCONST Cell * cell,
			     const double symprec )
{
  int i, j;
  double min_lat[3][3], trans_mat[3][3], inv_lat[3][3];
  VecDBL *pure_trans;
  Cell *primitive;

  pure_trans = sym_get_pure_translation( cell, symprec );
  
  if ( pure_trans->size > 1 ) {
    primitive = prm_get_primitive_with_pure_trans( cell,
						   pure_trans,
						   symprec );
  } else {
    /* Transform lattice to the smallest lattice */
    lat_smallest_lattice_vector( min_lat, cell->lattice, symprec );
    mat_inverse_matrix_d3( inv_lat, min_lat, symprec );
    mat_multiply_matrix_d3( trans_mat, inv_lat, cell->lattice );
    primitive = cel_alloc_cell( cell->size );
    mat_copy_matrix_d3( primitive->lattice, min_lat );
    for ( i = 0; i < cell->size; i++ ) {
      primitive->types[i] = cell->types[i];
      mat_multiply_matrix_vector_d3( primitive->position[i],
				     trans_mat, cell->position[i] );
      for ( j = 0; j < 3; j++ ) {
	cell->position[i][j] -= mat_Nint( cell->position[i][j] );
      }
    }
  }

  mat_free_VecDBL( pure_trans );

  return primitive;
}



static Symmetry * get_conventional_symmetry( SPGCONST double transform_mat[3][3],
					     const Centering centering,
					     const Symmetry *primitive_sym,
					     const double symprec )
{
  int i, j, k, multi, size;
  double tmp_trans;
  double tmp_matrix_d3[3][3], shift[4][3];
  double symmetry_rot_d3[3][3], primitive_sym_rot_d3[3][3];
  Symmetry *symmetry;

  size = primitive_sym->size;

  if (centering == FACE) {
    symmetry = sym_alloc_symmetry(size * 4);
  }
  else {
    if (centering) {
      symmetry = sym_alloc_symmetry(size * 2);
    } else {
      symmetry = sym_alloc_symmetry(size);
    }
  }

  for (i = 0; i < size; i++) {
    mat_cast_matrix_3i_to_3d(primitive_sym_rot_d3, primitive_sym->rot[i]);

    /* C*S*C^-1: recover conventional cell symmetry operation */
    mat_get_similar_matrix_d3( symmetry_rot_d3, primitive_sym_rot_d3,
			       transform_mat, symprec );
    mat_cast_matrix_3d_to_3i( symmetry->rot[i], symmetry_rot_d3 );

    /* translation in conventional cell: C = B^-1*P */
    mat_inverse_matrix_d3(tmp_matrix_d3, transform_mat, symprec);
    mat_multiply_matrix_vector_d3( symmetry->trans[i], tmp_matrix_d3,
				   primitive_sym->trans[i] );
  }

  multi = 1;

  if (centering) {
    if (centering != FACE) {
      for (i = 0; i < 3; i++) {	shift[0][i] = 0.5; }
      if (centering == A_FACE) { shift[0][0] = 0; }
      if (centering == B_FACE) { shift[0][1] = 0; }
      if (centering == C_FACE) { shift[0][2] = 0; }

      multi = 2;
    }

    if (centering == FACE) {
      shift[0][0] = 0;
      shift[0][1] = 0.5;
      shift[0][2] = 0.5;
      shift[1][0] = 0.5;
      shift[1][1] = 0;
      shift[1][2] = 0.5;
      shift[2][0] = 0.5;
      shift[2][1] = 0.5;
      shift[2][2] = 0;

      multi = 4;
    }

    for (i = 0; i < multi - 1; i++) {
      for (j = 0; j < size; j++) {
	mat_copy_matrix_i3( symmetry->rot[(i+1) * size + j],
			    symmetry->rot[j] );
	for (k = 0; k < 3; k++) {
	  tmp_trans = symmetry->trans[j][k] + shift[i][k];
	  symmetry->trans[(i+1) * size + j][k] = tmp_trans;
	}
      }
    }
  }


  /* Reduce translations into -0 < trans < 1.0 */
  for (i = 0; i < multi; i++) {
    for (j = 0; j < size; j++) {
      for (k = 0; k < 3; k++) {
  	tmp_trans = symmetry->trans[i * size + j][k];
  	tmp_trans -= mat_Nint(tmp_trans);
  	if ( tmp_trans < -symprec ) {
  	  tmp_trans += 1.0;
  	}
  	symmetry->trans[i * size + j][k] = tmp_trans;
      }
    }
  }

#ifdef DEBUG
  debug_print("Multi: %d\n", multi);
  debug_print("Centering: %d\n", centering);
  debug_print("sym size: %d\n", symmetry->size);
  
  for (i = 0; i < symmetry->size; i++) {
    debug_print("--- %d ---\n", i + 1);
    debug_print_matrix_i3(symmetry->rot[i]);
    debug_print("%f %f %f\n", symmetry->trans[i][0],
		symmetry->trans[i][1], symmetry->trans[i][2]);
  }
#endif

  return symmetry;
}
