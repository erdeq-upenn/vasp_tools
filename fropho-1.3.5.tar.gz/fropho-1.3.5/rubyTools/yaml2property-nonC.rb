#!/usr/bin/env ruby

# yaml2property-nonC.rb :  calculate dynamical properties without using C-extension
#                     omega <= 0.0 is ignored
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
# Time-stamp: <2006-05-16 15:00:00 togo>
#
# usage: yaml2property.rb [OPTION] [YAML-FILE]

require 'optparse'
require 'frophorun.rb'
require 'thermal_property.so'

Kb = 8.61733e-5 # [eV/K]
Hbar = 6.58218e-16 # [eV s]
CmToEv = 1.23985e-4 # [eV]
CmTokJmol = 11.96261 # [kJ/mol]
EvTokJmol = 96.4840 # [kJ/mol]
VaspToCm = 3276.5 / (2 * Math::PI) # [cm^-1]
Avogadro = 6.0222e23

class Yaml2property

  include Math
  include ThermalProperty

  def initialize(filename)
    @filename = "frophorun.yaml"
    if filename
      @filename = filename
    end
  end

  def start
    yaml = ParseYaml.new(@filename)
    @nqpoint = yaml.numQpoint
    @frequency = []
    yaml.frequency.each do |omega|
      @frequency << omega * @unit * CmToEv if omega > 0.0
    end
    @natom = yaml.numAtom
  end

  def setTemperature(temperature)
    @temperature = temperature
  end

  def getFreeEnergy
    freeEnergy = 0.0
    freq = []
    if (@temperature > 0.0)
#       freeEnergy = free_energy(@temperature, @frequency.size, @frequency)
      @frequency.each do |omega|
        if (omega > 0.0) # can not calculate if omega is negative
          # Calculate zero point energy
#           freeEnergy += 1.0 / 2 * omega + Kb * @temperature * log(1 - exp((- omega) / (Kb * @temperature)))
          # Not calculate zero point energy
          freeEnergy +=  Kb * @temperature * log(1 - exp((- omega) / (Kb * @temperature)))
        end
      end 
    end
    freeEnergy / @nqpoint / @natom * EvTokJmol * @coefficient + zeroPointEnergy()
  end

  # This is the alternative expression of getFreeEnergy with zero point energy
  def getFreeEnergy2
    freeEnergy = 0.0
    @frequency.each do |omega|
      freeEnergy += Kb * @temperature * log(2 * sinh(omega / (2 * Kb * @temperature)))
    end
   freeEnergy / @nqpoint / @natom * EvTokJmol * @coefficient
  end

  def getEntropy
    entropy = 0.0
    if (@temperature > 0.0)
#       entropy = entropy(@temperature, @frequency.size, @frequency)
      @frequency.each do |omega|
        if (omega > 0.0) # can not calculate if omega is negative
          val = omega / (2 * Kb * @temperature)
          entropy += 1 / (2 * @temperature) * omega * cosh(val) / sinh(val) - Kb * log(2 * sinh(val))
        end
      end
    end
    entropy / @nqpoint / @natom * EvTokJmol * @coefficient
  end
    
  # This is the alternative expression of getEntropy
  def getEntropy2
    entropy = 0.0
    if (@temperature > 0.0)
      @frequency.each do |omega|
        if (omega > 0.0) # can not calculate if omega is negative
          val = omega / (Kb * @temperature)
          entropy += -Kb * log(1 - exp( -val )) + 1.0 / @temperature * omega / (exp( val ) - 1)
        end
      end
    end
    entropy / @nqpoint / @natom * EvTokJmol * @coefficient
  end
    
  def getCv
    cv = 0.0
    if (@temperature > 0.0)
#       cv = cv(@temperature, @frequency.size, @frequency)
      frequency = @frequency.sort
      frequency.each_with_index do |omega, i|
        if (omega > 0.0) # can not calculate if omega is negative
          expVal = exp(omega / (Kb * @temperature))
          cv += Kb * (omega / (Kb * @temperature)) ** 2 * expVal / (expVal - 1.0) ** 2
        end
      end
    end
    cv / @nqpoint / @natom * EvTokJmol * @coefficient
  end

  def getZeroPointEnergy
    zeroPointEnergy
  end

  def setCoefficient(coefficient)
    @coefficient = coefficient
  end

  def getNumQpoint
    @nqpoint
  end

  def getNumAtom
    @natom
  end

  def setUnit(unit)
    @unit = unit
  end

  private

  def zeroPointEnergy
    zeroEnergy = 0.0
      @frequency.each do |omega|
        if (omega > 0.0) # can not calculate if omega is negative
          zeroEnergy += 1.0 / 2 * omega 
        end
      end 
    zeroEnergy / @nqpoint / @natom * EvTokJmol * @coefficient
  end
end

def checkImaginary(yaml)
  eigenvalue = []
  yaml['phonon'].each do |qpoint|
    qvec = qpoint['q-position']
    qpoint['q-point'].each do |eigen|
      if eigen['eigenvalue'] < 0.0
        printf("[%8.5f,%8.5f,%8.5f] eigenval: %10.5f   freq: %10.5f\n", qvec[0], qvec[1], qvec[2], eigen['eigenvalue'], eigen['frequency'])
        end
    end
  end
end


if __FILE__ == $0

  # parse options
  dTemp = 10
  maxTemp = 1000
  minTemp = 10
  mol = 1
  unit = VaspToCm
  imaginary = false
  stderrFlag = false
  opt = OptionParser.new
  opt.on('--step=delta T') {|dTemp|}
  opt.on('--maxt=max T') {|maxTemp|}
  opt.on('--mint=min T') {|minTemp|}
  opt.on('--mol=mol unit') {|mol|}
  opt.on('--unit=coefficient') {|unit|}
  opt.on('--imaginary') {|imaginary|}
  opt.on('--stderr') {|stderrFlag|}
  opt.parse!(ARGV)

  # check imaginary value and q-vector where imaginary value is
  if imaginary
    if ! filename = ARGV.shift
      filename = "frophorun.yaml"
    end
    checkImaginary(YAML.load(File.open(filename).read()))
    exit(0)
  end

  # create object
  yaml = Yaml2property.new(ARGV.shift)

  # set parameters
  yaml.setCoefficient(mol.to_f)
  yaml.setUnit(unit.to_f)

  # start
  yaml.start

  # zero point energy
  zeroPointEnergy = yaml.getZeroPointEnergy
  if stderrFlag
    STDERR.printf("# zero point energy: %15.10f [kJ/mol], %15.10f [eV]\n\n", zeroPointEnergy, zeroPointEnergy / EvTokJmol)
  end
  printf("# zero point energy: %15.10f [kJ/mol], %15.10f [eV]\n\n", zeroPointEnergy, zeroPointEnergy / EvTokJmol)

  # properties
  if stderrFlag
    STDERR.printf("%-12s %20s %20s %25s\n", "# temperatrue", "free energy [kJ/mol]", "entropy [J/K/mol]", "heat capacity [J/K/mol]")
  end
  printf("%-12s %20s %20s %25s\n", "# temperatrue", "free energy [kJ/mol]", "entropy [J/K/mol]", "heat capacity [J/K/mol]")

  if stderrFlag
    STDERR.printf("%12.5f %20.10f %20.10f %25.10f\n", 0, zeroPointEnergy, 0, 0)
  end
  printf("%12.5f %20.10f %20.10f %25.10f\n", 0, zeroPointEnergy, 0, 0)
  temperature = minTemp.to_f

  while (temperature <= maxTemp.to_f) do
    yaml.setTemperature(temperature)
    freeEnergy = yaml.getFreeEnergy
    entropy  = yaml.getEntropy
    cv = yaml.getCv

    if stderrFlag
      STDERR.printf("%12.5f %20.10f %20.10f %25.10f\n", temperature, freeEnergy, entropy * 1000, cv * 1000)
    end
    printf("%12.5f %20.10f %20.10f %25.10f\n", temperature, freeEnergy, entropy * 1000, cv * 1000)
    temperature += dTemp.to_f
  end

end
