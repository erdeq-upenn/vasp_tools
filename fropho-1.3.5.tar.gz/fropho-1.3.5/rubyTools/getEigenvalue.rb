#!/usr/bin/env ruby

# getFrequency.rb :  get the eigenvalue and frequency you indicate
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
# Time-stamp: <2006-05-21 12:01:25 togo>
#
# usage: getFrequency.rb [OPTION] [YAML-FILE]
#      -b = band number
#      -q = Q-point number
#      --factor = facor for frequency
#
# for VASP
#     factor = 15.633 for THz (98.228/2pi)
#            = 521.47 for cm-1 (3276.5/2pi)


require 'optparse'
require 'frophorun'

# class for yaml to dos
class GetFreq

  def initialize(filename, factor=1)
    if filename == nil
      filename = "frophorun.yaml"
    end
    @yaml = ParseYaml.new(filename)
    @factor = factor
    @eigenvalue = @yaml.eigenvalueAtQ
    @frequency = @yaml.frequencyAtQ
  end

  def test
    @eigenvalue.each_with_index do |eigenvalAtQ, i|
      print "-----------\n"
      print "Q-#{i}\n"
      print "-----------\n"
      eigenvalAtQ.each do |elem|
        p elem
      end
    end
  end

  def getEigenvalue(qpoint, band)
    @eigenvalue[qpoint - 1][band - 1]
  end

  def getFrequency(qpoint, band)
    @frequency[qpoint - 1][band - 1]
  end

end


if __FILE__ == $0

  qpoint = 1
  band = 1
  factor = 1.0

  opt = OptionParser.new
  opt.on('-q [Q-point]') do |qTmp|
    if qTmp.to_i > 0
      qpoint = qTmp.to_i
      STDERR.printf("Q-point:%d\n", qpoint)
    end
  end
  opt.on('-b [band]') do |bTmp|
    if bTmp.to_i > 0
      band = bTmp.to_i
      STDERR.printf("band:%d\n", band)
    end
  end
  opt.on('--factor[=unit conversion factor]') do |factorTmp|
    if (factorTmp.to_f > 0)
      factor = factorTmp.to_f
      STDERR.printf("Set factor to %f.\n", factor) 
    end
  end

  opt.parse!(ARGV)

  yaml = GetFreq.new(ARGV.shift)
  eigenvalue = yaml.getEigenvalue(qpoint, band) * factor * factor
  frequency = yaml.getFrequency(qpoint, band) * factor
  STDERR.print("------------------------\n")
  STDERR.print(" eigenvalue   frequency\n")
  printf("%11.7f %11.7f\n", eigenvalue, frequency)
end
