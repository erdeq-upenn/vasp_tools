# Time-stamp: <2008-04-02 20:51:17 togo>
#
# syminfo.rb :  write gnuplot type bandstructure data
#
#   Copyright (C) 2006 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can edistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
#
# usage: cleanCrystal [OPTIONS] [syminfo.yaml]
#

require 'yaml'
require 'optparse'
require 'matrix'
require 'poscar'

class Matrix
  def []=(i, j, x)
    @rows[i][j] = x
  end
end

class ParseSymInfo
  def initialize(filename)
    File.open(filename) do |file|
      @yaml = YAML.load(file)
    end
    @symprec = 1e-5
  end

  def atomType
    atomType = []
    @yaml['atom-info'].each do |elem|
      atomType << elem['type']
    end
    atomType
  end

  def atomName
    atomName = []
    @yaml['atom-info'].each do |elem|
      atomName << elem['name']
    end
    atomName
  end

  def bravais
    @yaml['bravais-lattice']
  end

  # This matrix is relation to Bravais lattice to input lattice,
  # C = B^-1 * L (B is Bravais, L is input lattice)
  def coordinate
    @yaml['coordinate']
  end

  def international
    @yaml['international']
  end

  # returen atom names if they exist. If not, return atom types.
  def name
    array = atomName
    if array.compact!
      array = atomType
    end
    array
  end

  def operation
    @yaml['operation']
  end

  def pointGroup
    @yaml['point_group']
  end

  def position
    @yaml['position']
  end

  def primitive
    if @yaml['primitive']
      @yaml = @yaml['primitive']
    end
  end

  def realBasis
    @yaml['real-basis']
  end

  def schoenflies
    @yaml['schoenflies']
  end

  def spaceGroup
    @yaml['space_group']
  end
end

