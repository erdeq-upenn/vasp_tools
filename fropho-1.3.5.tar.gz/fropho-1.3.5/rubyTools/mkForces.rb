#!/usr/bin/env ruby

#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html

require 'vasprun'
require 'poscar'
require 'phonModule'
require 'optparse'

DefaultDisplacement = 0.01

class VasprunToForces
  def initialize(filename, residualForce)
    @forceArray = ParseVasprun.new(filename).force[-1]
    if residualForce
      @forceArray.size.times do |i|
        3.times do |j|
          @forceArray[i][j] -= residualForce[i][j]
        end
      end
    end
  end

  def printForce
    @forceArray.each do |f|
      printf("%12.8f   %12.8f   %12.8f\n", f[0], f[1], f[2])
    end
  end
end

class ForceForPhon
  def initialize(dispfile, sposcarName)
    @sposcar = Vasp::Poscar.new(sposcarName).cell
    @dispfile = dispfile
    @residualForce = nil
  end

  def setDispScale(a, b, c)
    @disp = []
    @disp << a
    @disp << b
    @disp << c
  end

  def setZeroPoint(filename)
    @residualForce = ParseVasprun.new(filename).force[-1]
  end

  def start
    dispArray = getDisp(@dispfile, getDispScaleReduced(@sposcar))
    forcesArray = collectForces
    order = sortArrays(dispArray)
    print "#{dispArray.size}\n"
    order.each do |x|
      printf("%d   %15.10f   %15.10f   %15.10f\n", dispArray[x].number, dispArray[x].disp[0], dispArray[x].disp[1], dispArray[x].disp[2])
      forcesArray[x].printForce
    end
  end

  include Phon

  def collectForces
    forcesArray = []
    ARGV.each do |filename|
      $stderr.printf("#{filename} ")
      forcesArray << VasprunToForces.new(filename, @residualForce)
    end
    $stderr.printf("\n")
    forcesArray
  end

  def getDispScaleReduced(cell)
    disp = []
    3.times {|i| disp << @disp[i] / cell.axisLength[i]}
    disp
  end

  def sortArrays(dispArray)
    numArray = []
    dispArray.each_with_index do |elem, i|
      numArray << [elem.number, i]
    end
    order = []
    STDERR.print("sorted order\n ")
    STDERR.print("[ ")
    numArray.sort.each do |x|
      order << x[1]
      STDERR.print("#{x[1]+1} ")
    end
    STDERR.print("]\n")
    order
  end

end

disp_a = DefaultDisplacement
disp_b = DefaultDisplacement
disp_c = DefaultDisplacement
zeroFile = nil

opt = OptionParser.new
opt.on('-a DISPLACEMENT', 'displacement quantity of a-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in a direction.\n")
    disp_a = x.to_f
  end
end
opt.on('-b DISPLACEMENT', 'displacement quantity of b-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in b direction.\n")
    disp_b = x.to_f
  end
end
opt.on('-c DISPLACEMENT', 'displacement quantity of c-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in c direction.\n")
    disp_c = x.to_f
  end
end
opt.on('-z vasprun.xml', '--zero=', 'read vasprun.xml of equilibrium supercell for zero point correction') do |x|
  zeroFile = x
end
opt.parse!(ARGV)

def printUsage
  STDERR.print <<HERE
Usage: mkForce.rb [OPTION] [DISP] [SPOSCAR] [vasprun.xml ...]
HERE
end

if ARGV[0] == nil or ARGV[1] == nil or ARGV[2] == nil
  printUsage
  exit(0)
end

filenameDISP = ARGV.shift
filenameSPOSCAR = ARGV.shift
forceForPhon = ForceForPhon.new(filenameDISP, filenameSPOSCAR)
forceForPhon.setDispScale(disp_a, disp_b, disp_c)
forceForPhon.setZeroPoint(zeroFile) if zeroFile
forceForPhon.start

