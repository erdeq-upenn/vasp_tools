#!/usr/bin/env ruby

# Time-stamp: <2008-06-28 18:59:43 togo>
#
# reducePhonon.rb :  Yield direct sum of irreducible representations
#
#   Copyright (C) 2006 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can edistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# usage: reducePhonon.rb [OPTIONS] [syminfo.yaml] [frophorun.yaml]
#

require 'yaml'
require 'optparse'
require 'matrix'
require 'poscar'
require 'syminfo'
require 'frophorun'
require 'phononModeModule'

class CharacterTable
  def initialize(filename)
    File.open(filename) do |file|
      @yaml = YAML.load(file)
    end
  end

  def basis
    target("basis")
  end

  def character
    target("character")
  end

  def ir
    @yaml['ir']
  end

  def mulliken
    target("mulliken")
  end

  def number
    @yaml['number']
  end

  def operator
    @yaml['operator']
  end

  def symbol
    @yaml['symbol']
  end

  def simpleSymbol
    @yaml['simpleSymbol']
  end

  private

  def target(value)
    array = []
    ir.each do |elem|
      array << elem[value]
    end
    array
  end
end



module ReduceDirectSum
  def createMap(crystalOperators, irOperators, simpleSymbol)
    map = []
    crystalOperators.each_with_index do |crysOpe, i|
      if crysOpe == "none"
        warn "Symmetry operaton No.#{i+1} could not be located to symbol."
      end
      irOperators.each_with_index do |irOpe, j|
        if simpleSymbol[crysOpe] == irOpe
          map << j
        end
      end
    end
    map
  end

  def createOperation(basis, positions, operations, symprec, decimal)
    # create translation map among atoms
    lists = []
    operations.each do |operation|
      list = []
      positions.each do |posOuter|
        positions.each_with_index do |posInner, i|
          if reduce(operation['rotation'] * posOuter + operation['translation'] - posInner, decimal).r < symprec
            list << i
            break
          end
        end
      end
      lists << list
    end

    # create 3Nx3N operation of all freedom in Cartesian
    matrices = []
    numAtom = positions.size 
    operations.each do |operation|
      array = []
      lists.shift.each do |num|
        operationArray = (basis * operation['rotation'] * basis.inverse).transpose.to_a
        3.times do
          tmpArray = Array.new(numAtom * 3, 0.0)
          tmpArray[(3*num)..(3*num+2)] = operationArray.shift
          array << tmpArray
        end
      end
      matrices << Matrix.rows(array.transpose)
    end

    matrices
  end

  def getOperation(symInfo)
    operations = []
    symInfo.operation.each do |operation|
      operations << {"rotation"=> Matrix.rows(operation['rotation']),
        "translation"=>Vector.elements(operation['translation'])}
    end
    operations
  end

  def getPosition(symInfo)
    positions = []
    symInfo.position.each do |position|
      positions << Vector.elements(position)
    end
    positions
  end

  def mapOperator(operations, coordinate, symbol, symprec)
    operators = []
    operations.each do |rot|
      rotation = []
      (coordinate * rot['rotation'] * coordinate.inverse).to_a.each do |row|
        rotation << row.collect {|elem| elem.round}
      end
      operator = "none"
      symbol.each do |ope|
        if rotation == ope[1]
          operator = ope[0]
        end
      end
      operators << operator
    end
    operators
  end

  def reduce(vector, decimal)
    vec = []
    vector.to_a.each do |elem|
      vec << elem - (elem - decimal).round
    end
    Vector.elements(vec)
  end

  def weightedIrTable(characters, weights)
    table = []
    characters.each do |character|
      column = []
      character.each_with_index do |elem, i|
        column << elem * weights[i].to_f
      end
      table << column
    end
    table
  end
end

def reduceDirectSum(symInfo, table, symprec, decimal, phonon = false)
  include ReduceDirectSum
  # 3N x 3N operation matrices from syminfo.yaml
  basis = Matrix.rows(symInfo.realBasis).transpose
  crystalMatrices = createOperation(basis, getPosition(symInfo), getOperation(symInfo), symprec, decimal)

  # Create symbol map from crystal symmetry (more) to character table (fewer)
  crystalOperators = mapOperator(getOperation(symInfo), Matrix.rows(symInfo.coordinate),  table.symbol, symprec)

  # Mapping symbols between crystal and ir-table
  mapCrystalToTable = createMap(crystalOperators, table.operator, table.simpleSymbol)

  # Characters in same classes are binded.
  characterSum = Array.new(table.operator.size, 0)
  mapCrystalToTable.each_with_index do |i, j|
    characterSum[i] += crystalMatrices[j].trace
  end
  
  # Reduce direct sum
  sumTable = Matrix.rows(weightedIrTable(table.character, table.number)).transpose.inverse * Vector.elements(characterSum)
  
  return sumTable, mapCrystalToTable, crystalMatrices, crystalOperators
end


def projection(numAtom, table, matrices, map, modes, mass, frequency, symprec, stderrFlag)
  checkSum = []
  puts "mode symbol      frequency   basis"
  modes.each_with_index do |mode, i|
    table.ir.each do |ir|
      (numAtom * 3).times do |j|
        tmpMass = Math.sqrt(mass[(j/3).to_i])
        sumVector = Vector.elements(Array.new(3 * numAtom, 0.0))
        matrices.each_with_index do |matrix, k|
          sumVector += matrix.column(j) * tmpMass * ir['character'][map[k]]
        end
        val = sumVector.inner_product(Vector.elements(mode.flatten))
        if val.abs > symprec
          printf("%3d   %-3s  %15.8f   ", i+1, ir['mulliken'], frequency[i])
          if stderrFlag
            STDERR.printf("%3d   %-3s  %15.8f\n", i+1, ir['mulliken'], frequency[i])
          end
          checkSum << ir['mulliken']
          if ir['basis']
            ir['basis'].each do |elem|
              print "#{elem.gsub(/&/, ",").gsub(/2/,"^2")} "
            end
          end
          print "\n"
#           $stderr.printf("%3d:", j)
#           sumVector.to_a.each do |elem|
#             $stderr.printf("%5.2f ", elem)
#           end
#           $stderr.printf(":%10.5f", val)
#           $stderr.print "\n"
          break
        end
      end
    end
  end
  checkSum
end






if __FILE__ == $0
  symprec = 1e-2
  decimal = 1e-16
  primitive = false
  syminfoFile = false
  stderrFlag = false
  frophorunFile = false
  irrep = false
  qnumber = 0
  logFlag = false
  factor = 1.0
  irTablePath = "#{ENV['FROPHOPATH']}/character_table/"
  checkCartesian = false
  opt = OptionParser.new
  opt.on('-i', '--irrep', 'Only print direct sum of irrep of crystal') {|irrep|}
  opt.on('-p', '--primitive', 'Use primitive symmetry information') {|primitive|}
  opt.on('--syminfo=', 'syminfo.yaml file') {|syminfoFile|}
  opt.on('-f', '--frophorun=', 'frophorun.yaml file') {|frophorunFile|}
  opt.on('-q', '--qpoint=', 'q-point number') {|tmp| qnumber = tmp.to_i}
  opt.on('-s', '--symprec=', 'Symmetry check precision') {|tmp| symprec = tmp.to_f}
  opt.on('-l', '--log', 'Obtain detail') {|logFlag|}
  opt.on('-f', '--factor=', 'Unit of conversion factor') {|tmp| factor = tmp.to_f}
  opt.on('-c', '--check', 'Check rotation in Cartesian') {|checkCartesian|}
  opt.on('--stderr') {|stderrFlag|}
  opt.parse!(ARGV)

  if syminfoFile
    symInfo = ParseSymInfo.new(syminfoFile)
  else
    symInfo = ParseSymInfo.new("syminfo.yaml")
  end
  symInfo.primitive

  # Reading Point group irreps and Operations of a Bravais lattice
  case symInfo.schoenflies[0..2]
  when "C2v"
    tablePath = ("#{irTablePath}C2v.yaml")
  when "C6v"
    tablePath = ("#{irTablePath}C6v.yaml")
  when "C2h"
    tablePath = ("#{irTablePath}C2h.yaml")
  when "D2^"
    tablePath = ("#{irTablePath}D2.yaml")
  when "D3^"
    tablePath = ("#{irTablePath}D3.yaml")
  when "D4^"
    tablePath = ("#{irTablePath}D4.yaml")
  when "D4h"
    tablePath = ("#{irTablePath}D4h.yaml")
  when "D2h"
    tablePath = ("#{irTablePath}D2h.yaml")
  when "D3d"
    tablePath = ("#{irTablePath}D3d.yaml")
  when "D2d"
    tablePath = ("#{irTablePath}D2d.yaml")
  else
    warn "The point group is not prepared."
    exit(0)
  end
  table = CharacterTable.new(tablePath)

  #
  # Check rotation in Cartesian
  #  If this is imposed, just show the rotation matrix in Cartesian and stop.
  if checkCartesian
    coordinate = Matrix.rows(symInfo.coordinate)
    symInfo.operation.each_with_index do |operation, i|
      puts i+1
      p coordinate
      (coordinate * Matrix.rows(operation['rotation']) * coordinate.inverse).to_a.each do |row|
        printf("[%5.2f,%5.2f,%5.2f]\n", row[0], row[1], row[2])
      end
      puts
    end
    exit(0)
  end

  #
  # Reduce direct sum
  #
  sumTable, map, crysMatrices, crystalOperators = reduceDirectSum(symInfo, table, symprec, decimal)

  # Output symbols of symmetry operations
  print "symmetry operations: "
  crystalOperators.each do |symbol|
    print "#{symbol} "
  end
  print "\n"

  # Direct sum checking
  numAtom = symInfo.position.size
  sum = 0
  sumTable.to_a.each_with_index do |val, i|
    if (val - val.round).abs > symprec or val.round < 0
      warn "Number of irrep is not integer."
      p sumTable.to_a
      exit(1)
    end
    case table.mulliken[i][0].chr
    when "E"
      sum += val * 2
    when "T"
      sum += val * 3
    else
      sum += val
    end
  end
  if sum.round != numAtom * 3
    warn "Something wrong occurs"
    warn "Number of freedom: #{numAtom * 3} != sum of irrep dimensions: #{sum}"
    exit(1)
  end

  # Direct sum output
  string = ""
  table.mulliken.each_with_index do |mulliken, i|
    if sumTable.to_a[i].round != 0
      string += sprintf("%3d %-3s +", sumTable.to_a[i].round, mulliken)
    end
  end
  puts "Direct sum: #{string.chop}"

  # log
  if logFlag
    crysMatrices.each_with_index do |array, i|
      puts "No.#{i+1}: #{table.operator[map[i]]}"
      array.to_a.each do |line|
        line.each do |x|
          printf("%2d ", x)
        end
        print "\n"
      end
      puts ""
    end
  end

  # stop when irrep only
  if irrep
    exit(1)
  end

  #
  # projection
  #
  if frophorunFile
    frophorun = ParseYaml.new(frophorunFile)
  else
    frophorun = ParseYaml.new("frophorun.yaml")
  end
  mode = frophorun.eigenvectorAtQ[qnumber-1]
  if mode == nil
    warn "No such a q-point"
    exit(0)
  end
  frequency = frophorun.frequencyAtQ[qnumber-1].collect! {|val| val * factor}
  checkSum = projection(numAtom, table, crysMatrices, map, mode, frophorun.mass, frequency, symprec, stderrFlag)

  # Checking projection
  sumArray = []
  sumTable.to_a.each_with_index do |val, i|
    case table.mulliken[i][0].chr
    when "E"
      sumArray << val.round * 2
    when "T"
      sumArray << val.round * 3
    else
      sumArray << val.round
    end
  end
  checkSum.each do |mulliken|
    sumArray[table.mulliken.index(mulliken)] -= 1
  end
  if sumArray.uniq.size != 1 or sumArray[0] != 0
    warn "Projection went wrong !!"
    exit(1)
  end
end
