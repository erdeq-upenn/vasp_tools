#!/usr/bin/env ruby

# parseYaml.rb :  yaml parser class
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
# Time-stamp: <2006-11-05 17:59:04 togo>

require 'yaml'
require 'complex'

module ForceConstant

  require 'poscar'

  class ForceConstant
    attr_reader :unitcell, :supercell, :matrix
    def initialize (unitcell, supercell, matrix)
      @unitcell = unitcell
      @supercell = supercell
      @matrix = matrix
    end
  end

  class Atom < Crystal::Atom
    attr_accessor :mass
    def initialize(position, mass = nil)
      @position = position
      @mass = mass
    end
  end
end

class ParseYaml
  
  def initialize(filename)
    @yaml = YAML.load(File.open(filename).read())
  end 

  def cellVolume
    @yaml['cell-volume']
  end

  def coordinate
    @yaml['coordinate']
  end
  
  def eigenvalueAtQ
    eigenvalue = []
    @yaml['phonon'].each do |qpoint|
      eigenTemp = []
      qpoint['q-point'].each do |eigen|
        eigenTemp << eigen['eigenvalue']
      end
      eigenvalue << eigenTemp
    end
    eigenvalue
  end

  def eigenvalue
    eigenvalue = []
    @yaml['phonon'].each do |qpoint|
      qpoint['q-point'].each do |eigen|
        eigenvalue << eigen['eigenvalue']
      end
    end
    eigenvalue
  end

  def eigenvector  # [q-point * band][atom][vector]
    eigenvector = []
    @yaml['phonon'].each do |qpoint|
      qpoint['q-point'].each do |eigen|
        eigEig = []
        eigen['eigenvector'].each do |atom|
          eigAtom = []
          3.times do |x|
            eigAtom << Complex.new(atom[x][0],atom[x][1])
          end
          eigEig << eigAtom
        end 
        eigenvector << eigEig
      end
    end
    eigenvector
  end

  def eigenvectorAtQ  # [q-point][band][atom][vector]
    eigenvector = []
    @yaml['phonon'].each do |qpoint|
      eigQ = []
      qpoint['q-point'].each do |eigen|
        eigEig = []
        eigen['eigenvector'].each do |atom|
          eigAtom = []
          3.times do |x|
            eigAtom << Complex.new(atom[x][0],atom[x][1])
          end
          eigEig << eigAtom
        end 
        eigQ << eigEig
      end
      eigenvector << eigQ
    end
    eigenvector
  end

  def forceConstant
    require 'matrix'
    require 'poscar'

    forceConstant = []
    atoms = []
    axis = []
    mass = []
    position = []
    fcYaml = @yaml['forceconstant']
    scYaml = @yaml['supercell']
    scYaml['position'].each {|elem| position << elem}
    scYaml['atom-info'].each {|elem| mass << elem['mass']}
    scYaml['real-basis'].each {|vec| axis << vec}
    position.size.times {|i| atoms << ForceConstant::Atom.new(position[i], mass[i])}
    cell = Crystal::Cell.new(axis, atoms)
    fcYaml.each do |elem|
      matrix = elem['matrix']
      forceConstant << ForceConstant::ForceConstant.new(elem['atom-unitcell'], elem['atoms-supercell'], matrix)
    end
    return cell, forceConstant
  end

  def frequency
    eigenvalue = []
    @yaml['phonon'].each do |qpoint|
      qpoint['q-point'].each do |eigen|
        eigenvalue << eigen['frequency']
      end
    end
    eigenvalue
  end

  def frequencyAtQ
    eigenvalue = []
    @yaml['phonon'].each do |qpoint|
      eigenTemp = []
      qpoint['q-point'].each do |eigen|
        eigenTemp << eigen['frequency']
      end
      eigenvalue << eigenTemp
    end
    eigenvalue
  end

  def mass
    array = []
    @yaml['atom-info'].each do |elem|
      array << elem['mass']
    end
    array
  end

  def name
    array = []
    @yaml['atom-info'].each do |elem|
      array << elem['name']
    end
    array
  end

  def numAtom
    @yaml['natom']
  end

  def numQpoint
    @yaml['nqpoint']
  end

  # [[a1,b1,c1], [a2,b2,c2]....]
  def position
    @yaml['position']
  end

  def qposition
    qposition = []
    @yaml['phonon'].each do |qpoint|
      qposition << qpoint['q-position']
    end
    qposition
  end

  def realBasis
    @yaml['real-basis']
  end

  def recBasis
    @yaml['rec-basis']
  end

  def recCellVolume
    @yaml['rec-cell-volume']
  end

end



