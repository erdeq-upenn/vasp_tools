# Time-stamp: <2007-03-19 17:00:59 togo>
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html

require 'poscar'

module PhononMode
  AtomicNumber = Crystal::AtomicNumber

  #
  # make unitcell
  #
  # Atomic positions must be supplied by Cartesian
  class Atom
    attr_reader :name, :position
    def initialize(position, mass, mode, name="H")
      @position = position
      @mass = mass
      @mode = mode
      @name = name
    end

    def positionPhase(phase, amplitude, shift=[0.0,0.0,0.0])
      displace = []
      @mode.each do |x|
        displace << (x * Complex.polar(1, phase)).image / Math.sqrt(@mass) * amplitude 
      end
      pos = []
      3.times do |i|
        pos << @position[i] + shift[i]
      end
      (Vector.elements(pos) + Vector.elements(displace)).to_a
    end
  end

  def eigenvalue(yaml)
    yaml.eigenvalueAtQ
  end

  def eigenvector(yaml)
    yaml.eigenvectorAtQ
  end

  def listBand(qNumber, eigenvector, eigenvalue)
    printf("# %4s %7s%9s  %9s%9s  %9s%9s\n\n", "atom", "x_real", "x_image", "y_real", "y_image", "z_real", "z_image")
    eigenvector[qNumber-1].each_with_index do |band, i|
      printf("# band: %4s   eigenvalue: %9.5f\n", i+1, eigenvalue[qNumber-1][i])
      band.each_with_index do |vec, j|
        printf("%-4s %9.5f%9.5f  %9.5f%9.5f  %9.5f%9.5f\n", j+1, vec[0].real, vec[0].image, vec[1].real, vec[1].image, vec[2].real, vec[2].image)
      end
      puts
    end
  end

  def listQposition(qposition)
    qposition.each_with_index do |vec, i|
      printf("%4s %9.5f%9.5f%9.5f\n", i+1, vec[0], vec[1], vec[2])
    end
  end

  def mass(yaml)
    yaml.mass
  end

  def name(yaml)
    yaml.name
  end

  def numAtom(yaml)
    yaml.numAtom
  end

  def phononMode(qNumber, band, yaml)
    eigenvector(yaml)[qNumber-1][band-1]
  end

  def position(yaml)
    yaml.position
  end

  def qposition(yaml)
    yaml.qposition
  end

  def realBasis(yaml)
    yaml.realBasis
  end

  def unitcell(axis, position, mass, mode, name)
    alpha, beta, gamma = Crystal.axisAngle(axis)
    cellA, cellB, cellC = Crystal.axisLength(axis)
    orientedAxis = Crystal.transform2axis(alpha, beta, gamma, cellA, cellB, cellC)
    atoms = []
    mass.size.times do |i|
      atoms << Atom.new(Matrix.rows(orientedAxis).transpose * Vector.elements(position[i]), mass[i], mode[i], name[i])
    end
    # atomic positions are supplied in Cartesian
    cell = Crystal::Cell.new(orientedAxis, atoms)
  end
end


