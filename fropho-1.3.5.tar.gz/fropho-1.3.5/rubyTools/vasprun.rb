#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html

require "rexml/document"

class ParseVasprun

  def initialize(filename)
    @doc = REXML::Document.new File.new(filename)
  end
  
  # return all basis through geometry optimization
  def basis
    basisArray = Array.new
    @doc.elements.each("modeling/calculation/structure/crystal/varray") do |elem|
      case elem.attributes["name"]
      when "basis"
        basis = Array.new
        elem.elements.each("v") do |relem|
          basisTmp = relem.text.strip.split(/\s+/)
          basis << [basisTmp[0].to_f, basisTmp[1].to_f, basisTmp[2].to_f]
        end
        basisArray << basis
      end
    end
    basisArray
  end

  # [kpoints][band][eigenvalue, occupancy]
  def eigenvalue
    array = Array.new
    @doc.elements.each("modeling/calculation/eigenvalues/array/set/set/set") do |elem|
      eigenvalues = Array.new
      elem.elements.each("r") do |velem|
        line = velem.text.strip.split(/\s+/)
        eigenvalues << [line[0].to_f, line[1].to_f]
      end
      array << eigenvalues
    end
    array
  end

  def name
    elements = Array.new
    @doc.elements.each("modeling/atominfo/array") do |elem|
      if elem.attributes["name"] == "atoms"
        elem.elements.each("set/rc") do |rcelem|
          elements << rcelem.elements["c"].text.strip
        end
      end
    end
    elements
  end

  # It's enthalpy when applying pressure with PSTRESS
  def energy
    energy = Array.new
    @doc.elements.each("modeling/calculation/energy/i") do |elem|
      case elem.attributes["name"]
      when "e_wo_entrp"
          energy << elem.text.strip.to_f
      end
    end
    energy
  end

  def force
    forceArray = Array.new
    @doc.elements.each("modeling/calculation/varray") do |elem|
      case elem.attributes["name"]
      when "forces"
        forces = Array.new
        elem.elements.each("v") do |velem|
          array = velem.text.strip.split
          forces << [array[0].to_f, array[1].to_f, array[2].to_f]
        end
        forceArray << forces
      end
    end
    forceArray
  end

  def kpoints
    array = Array.new
    @doc.elements.each("modeling/kpoints/varray") do |elem|
      case elem.attributes["name"]
      when "kpointlist"
        elem.elements.each("v") do |velem|
          kpt = velem.text.strip.split(/\s+/)
          array << [kpt[0].to_f,kpt[1].to_f,kpt[2].to_f]
        end
      end
    end
    array
  end

  # return all position through geometry optimization
  def position
    positionsArray = Array.new
    @doc.elements.each("modeling/calculation/structure/varray") do |elem|
      case elem.attributes["name"]
      when "positions"
        positions = Array.new
        elem.elements.each("v") do |velem|
          array = velem.text.strip.split
          positions << [array[0].to_f, array[1].to_f, array[2].to_f]
        end
        positionsArray << positions
      end
    end
    positionsArray
  end

  def recBasis
    recBasis = Array.new
    @doc.elements.each("modeling/structure") do |elem|
      case elem.attributes["name"]
      when "finalpos"
        elem.elements.each("crystal/varray") do |velem|
          case velem.attributes["name"]
          when "rec_basis"
            velem.elements.each("v") do |relem|
              recBasis = relem.text.strip.split(/\s+/)
              recBasis << [recBasis[0].to_f, recBasis[1].to_f, recBasis[2].to_f]
            end
          end
        end
      end
    end
    recBasis
  end

  def stress
    stressArray = Array.new
    @doc.elements.each("modeling/calculation/varray") do |elem|
      case elem.attributes["name"]
      when "stress"
        stresses = Array.new
        elem.elements.each("v") do |velem|
          array = velem.text.strip.split
          stresses << [array[0].to_f, array[1].to_f, array[2].to_f]
        end
        stressArray << stresses
      end
    end
    stressArray
  end

  def volume
    volume = 0
    @doc.elements.each("modeling/structure/crystal/i") do |elem|
      case elem.attributes["name"]
      when "volume"
        volume = elem.text.strip.to_f
      end
    end
    volume
  end

  def weights
    array  = Array.new
    @doc.elements.each("modeling/kpoints/varray") do |elem|
      case elem.attributes["name"]
      when "weights"
        elem.elements.each("v") {|velem| array << velem.text.strip.to_f}
      end
    end
    array
  end

end
