#!/usr/bin/env ruby

#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html

require 'poscar'
require 'phonModule'
require 'optparse'

DefaultDisplacement = 0.01

class Mkphon

  def initialize(dispfile, sposcarName, potcarName = "POTCAR")
    @sposcar = Vasp::Poscar.new(sposcarName, potcarName).cell
    @dispfile = dispfile
  end

  def setDispScale(a, b, c)
    @disp = []
    @disp << a
    @disp << b
    @disp << c
  end

  def start
    getDisp(@dispfile, getDispScaleReduced(@sposcar)).each_with_index do |elem, i|
      position = @sposcar.atoms[elem.number - 1].position
      initialPos = []
      position.each {|x| initialPos << x}  # back up initial position
      3.times {|j| position[j] += elem.disp[j]}
      Vasp::CellToPoscar.new(@sposcar).write("POSCAR-#{sprintf("%03d",i+1)}")
      @sposcar.atoms[elem.number - 1].position = initialPos                # return initial position
    end
  end

  private

  include Phon

  def getDispScaleReduced(cell)
    disp = []
    3.times {|i| disp << @disp[i] / cell.axisLength[i]}
    disp
  end

end

disp_a = DefaultDisplacement
disp_b = DefaultDisplacement
disp_c = DefaultDisplacement
zeroFile = ""

opt = OptionParser.new
opt.on('-a DISPLACEMENT', 'displacement quantity of a-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in a direction.")
    disp_a = x.to_f
  end
end
opt.on('-b DISPLACEMENT', 'displacement quantity of b-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in b direction.")
    disp_b = x.to_f
  end
end
opt.on('-c DISPLACEMENT', 'displacement quantity of c-axis') do |x|
  if x.to_f.abs > 0
    STDERR.print("Set displacement in c direction.")
    disp_c = x.to_f
  end
end

opt.parse!(ARGV)

def printUsage
  STDERR.print <<HERE
Usage: mkDisp.rb [OPTION] [DISP] [SPOSCAR] [POTCAR]
   POTCAR is not mandatory.
HERE
end

if ARGV[0] == nil or ARGV[1] == nil 
  printUsage; exit(0)
end

if ARGV[2] == nil
  mkphon = Mkphon.new(ARGV[0], ARGV[1])
else
  mkphon = Mkphon.new(ARGV[0], ARGV[1], ARGV[2])
end
mkphon.setDispScale(disp_a, disp_b, disp_c)
mkphon.start
