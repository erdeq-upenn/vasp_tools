#!/usr/bin/env ruby

# Time-stamp: <2008-04-06 15:00:26 togo>
#
# cleanCrystal.rb :  write gnuplot type bandstructure data
#
#   Copyright (C) 2006 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can edistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# usage: cleanCrystal [OPTIONS] [syminfo.yaml]
#

require 'yaml'
require 'optparse'
require 'matrix'
require 'poscar'
require 'syminfo'

class Vector
  def []=(i,x)
    @elements[i]=x
  end
end

module Bravais
  def checkBravais(metric, symprec)
    ortho, tetra, cubic = checkOrtho(metric, symprec)
    hexa = checkHexa(metric, symprec)
    rhombo, angle = checkRhombo(metric, symprec)

    label = "other"
    if cubic
      $stderr.puts "Bravais lattice --> cubic"
      label = "cubic"
    elsif rhombo
      $stderr.printf("Bravais lattice --> rhombohedral (angle %5.3f)\n", angle)
      label = "rhombo"
    elsif hexa
      $stderr.puts "Bravais lattice --> hexagonal"
      label = "hexa"
    elsif tetra
      $stderr.puts "Bravais lattice --> tetragonal"
      label = "tetra"
    elsif ortho
      $stderr.puts "Bravais lattice --> ortho"
      label = "ortho"
    end
    label
  end

  def checkOrtho(metric, symprec)
    ortho = tetra = cubic = false
    if  metric[0,1].abs < symprec and 
        metric[0,2].abs < symprec and
        metric[1,2].abs < symprec
      if (metric[0,0] - metric[1,1]).abs > symprec
        ortho = true
      elsif (metric[0,0] - metric[2,2]).abs > symprec
        tetra = true
      else
        cubic = true
      end
    end
    return ortho, tetra, cubic
  end

  def checkHexa(metric, symprec)
    if  (metric[0,1] / metric[0,0] + 0.5).abs < symprec and 
        metric[0,2].abs < symprec and
        metric[1,2].abs < symprec and
        (metric[0,0] - metric[1,1]).abs < symprec
      hexa = true
    else
      hexa = false
    end
    hexa
  end

  def checkRhombo(metric, symprec)
    average = (metric[0,0] + metric[1,1] + metric[2,2]) / 3.0
    gamma = metric[0,1] / average
    alpha = metric[1,2] / average
    beta = metric[2,0] / average
    if  (alpha - beta).abs < symprec and 
        (beta - gamma).abs < symprec and 
        (gamma - alpha).abs < symprec and 
        (metric[0,0] - metric[1,1]).abs < symprec and
        (metric[1,1] - metric[2,2]).abs < symprec and
        (metric[2,2] - metric[0,0]).abs < symprec
      rhombo = true
    else
      rhombo = false
    end
    angle = Math.acos((alpha + beta + gamma)/3) / Math::PI * 180
    return rhombo, angle
  end
end

module CleanCrystal
  def averageAxis(realBasis, operations, symprec, option)
    include Bravais

    axis = Matrix.rows(realBasis).transpose
    metric = axis.transpose * axis
    $stderr.puts "Metric tensor"
    metric.to_a.each do |row|
      $stderr.printf("[%7.3f,%7.3f,%7.3f]\n", row[0], row[1], row[2])
    end
    if option == "auto"
      bravais = checkBravais(metric, symprec)
    else
      bravais = option
    end
    case bravais
    when "ortho"
      newAxis = Matrix.zero(3)
      3.times do |i|
        newAxis[i,i] = Math.sqrt(metric[i,i])
      end
    when "tetra"
      newAxis = Matrix.scalar(3, Math.sqrt((metric[0,0]+metric[1,1])/2))
      newAxis[2,2] = axis[2,2]
    when "hexa"
      length = Math.sqrt((metric[0,0]+metric[1,1])/2)
      newAxis = Matrix.scalar(3, axis[2,2])
      newAxis[0,0] = length
      newAxis[1,1] = length * Math.sin(2*Math::PI/3)
      newAxis[1,0] = length * Math.cos(2*Math::PI/3)
    when "rhombo"
      length = Math.sqrt((metric[0,0]+metric[1,1]+metric[2,2])/3)
      cosval = (metric[0,1] + metric[1,2] + metric[2,0]) / ( 3 * length * length)
      ahex = 2 * length * Math.sin(Math.acos(cosval)/2)
      chex = length * Math.sqrt((3.0 * (1 + 2 * cosval)))
      a1 = [ahex/2, -ahex/(2.0 * Math.sqrt(3)), chex/3]
      a2 = [0, ahex/Math.sqrt(3), chex/3]
      a3 = [-ahex/2, -ahex/(2.0 * Math.sqrt(3)), chex/3]
      newAxis = Matrix[a1,a2,a3]
    when "cubic"
      newAxis = Matrix.scalar(3, Math.sqrt((metric[0,0]+metric[1,1]+metric[2,2])/3))
    else
      newAxis = axis.transpose
    end
    newAxis.to_a
  end

  def averagePosition(positions, operations, symprec)
    $stderr.puts "Translation list"
    averageVectors(positions, operations, symprec)
  end

  def averageVectors(vectors, operations, symprec)
    numElem = vectors.size
    newVectors = []
    numElem.times do |i|
      vecOuter = Vector.elements(vectors[i])
      sum = Vector[0.0, 0.0, 0.0]
      sentElems = []
      counter = 0
      numElem.times do |j|
        vecInner = Vector.elements(vectors[j])
        operations.each do |operation|
          rotatedVector = operation['rotation'] * vecInner + operation['translation']
          if reduce(rotatedVector - vecOuter).r < symprec
            sum += reduce(rotatedVector - vecOuter)
            counter += 1
            sentElems << (j + 1)
          end
        end
      end
      $stderr.print "[ "
      sentElems.each do |elem|
        $stderr.print "#{elem} "
      end
      $stderr.print "] --> #{i+1}\n"
      newVectors << (vecOuter + Vector[sum[0] / counter, sum[1] / counter, sum[2] / counter]).to_a
    end
    newVectors
  end

  def reduce(vector, decimal = 0.0)
    vec = []
    vector.to_a.each do |elem|
      vec << elem - (elem - decimal).round
    end
    Vector.elements(vec)
  end

  def swapAxes(swap, axis, positions)
    if swap
      positions.each do |pos|
        case swap
        when "ab", "ba"
          tmp = pos[0]
          pos[0] = pos[1]
          pos[1] = tmp
        when "bc", "cb"
          tmp = pos[1]
          pos[1] = pos[2]
          pos[2] = tmp
        when "ca", "ac" 
          tmp = pos[2]
          pos[2] = pos[0]
          pos[0] = tmp
        end
      end

      case swap
      when "ab", "ba"
        tmp = axis[0]
        axis[0] = axis[1]
        axis[1] = tmp
      when "bc", "cb"
        tmp = axis[1]
        axis[1] = axis[2]
        axis[2] = tmp
      when "ca", "ac" 
        tmp = axis[2]
        axis[2] = axis[0]
        axis[0] = tmp
      end
    end    

    return axis, positions
  end
end

def cleanCrystal(initialPositions, operations, initialAxis, atomType, center, shift, symprec, decimal, bravais, swap)
  include CleanCrystal

  # clean atomic positions
  $stderr.puts "--------------stderr--------------"
  positions = []
  newPositions = averagePosition(initialPositions, operations, symprec)
  newPositions.each do |pos|
    if center > 0
      posTemp = reduce(Vector.elements(pos) - Vector.elements(newPositions[center-1]) + shift)
    else
      posTemp = pos
    end
    position = []
    posTemp.to_a.each do |elem|
      if elem < - decimal
        position << elem + 1.0
      elsif elem > 1.0 - decimal
        position << elem - 1.0
      else
        position << elem
      end
    end
    3.times do |i|
      position[i] = (position[i] / decimal).round * decimal
    end
    positions << position
  end
  atoms = []

  # clean axes
  initialAxis, positions = swapAxes(swap, initialAxis, positions)

  # swap axes
  axis = averageAxis(initialAxis, operations, symprec, bravais)

  # create POSCAR
  positions.each do |pos|
    atoms << Vasp::Atom.new(pos, atomType.shift)
  end
  $stderr.puts "--------------stdout--------------"
  Crystal::Cell.new(axis, atoms)
end

def getConventional(cell, coordinate, symprec)
  tmpAtoms = []
  cell.atoms.each do |atom|
    2.times do |i|
      2.times do |j|
        2.times do |k|
          position = [atom.position[0] + i,
                      atom.position[1] + j,
                      atom.position[2] + k]
          position = (coordinate * Vector.elements(position)).to_a.collect do |x|
            x = x - x.round
          end
          tmpAtoms << Vasp::Atom.new(position, atom.name)
        end
      end
    end
  end

  atoms = []
  tmpAtoms.size.times do |i|
    flag = true
    ((i+1)..(tmpAtoms.size-1)).each do |j|
      if (tmpAtoms[i].position[0] - tmpAtoms[j].position[0]).abs < symprec and
          (tmpAtoms[i].position[1] - tmpAtoms[j].position[1]).abs < symprec and
          (tmpAtoms[i].position[2] - tmpAtoms[j].position[2]).abs < symprec
        flag = false
        break
      end
    end
    if flag
      atoms << tmpAtoms[i]
    end
  end
  Crystal::Cell.new((Matrix.rows(cell.axis).transpose*coordinate.inverse).transpose.to_a, atoms)
end


if __FILE__ == $0
  symprec = 1e-2
  decimal = 1e-16
  center = 0
  bravais = "other"
  conventional = false
  poscar = "POSCAR"
  poscarFlag = false
  primitive = false
  shift = Vector[0.0,0.0,0.0]
  swap = false
  xyz = false
  opt = OptionParser.new
  opt.on('--symprec=', 'symmetry check accuracy') do |tmp|
    symprec = tmp.to_f
  end
  opt.on('-d', '--decimal=', 'cutoff decimals') do |tmp|
    decimal = tmp.to_f
  end
  opt.on('-c', '--center=', 'atom number being at center') {|tmp| center = tmp.to_i}
  opt.on('-s', '--shift=', 'atomic position shift') do |tmp|
    tmp.split.each_with_index do |x, i|
      shift[i] = x.to_f
    end
  end
  opt.on('--conv', 'Recover conventional cell') {|conventional|}
  opt.on('--xyz', 'Print in XYZ') {|xyz|}
  opt.on('--swap=', 'Swap two axes') {|swap|}
  opt.on('--poscar=', 'POSCAR style file') {|poscar| poscarFlag = true}
  opt.on('-p', '--primitive', 'Use primitive symmetry information') {|primitive|}
  opt.on('-b', '--bravais=', '"auto", "cubic", "tetra", "othro", "hexa", "rhombo" and "other"(default)') {|bravais|}
  
  opt.parse!(ARGV)

  # The bravais and conv options can not be used simultaneously
  # because using these options simultaneously is misleading.
  if bravais != "other" and conventional
    $stderr.puts "--bravais and --conv can not be used simultaneously."
    exit(1)
  end

  

  if file = ARGV.shift
    symInfo = ParseSymInfo.new(file)
  else
    symInfo = ParseSymInfo.new("syminfo.yaml")
  end
  if primitive
    symInfo.primitive
  end

  # Squeeze translations to fractional values
  #  and make operations matrices and vectors
  # Squeezing asumes the supercell is enough small by 10 multiplicity.
  # A large supercell violates this assumption.
  if symInfo.spaceGroup
    squeeze = true
    $stderr.puts "Translation is forced into fractional value."
  else
    squeeze = false
  end
  operations = symInfo.operation.collect do |operation|
    translation = operation['translation'].collect do |elem|
      elem = elem - (elem - symprec).round
      if elem.abs > symprec
        tempInt = ( 1.0 / elem ).round
        if tempInt.abs < 100 and squeeze
          elem = 1.0 / tempInt
        end
      else
        elem = 0.0
      end
      elem
    end
    { 'rotation'    => Matrix.rows(operation['rotation']),
      'translation' => Vector.elements(translation)}
  end

  if !poscarFlag
    positions = symInfo.position
    axis = symInfo.realBasis
    atomType = symInfo.atomType
  else
    cell = Vasp::Poscar.new(poscar).cell
    positions = []
    atomType = []
    cell.atoms.each do |atom|
      positions << atom.position
      atomType << atom.name
    end
    axis = cell.axis
  end

  newCell = cleanCrystal(positions, operations, axis, atomType, center, shift, symprec, decimal, bravais, swap)

  if conventional
    newCell = getConventional(newCell, Matrix.rows(symInfo.coordinate), symprec)
  end
  
  if xyz
    Vasp::CellToPoscar.new(newCell).printXYZ
  else
    Vasp::CellToPoscar.new(newCell).print
  end
  
end
