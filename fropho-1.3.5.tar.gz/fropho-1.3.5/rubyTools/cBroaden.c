/* cBroaden.c : broaden discreate values by Gaussian function           */
/*                                                                      */
/*    Copyright (C) 2006 Atsushi Togo                                   */
/*    togo.atsushi@gmail.com                                            */
/*                                                                      */
/*    This program is free software; you can redistribute it and/or     */
/*    modify it under the terms of the GNU General Public License       */
/*    as published by the Free Software Foundation; either version 2    */
/*    of the License, or (at your option) any later version.            */
/*                                                                      */
/*    This program is distributed in the hope that it will be useful,   */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of    */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     */
/*    GNU General Public License for more details.                      */
/*                                                                      */
/*    You should have received a copy of the GNU General Public License */
/*    along with this program; if not, write to                         */
/*    the Free Software Foundation, Inc., 51 Franklin Street,           */
/*    Fifth Floor, Boston, MA 02110-1301, USA, or see                   */
/*    http://www.gnu.org/copyleft/gpl.html                              */
/*                                                                      */
/*  Atsushi Togo                                                        */
/*  Time-stamp: <2006-05-21 12:00:57 togo>                              */

#include <ruby.h>
#include <math.h>

double gaussian(double deviation, double sigma);

VALUE broaden(VALUE self, VALUE rsigma, VALUE renergy, VALUE num, VALUE reArray, VALUE rsArray){

	int i, numArray;
	double sigma, gauss;
	double sum = 0;

	numArray = NUM2INT(num);
	sigma = NUM2DBL(rsigma);

	double eArray[numArray], sArray[numArray];

	for (i=0; i<numArray; i++){
	  gauss = gaussian(NUM2DBL(rb_ary_entry(reArray, i)) - NUM2DBL(renergy), sigma) * NUM2DBL(rb_ary_entry(rsArray, i));
	  sum += gauss;
	}

	return rb_float_new(sum);
}

double gaussian(double deviation, double sigma){
	double pi = 3.14159265358979;
	return 1.0 / sigma / sqrt(2.0*pi) * exp(-deviation*deviation / (2.0*sigma*sigma));
}

void Init_cBroaden(void){
	VALUE rb_broaden;

	rb_broaden = rb_define_module("CBroaden");
	rb_define_module_function(rb_broaden, "cBroaden", broaden, 5);
}
