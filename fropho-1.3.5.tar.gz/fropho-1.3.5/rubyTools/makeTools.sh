#!/bin/sh

echo 'Make sure to set RUBYLIB.'
echo '   export RUBYLIB=your_rubyTools_directory'
echo
# cBroaden.so
echo 'Making cBroaden.so. This is the module library for yaml2dos.rb.'
echo 'Ruby developping environment is required.'
ruby ./extconf_cBroaden.rb
make
# cThermalProperty.so
echo
echo 'Making cThermalProperty.so. This is the module library for yaml2property.rb.'
echo 'Ruby developping environment is required.'
ruby ./extconf_cThermalProperty.rb
make
