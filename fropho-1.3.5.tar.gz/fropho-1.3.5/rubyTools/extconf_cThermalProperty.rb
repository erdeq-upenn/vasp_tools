require "mkmf"
create_makefile("thermal_property")
