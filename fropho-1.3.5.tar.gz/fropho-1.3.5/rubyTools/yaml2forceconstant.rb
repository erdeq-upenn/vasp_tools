#!/usr/bin/env ruby

# yaml2forceconstant.rb :  write gnuplot type force constants vs distance
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
# Time-stamp: <2006-05-21 12:01:25 togo>
#
# usage: yaml2forceconstant.rb [YAML-FILE] [SPOSCAR]
#
# gnuplot : Following "plot.dat" file is standard output of this script.
# echo 'p "plot.dat" index 0 w l, "plot.dat" index 1 using 3:($4*100) w imp'|gnuplot -persist

require 'optparse'
require 'matrix'
require 'frophorun'
require 'poscar'
require 'cBroaden.so'

class Yaml2forceconstant

  include CBroaden

  def initialize(yamlfile = "frophorun.yaml")
    yamlfile = "frophorun.yaml" if yamlfile == nil
    yaml = ParseYaml.new(yamlfile)
    @sposcar, @forceConstant = yaml.forceConstant
    @numPrimitiveAtom = yaml.numAtom
  end

  def broaden
    plus = []
    minus = []
    @forceConstant.each do |elem|
      num1, num2 = elem.supercell
      distance = @sposcar.minDistance(num1 - 1, num2 - 1)
      elem.matrix.each do |row|
        row.each do |a|
          plus << [distance, a] if a > 0
          minus << [distance, a] if a < 0
        end
      end
    end
    puts "# plus"
    broadening(0.1, 0.01, plus).each do |distance, val|
      print "#{distance} #{val}\n"
    end
    puts
    puts "# minus"
    broadening(0.1, 0.01, minus).each do |distance, val|
      print "#{distance} #{val}\n"
    end
  end

  def points
    array = Array.new
    @numPrimitiveAtom.times {array << []}
    printf("#%4s %4s %12s %14s\n", "pos1", "pos2", "distance  ", "force-constant")
    @forceConstant.each do |elem|
      num1, num2 = elem.supercell
      distance = @sposcar.minDistance(num1 - 1, num2 - 1)
      matrix = elem.matrix
      array[elem.unitcell - 1] << {"num1" => num1, "num2" => num2, "distance" => distance, "matrix" => matrix}
    end
    array.each do |arrayAtom|
      arrayAtom.each do |elem|
        elem['matrix'].each_with_index do |row, i|
          row.each_with_index do |a, j|
            printf("%4d %4d %12.8f %14.8f (a%1d%1d)\n", elem['num1'], elem['num2'], elem['distance'], a, i+1, j+1)
          end
        end
      end
      print "\n\n"
    end
  end


  private

  def broadening(sigma, dd, array)
    distances = []
    elements = []
    array.each do |distance, elem|
      distances << distance
      elements << elem
    end
    plot = []
    distance = - 6 * sigma
    while distance < distances.sort[-1] + 3 * sigma + dd
      sumArray = Array.new
      STDERR.printf("distance:%19.10f\n", distance)
      plot << [distance, cBroaden(sigma, distance, distances.size, distances, elements)]
      distance += dd
    end
    plot
  end
end


if __FILE__ == $0
  broadenFlag = false
  bothFlag = false
  opt = OptionParser.new
  opt.on('--broaden') {|broadenFlag|}
  opt.on('--both') {|bothFlag|}
  opt.parse!(ARGV)
  yaml = Yaml2forceconstant.new(ARGV.shift)
  yaml.broaden if broadenFlag or bothFlag
  print "\n\n" if bothFlag
  yaml.points if not broadenFlag
end
