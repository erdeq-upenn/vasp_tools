#!/usr/bin/env ruby

# Time-stamp: <2007-03-25 23:06:04 togo>
# yaml2band.rb :  write gnuplot type bandstructure data
#
#   Copyright (C) 2006 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
#
# usage: yaml2band.rb [OPTION] [YAML-FILE]
#     --factor
#
# for VASP
#     factor = 15.633 for THz (98.228/2pi)
#            = 521.47 for cm-1 (3276.5/2pi)


require 'optparse'
require 'matrix'
require 'frophorun'

class Yaml2band

  class Band
    attr_reader :frequency, :qposition
    def initialize(frequency, qposition)
      @frequency = frequency
      @qposition = qposition
    end
  end

  class BandPm3d
    attr_reader :frequency, :qposition, :eVec
    def initialize(frequency, qposition, eigenvector)
      @frequency = frequency
      @qposition = qposition
      @eVec = eigenvector
    end
  end

  def initialize(filename, factor)
    if filename == nil
      filename = "frophorun.yaml"
    end
    @yaml = ParseYaml.new(filename)
    @natom = @yaml.numAtom
    @recbasis = Matrix.rows(@yaml.recBasis).transpose
    @factor = factor
    @qposition = Array.new
    @yaml.qposition.each {|vec| @qposition << Vector.elements(vec)}
    @frequencies = @yaml.frequency
    @pm3d = false
  end

  def printBand
    @band = sortByBand
    @band.each do |band|
      qpointPrev = band.shift
      distance = 0.0
      printf("%f   %f   %f %f %f ", 0.0, qpointPrev.frequency, qpointPrev.qposition[0], qpointPrev.qposition[1], qpointPrev.qposition[2])
      print "\n"
      band.each do |qpoint|
        distance += (@recbasis * (qpoint.qposition - qpointPrev.qposition)).r
        printf("%f   %f   %f %f %f ", distance, qpoint.frequency, qpoint.qposition[0], qpoint.qposition[1], qpoint.qposition[2])
        print "\n"
        qpointPrev = qpoint
      end
      print "\n\n"
    end
  end

  def printBandPm3d
    @pm3d = true
    @eigenvector = @yaml.eigenvector
    @band = sortByBand
    @band.each do |band|
      band0 = band.shift
      2.times do |i|
        band.unshift(band0)
        qpointPrev = band.shift
        distance = 0.0
        printf("%f   %f   %f %f %f ", 0.0, qpointPrev.frequency + 0.01 * i * @factor, qpointPrev.qposition[0], qpointPrev.qposition[1], qpointPrev.qposition[2])
        printEVec(qpointPrev.eVec)
        print "\n"
        band.each do |qpoint|

          printf("%f   %f   %f %f %f ", distance, qpointPrev.frequency + 0.01 * i * @factor, qpointPrev.qposition[0], qpointPrev.qposition[1], qpointPrev.qposition[2])
          printEVec(qpoint.eVec)
          print "\n"

          distance += (@recbasis * (qpoint.qposition - qpointPrev.qposition)).r
          printf("%f   %f   %f %f %f ", distance, qpoint.frequency + 0.01 * i * @factor, qpoint.qposition[0], qpoint.qposition[1], qpoint.qposition[2])
          printEVec(qpoint.eVec)
          print "\n"

          qpointPrev = qpoint
        end
        print "\n"
      end
      print "\n\n"
    end
  end

  private

  def printEVec(eVec)
    eVec.each do |atom|
      sum = 0.0
      atom.each do |elem|
        sum += elem.abs2
      end
      printf("%f ", sum)
    end
  end

  def sortByBand
    band = Array.new(@natom * 3, Array.new)
    @qposition.each do |qpoint|
      (@natom * 3).times do |j|
        if @pm3d
          band[j] += [BandPm3d.new(@frequencies.shift * @factor, qpoint, @eigenvector.shift)]
        else
          band[j] += [Band.new(@frequencies.shift * @factor, qpoint)]
        end
      end
    end
    band
  end

end


if __FILE__ == $0

  factor = 1.0
  pm3d = false
  opt = OptionParser.new
  opt.on('--pm3d') do |pm3d|
    if pm3d
      STDERR.print "Set pm3d.\n"
    end
  end
  opt.on('--factor=unit conversion factor') do |factorTmp|
    if (factorTmp.to_f > 0)
      factor = factorTmp.to_f
      STDERR.printf("Set factor to %f.\n", factor) 
    end
  end

  opt.parse!(ARGV)

  yaml = Yaml2band.new(ARGV.shift, factor)
  if pm3d
    yaml.printBandPm3d
  else
    yaml.printBand
  end
end
