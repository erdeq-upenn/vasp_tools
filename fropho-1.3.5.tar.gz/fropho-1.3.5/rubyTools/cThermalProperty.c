/* cThermalProperty.c : calculate thermal properties
/*                                                                      */
/*    Copyright (C) 2006 Atsushi Togo                                   */
/*    togo.atsushi@gmail.com                                            */
/*                                                                      */
/*    This program is free software; you can redistribute it and/or     */
/*    modify it under the terms of the GNU General Public License       */
/*    as published by the Free Software Foundation; either version 2    */
/*    of the License, or (at your option) any later version.            */
/*                                                                      */
/*    This program is distributed in the hope that it will be useful,   */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of    */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     */
/*    GNU General Public License for more details.                      */
/*                                                                      */
/*    You should have received a copy of the GNU General Public License */
/*    along with this program; if not, write to                         */
/*    the Free Software Foundation, Inc., 51 Franklin Street,           */
/*    Fifth Floor, Boston, MA 02110-1301, USA, or see                   */
/*    http://www.gnu.org/copyleft/gpl.html                              */
/*                                                                      */
/*  Atsushi Togo                                                        */
/*  Time-stamp: <2006-05-21 12:00:57 togo>                              */

#define KB 8.61733e-5 /* Boltzmann constant */

#include <ruby.h>
#include <math.h>

double free_energy_omega(double temperature, double omega);
double entropy_omega(double temperature, double omega);
double cv_omega(double temperature, double omega);
double wrapper(VALUE self, VALUE rtemperature, VALUE rnum_sigma, VALUE rsigma, int key);

double free_energy_omega(double temperature, double omega){
  /* temperature is defined by T (K) */
  /* omega must be normalized to eV. */
  return KB * temperature * log(1 - exp(- omega / (KB * temperature)));
}

double entropy_omega(double temperature, double omega){
  /* temperature is defined by T (K) */
  /* omega must be normalized to eV. */
  double val;

  val = omega / (2 * KB * temperature);
  return 1 / (2 * temperature) * omega * cosh(val) / sinh(val) - KB * log(2 * sinh(val));
}

double cv_omega(double temperature, double omega){
  /* temperature is defined by T (K) */
  /* omega must be normalized to eV. */
  double val, pow1, pow2;

  val = exp(omega / (KB * temperature));
  pow1 = omega / (KB * temperature);
  pow2 = val - 1;
  return KB * pow1 * pow1 * val / (pow2 * pow2);
}

double wrapper(VALUE self, VALUE rtemperature, VALUE rnum_sigma, VALUE rsigma, int key){
  int i, num_sigma;
  double temperature;
  double sum = 0;
  double sigma[num_sigma];
  
  num_sigma = NUM2INT(rnum_sigma);
  temperature = NUM2DBL(rtemperature);

    switch(key) {
    case 0:
      for (i=0; i < num_sigma; i++){
	sum += free_energy_omega(temperature, NUM2DBL(rb_ary_entry(rsigma, i)));
      }
      break;
    case 1:
      for (i=0; i < num_sigma; i++){
	sum += entropy_omega(temperature, NUM2DBL(rb_ary_entry(rsigma, i)));
      }
      break;
    case 2:
      for (i=0; i < num_sigma; i++){
	sum += cv_omega(temperature, NUM2DBL(rb_ary_entry(rsigma, i)));
      }
      break;
    }

  return rb_float_new(sum);
}

VALUE free_energy(VALUE self, VALUE rtemperature, VALUE rnum_sigma, VALUE rsigma){
  return wrapper(self, rtemperature, rnum_sigma, rsigma, 0);
}

VALUE entropy(VALUE self, VALUE rtemperature, VALUE rnum_sigma, VALUE rsigma){
  return wrapper(self, rtemperature, rnum_sigma, rsigma, 1);
}

VALUE cv(VALUE self, VALUE rtemperature, VALUE rnum_sigma, VALUE rsigma){
  return wrapper(self, rtemperature, rnum_sigma, rsigma, 2);
}

void Init_thermal_property(void){
  VALUE rb_thermal_property;

  rb_thermal_property = rb_define_module("ThermalProperty");
  rb_define_module_function(rb_thermal_property, "free_energy", free_energy, 3);
  rb_define_module_function(rb_thermal_property, "entropy", entropy, 3);
  rb_define_module_function(rb_thermal_property, "cv", cv, 3);
}
