#!/usr/bin/env ruby

class DosCombine

  def initialize
    @columns = 0
    @freq = Array.new
    File.open(ARGV[0]) do |file|
      while line = file.gets
        line.strip!
        next if line == ""
        next if /^#/ =~ line
        @freq << line.strip.split[0].to_f
        @columns = line.strip.split.size - 1
      end
    end
    @lines = @freq.size

    @dos = Array.new
    @lines.times {@dos << Array.new(@columns, 0.0)}

    STDERR.print "lines:#{@lines}, columns:#{@columns}\n"

    ARGV.each do |filename|
      File.open(filename) do |file|
        lines = 0
        while line = file.gets
          line.strip!
          next if line == ""
          next if /^#/ =~ line
          lineArray = line.strip.split
          tmpArray = Array.new
          lineArray.each do |val|
            tmpArray << val.to_f
          end
          @columns.times do |i|
            @dos[lines][i] += tmpArray[i + 1]
          end
          lines += 1
        end
      end
    end
  end

  def printGnuplot
    @lines.times do |i|
      printf("%10.5f  ", @freq[i])
      @columns.times do |j|
        printf("%10.5f  ", @dos[i][j])
      end
      print "\n"
    end
  end
end

dosCombine = DosCombine.new
dosCombine.printGnuplot
