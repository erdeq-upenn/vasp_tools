#!/usr/bin/env ruby

# yaml2dos.rb :  write gnuplot type pdos data
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Atsushi Togo
# Time-stamp: <2006-05-21 12:01:25 togo>
#
# usage: yaml2dos.rb [OPTION] [YAML-FILE]
#     --total    total DOS
#     --partial  partial DOS
#     --xyz      partial DOS projected onto Cartesian
#     --sigma
#     --delta
#     --factor
#
# for VASP
#     factor = 15.633 for THz (98.228/2pi)
#            = 521.47 for cm-1 (3276.5/2pi)


require 'optparse'

# class for gaussian broadening

require 'cBroaden.so'
require 'frophorun'

class Broadening

  include CBroaden
  # array << [eigenvalue, value, value ,,,, (number of values are arbitrary. )]

  attr_writer :maxEnergy, :minEnergy

  def initialize(array, dE, sigma = 0.1)

    @dE = dE
    @sigma = sigma
    @numEnergies = array.size
    @numValues = array[0].size - 1
    @energies = Array.new
    @states = Array.new
    @dos = Array.new
    
    @numEnergies.times {|i| @energies << array[i][0]}
    
    @numValues.times do |i|
      tmpArr = Array.new
      @numEnergies.times {|j| tmpArr << array[j][i+1]}
      @states << tmpArr
    end

    @maxEnergy = @energies[-1] + 3 * @sigma
    @minEnergy = @energies[0] - 3 * @sigma
  end

  def getDos
    broadening
    @dos
  end

  private

  def broadening
    energy = @minEnergy
    while @maxEnergy + @dE / 100 > energy
      sumArray = Array.new(@numValues, 0)
      STDERR.printf("eigenvalue:%19.10f\n", energy)
      @numValues.times do |j|
        sumArray[j] = cBroaden(@sigma, energy, @numEnergies, @energies, @states[j])
      end
      @dos << [energy] + sumArray
      energy += @dE
    end
  end
end

# class for yaml to dos
class Yaml2dos


  def initialize(filename, factor, maxFreq, minFreq)
    if filename == nil
      filename = "frophorun.yaml"
    end
    @yaml = ParseYaml.new(filename)
    @natom = @yaml.numAtom
    @nqpoint = @yaml.numQpoint
    @factor = factor
    @maxFreq = maxFreq
    @minFreq = minFreq
  end

  def totalDos(sigma, dFreq)
    @states = Array.new
    @sigma = sigma
    @dFreq = dFreq
    @yaml.frequency.each do |eigenvalue|
      @states << [eigenvalue * @factor, 1.0 / @nqpoint]
    end
    broadening
    printTotalGnuplot
  end

  def partialDos(sigma, dFreq)
    eigenvalue = @yaml.frequency
    @states = Array.new
    @sigma = sigma
    @dFreq = dFreq
    @yaml.eigenvector.each do |eig|
      state = Array.new
      state << (eigenvalue.shift) * @factor
      eig.each do |atom|
        sum = 0.0
        atom.each do |elem|
          sum += elem.abs2
        end
        state << sum / @nqpoint
      end
      @states << state
    end
    STDERR.print "Broadening...\n"
    broadening
    printPartialGnuplot
  end

  def xyzDos(sigma, dFreq)
    eigenvalue = @yaml.frequency
    @states = Array.new
    @sigma = sigma
    @dFreq = dFreq
    @yaml.eigenvector.each do |eig|
      state = Array.new
      state << (eigenvalue.shift) * @factor
      eig.each do |atom|
        atom.each do |elem|
          state << elem.abs2 / @nqpoint
        end
      end
      @states << state
    end
    STDERR.print "Broadening...\n"
    broadening
    printPartialGnuplot
  end

  # check if eigenvectors are correct (sum should be 1)
  def checkSum
    vector = @yaml.eigenvector
    count = 0
    vector.each do |eig|
      sum = 0.0
      eig.each do |atom|
        atom.each do |elem|
          sum += elem.abs2
        end
      end 
      count += 1
      print("num:#{count} sum:#{sum}\n")
    end
  end

  private

  def broadening
    dos = Broadening.new(@states.sort, @dFreq, @sigma)
    dos.maxEnergy = @maxFreq if @maxFreq
    dos.minEnergy = @minFreq if @minFreq
    @dos = dos.getDos
  end

  def printTotalGnuplot
    print("# energy  DOS\n")
    @dos.each do |energy|
      printf("%19.10f %19.10f\n",energy[0] ,energy[1])
    end
  end

  def printPartialGnuplot
    print("# energy  DOS\n")
    @dos.each do |states|
      states.each do |val|
        printf("%19.10f ", val)
      end 
      print "\n"
    end
  end
end


if __FILE__ == $0

  totalDosFlag = true
  partialDosFlag = false
  xyzDosFlag = false
  sigma = 0.01
  dFreq = 0.01
  factor = 1.0
  minFreq = nil
  maxFreq = nil
  opt = OptionParser.new
  opt.on('--total') {|totalDosFlag| STDERR.print("Set total DOS.\n") if totalDosFlag }
  opt.on('--partial') {|partialDosFlag| STDERR.print("Set partial DOS.\n") if partialDosFlag }
  opt.on('--xyz') {|xyzDosFlag| STDERR.print("Set partial DOS projected onto xyz.\n") if xyzDosFlag }
  opt.on('--sigma=sigma') do |sigmaTmp|
    if (sigmaTmp.to_f > 0)
      sigma = sigmaTmp.to_f
      STDERR.printf("Set sigma to %f.\n", sigma) 
    end
  end
  opt.on('--delta=delta frequeqncy') do |dFreqTmp|
    if (dFreqTmp.to_f > 0)
      dFreq = dFreqTmp.to_f
      STDERR.printf("Set delta frequency to %f.\n", dFreq) 
    end
  end
  opt.on('--factor=unit conversion factor') do |factorTmp|
    if (factorTmp.to_f > 0)
      factor = factorTmp.to_f
      STDERR.printf("Set factor to %f.\n", factor) 
    end
  end
  opt.on('--minFreq=minimum frequency') do |minFreqTmp|
    if (minFreqTmp)
      minFreq = minFreqTmp.to_f
      STDERR.printf("Set minimum frequency to %f.\n", minFreq) 
    end
  end
  opt.on('--maxFreq=maximum frequency') do |maxFreqTmp|
    if (maxFreqTmp)
      maxFreq = maxFreqTmp.to_f
      STDERR.printf("Set maximum frequency to %f.\n", maxFreq) 
    end
  end

  opt.parse!(ARGV)

  yaml = Yaml2dos.new(ARGV.shift, factor, maxFreq, minFreq)
  if xyzDosFlag
    yaml.xyzDos(sigma, dFreq)
  elsif partialDosFlag
    yaml.partialDos(sigma, dFreq)
  elsif totalDosFlag
    yaml.totalDos(sigma, dFreq)
  end

end
