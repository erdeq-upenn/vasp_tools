#!/usr/bin/env ruby

# Time-stamp: <2009-05-18 12:31:25 togo>
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# mode2anime : Create an animation file in BIOSYM and Xcrysden style,
#              and create snapshot in POSCAR
#              Currently, only Gamma point is supported.

require 'vasprun'
require 'frophorun'
require 'optparse'
require 'matrix'
require 'poscar'
require 'phononModeModule'

#
# Xcrysden
#
module Xcrysden
  def xsfHeader(steps)
    puts "ANIMSTEPS #{steps}"
    puts "CRYSTAL"
  end

  def printOneXsf(cell, theta, counter, shift, amplitude)
    puts "PRIMVEC #{counter}"
    cell.axis.each do |vec|
      printf("%15.8f%15.8f%15.8f\n", vec[0], vec[1], vec[2])
    end
    puts "PRIMCOORD #{counter}"
    puts "#{cell.atoms.size} 1"
    cell.atoms.each do |atom|
      pos = atom.positionPhase(theta, amplitude, shift)
      printf("%-2d%15.8f%15.8f%15.8f\n", AtomicNumber[atom.name], pos[0], pos[1], pos[2])
    end
  end

  def printXsfAnime(cell, division, repeat, shift, amplitude = 1)
    xsfHeader(division * repeat)
    repeat.times do |i|
      division.times do |j|
        printOneXsf(cell, Math::PI*2 / division * j, j + 1 + division * i, shift, amplitude)
      end
    end
  end
end

#
# BIOSYM
#
module Biosym
  def arcHeader(steps)
    puts "!BIOSYM archive 3"
    puts "PBC=ON"
  end

  def printArcAnime(cell, division, repeat, shift, amplitude = 1)
    arcHeader(division * repeat)
    repeat.times do |i|
      (division+1).times do |j|
        puts "                                                                        0.000000"
        puts "!DATE"
        printOneArc(cell, Math::PI*2 / division * j, shift, amplitude)
        puts "end"
        puts "end"
      end
    end
  end

  def printOneArc(cell, theta, shift, amplitude)
    axisLength = cell.axisLength
    printf("%-4s%10.4f%10.4f%10.4f", "PBC", axisLength[0], axisLength[1], axisLength[2])
    axisAngle = cell.axisAngle
    printf("%10.4f%10.4f%10.4f\n", axisAngle[0], axisAngle[1], axisAngle[2])
    cell.atoms.each_with_index do |atom, i|
      pos = atom.positionPhase(theta, amplitude, shift)
      printf("%-4s%15.9f%15.9f%15.9f CORE", atom.name, pos[0], pos[1], pos[2])
      printf("%5s%4s%4s%9.4f%5s\n", i+1, atom.name, atom.name, 0.0, i+1)
    end
  end
end

#
# snapshot with POSCAR
#
def snapshot2poscar(cell, theta, amplitude=1)
  newAtoms = []
  cell.atoms.each do |atom|
    position = (Matrix.rows(cell.axis).transpose.inverse * Vector.elements(atom.positionPhase(theta / 180 * Math::PI, amplitude))).to_a
    newAtoms << Vasp::Atom.new(position, atom.name)
  end
  newCell = Crystal::Cell.new(cell.axis, newAtoms, "Snapshot")
  Vasp::CellToPoscar.new(newCell).print
end

#
# run
#

include PhononMode
opt = OptionParser.new
qNumber = 1
band = 1
amplitude = 1.0
repeat = 1
division = 25
listQ = false
qpointAtBand = 0
theta = 0.0
shift = [0.0, 0.0, 0.0]
xsf = false
arc = false
snapshot = false
opt.on('--band=', 'band number') {|tmp| band = tmp.to_i}
opt.on('--qnum=', 'q-point number') {|tmp| qNumber = tmp.to_i}
opt.on('--amp=', 'vibration amplitude') {|tmp| amplitude = tmp.to_f}
opt.on('--division=', 'number of division per 2Pi') {|tmp| division = tmp.to_i}
opt.on('--repeat=', 'number of repetitiion') {|tmp| repeat = tmp.to_i}
opt.on('--lq', 'list q-points') {|listQ|}
opt.on('--lb=q-point', 'list bands at the q-point') {|tmp| qpointAtBand = tmp.to_i}
opt.on('--theta=', 'theta for snapshot in degree (in code, sin(theta))') {|tmp| theta = tmp.to_f}
opt.on('--shift=', 'shift of atomic position') {|tmp| shift = tmp.split.collect!{|x| x.to_f}}
opt.on('--snapshot', 'write snapshot in POSCAR style. theta, band, qnum and amplitude are required, too.') {|snapshot|}
opt.on('--xsf', 'Xcrysden style') {|xsf|}
opt.on('--arc', 'Biosym style') {|arc|}
opt.parse!(ARGV)

if file = ARGV.shift
  yaml = ParseYaml.new(file)
else
  yaml = ParseYaml.new("frophorun.yaml")
end

if listQ
  listQposition(qposition(yaml))
  exit(1)
elsif qpointAtBand > 0
  listBand(qpointAtBand, eigenvector(yaml), eigenvalue(yaml))
  exit(1)
end

cell = unitcell(realBasis(yaml), position(yaml), mass(yaml), phononMode(qNumber, band, yaml), name(yaml))
if snapshot
  snapshot2poscar(cell, theta, amplitude)
elsif xsf
  include Xcrysden
  printXsfAnime(cell, division, repeat, shift, amplitude)
else
  include Biosym
  printArcAnime(cell, division, repeat, shift, amplitude)
end

