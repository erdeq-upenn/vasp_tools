#!/usr/bin/env ruby

# Time-stamp: <2007-09-24 16:33:48 togo>
#
# overlapAtoms.rb :  Find equivalent atoms due to symmetry
#
#   Copyright (C) 2006 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can edistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# usage: equivalentAtoms.rb [OPTIONS] [syminfo.yaml]
#

require 'yaml'
require 'optparse'
require 'matrix'
require 'poscar'
require 'syminfo'

def getAtomName(symInfo)
  symInfo.name
end

def getOperation(symInfo)
  operations = []
  symInfo.operation.each do |operation|
    operations << {"rotation"=> Matrix.rows(operation['rotation']),
      "translation"=>Vector.elements(operation['translation'])}
  end
  operations
end

def getPosition(symInfo)
  positions = []
  symInfo.position.each do |position|
    positions << Vector.elements(position)
  end
  positions
end

# Find combinations  m_C_n  depth=m, array=[1..n]
def recursiveLoop(original, depth, result, combinations)
  reprica = original.dup
  original.each do |x|
    result << reprica.delete(x)

    if depth > 1
      recursiveLoop(reprica, depth - 1, result, combinations)
    else
      combinations << result.dup
    end
    result.pop
  end
end

def reduce(vector, decimal)
  vec = []
  vector.to_a.each do |elem|
    vec << elem - (elem - decimal).round
  end
  Vector.elements(vec)
end

def sentAtomList(symInfo, symprec, decimal)
  basis = Matrix.rows(symInfo.realBasis).transpose
  positions = getPosition(symInfo)
  operations = getOperation(symInfo)

  # create translation map among atoms
  lists = []
  operations.each do |operation|
    list = []
    positions.each do |posOuter|
      positions.each_with_index do |posInner, i|
        if reduce(operation['rotation'] * posOuter + operation['translation'] - posInner, decimal).r < symprec
          list << i
          break
        end
      end
    end
    lists << list
  end
  lists
end

def symInfoToCell(symInfo)
  basis = symInfo.realBasis
  positions = symInfo.position
  name = symInfo.name
  atoms = positions.collect {|pos| Vasp::Atom.new(pos, name.shift)}
  Crystal::Cell.new(basis, atoms)
end

if __FILE__ == $0
  symprec = 1e-2
  decimal = 1e-16
  primitive = false
  syminfoFile = false
  replaceFlag = false
  opt = OptionParser.new
  opt.on('-p', '--primitive', 'Use primitive symmetry information') {|primitive|}
  opt.on('--syminfo=', 'syminfo.yaml file') {|syminfoFile|}
  opt.on('-s', '--symprec=', 'Symmetry check precision') {|tmp| symprec = tmp.to_f}
  opt.on('-r', '--replace', 'Replace atoms (experimental)') {|replaceFlag|}
  opt.parse!(ARGV)

  if syminfoFile
    symInfo = ParseSymInfo.new(syminfoFile)
  else
    symInfo = ParseSymInfo.new("syminfo.yaml")
  end
  if primitive
    symInfo.primitive
  end

  names = getAtomName(symInfo)
  positions = symInfo.position
  lists = sentAtomList(symInfo, symprec, decimal)

  vlists = []
  lists[0].size.times do |i|
    vlist = []
    lists.size.times do |j|
      vlist << lists[j][i]
    end
    vlists << vlist.sort.uniq
  end

  puts "atom name : equiv-atoms : represented position of (atom number)"
  vlists.uniq.each_with_index do |vlist, i|
    printf(" %2s:", names[vlist[0]])
    vlist.each {|elem| printf("%3d ", elem + 1)}
    printf(": (%3d)", vlist[0]+1)
    positions[vlist[0]].each {|val| printf("%10.5f ", val)}
    puts
  end

  # This is the experimental procedure.
  # Atoms on equivalent sites are replaced by other atoms.
  # All combination is output as POSCARs.
  # Number of the equivalent cites or which sets are replaced, etc,
  # have to be indicated by ourselves.
  if replaceFlag
    combinations = []
    array = (0..6).collect {|x| x}
    result = []
    recursiveLoop(array, 2, result, combinations)
    
    NewAtomName = "Ca"
    basis = symInfo.realBasis
    combinations.each_with_index do |combi, i|
      names = getAtomName(symInfo)
      combi.each do |numList|
        vlists[numList].each do |numAtom|
          names[numAtom] = NewAtomName
        end
      end
      atoms = positions.collect {|pos| Vasp::Atom.new(pos, names.shift)}
      Vasp::CellToPoscar.new(Crystal::Cell.new(basis, atoms), ["Ca","Fe","S"]).write("POSCAR-#{i}")
    end
  end

end
