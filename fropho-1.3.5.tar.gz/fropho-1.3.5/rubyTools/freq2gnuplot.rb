#!/usr/bin/ruby
#
# freq2gnuplot.rb : convert frequency file of phonon analysis to gnuplot data
#
#   Copyright (C) 2005 Atsushi Togo
#   togo.atsushi@gmail.com
# 
#   This program is free software; you can redistribute it and/or
#   modify it under the terms of the GNU General Public License
#   as published by the Free Software Foundation; either version 2
#   of the License, or (at your option) any later version.
#   
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#   
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to
#   the Free Software Foundation, Inc., 51 Franklin Street,
#   Fifth Floor, Boston, MA 02110-1301, USA, or see
#   http://www.gnu.org/copyleft/gpl.html
#
# Usage: freq2gnuplot.rb [BAND] N
#   N = the number of phonon modes

require 'optparse'

class Freq2gnuplot

  def initialize(filename, number, factor = 1.0)
    @number = number.to_i
    @freq = Array.new
    @qvector = Array.new
    @factor = factor
    readFromFile(open(filename))
  end

  def output
    @freq[0].size.times do |i|
      @qvector.size.times do |j|
        printf("%f %f\n", @qvector[j], @freq[j][i] * @factor)
      end
      print "\n\n"
    end
  end

  private

  # read lines until the counter gets across @number
  def readFromFile(file)
    while freq = readAtQvector(file)
      @freq << freq
    end
  end

  def readAtQvector(file)
    # check whether EOF
    return nil if !(line = file.gets)

    # check comment line
    while (/^#/ =~ line.strip)
      line = file.gets
    end

    count = 0
    array = line.strip.split
    @qvector << array.shift.to_f

    freqArray = Array.new
    array.each do |freq|
      count += 1
      freqArray << freq.to_f
    end

    # break if the data is of one line
    return freqArray if count >= @number

    # continue if the data doesn't end in a line
    while line = file.gets.strip
      array = line.split
      array.each do |freq|
        count += 1
        freqArray << freq.to_f
      end
      break if count >= @number
    end

    freqArray
  end
end

def printUsage
  STDERR.print <<HERE
Usage: freq2gnuplot.rb [BAND] N
  N = the number of phonon modes
HERE
end

if ARGV[0] == nil or ARGV[1] == nil
printUsage; exit(0)
end

factor = 1.0
opt = OptionParser.new
opt.on('--factor[=unit conversion factor]') do |factorTmp|
  if (factorTmp.to_f > 0)
    factor = factorTmp.to_f
    STDERR.printf("Set factor to %f.\n", factor) 
  end
end

opt.parse!(ARGV)

freq2gnuplot = Freq2gnuplot.new(ARGV[0], ARGV[1], factor)
freq2gnuplot.output
