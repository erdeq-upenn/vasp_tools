def get_displacement_fractional(disp, cell_lengths, amplitude = 0.01):
  """
  Generate displacements in fractional coodinates.
  """
  # amplitude: Distance of displacement that is shared for each directions
  # disp[0:3] (numpy): Displacements as written in DISP file
  # cell_lengths[0:3] (numpy): Cell parameters a, b, and c
  return disp / cell_lengths * amplitude

