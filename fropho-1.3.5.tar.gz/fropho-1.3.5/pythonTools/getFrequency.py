#!/usr/bin/env python

import yaml
try:
    from yaml import CLoader as Loader
    from yaml import CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

import sys, math

string = open(sys.argv[1]).read()
data = yaml.load(string, Loader=Loader)

qpoints = data['phonon']
for qpt in qpoints:
	print '(%8.5f, %8.5f, %8.5f)' % (qpt['q-position'][0], qpt['q-position'][1], qpt['q-position'][2])
	for band in qpt['q-point']:
		frequency = band['frequency']
		print '%15.7f (cm-1), %15.7f (THz)' % (frequency*3276.5/(2*math.pi), frequency*98.228/(2*math.pi))
	print
