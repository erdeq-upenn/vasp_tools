#!/usr/bin/env python

import re
import sys
from numpy import *
import matplotlib.pyplot as plt

def run(file, style):
    plot_data(get_data(file), style)

def plot_data(data, style):
    num_column = data.shape[1]
    for i in range(1,num_column):
        plt.plot(data[:,0], data[:,i]*15.633, style)

def get_data(file):
    num_column = int(re.search('\d+', file.readline()).group()) + 1
    data = array([])
    for line in file:
        if not re.match('^#', line):
            data = append(data, array([float(elem) for elem in line.split()]))
    num_row = data.size / num_column
    return data.reshape(num_row, num_column)

run(open(sys.argv[1]), 'r-')
plt.show()
