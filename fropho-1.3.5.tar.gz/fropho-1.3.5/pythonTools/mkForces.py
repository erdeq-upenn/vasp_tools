#!/usr/bin/env python

from lxml import etree
from ASE import read_vasp
import sys, re
import numpy as npy
from math import sqrt
from disp import get_displacement_fractional


def mycmp(x, y):
  return cmp(x[0], y[0])

def read_disp(disp):
  data = []
  count = 0
  for line in disp:
    if line.strip() != '':
      a = line.split()
      data.append([int(a[0]), float(a[1]), float(a[2]), float(a[3]), count])
      count += 1
  return data

def read_vasprun(vasprun):
  for varray in vasprun.xpath('./calculation/varray'):
    if varray.attrib['name'] == 'forces':
      for v in varray.xpath('./v'):
        print v.text


#
# initialize
#
dispfile = open(sys.argv[1])
sposcar = read_vasp(sys.argv[2])

cell = sposcar.get_cell()
cell_lengths = npy.sqrt(npy.dot(cell, cell.transpose()).diagonal())
displacements = read_disp(dispfile)
displacements.sort(mycmp)

#
# FORCES is output to stdout.
#
print len(displacements)
for count, disp in enumerate(displacements):
  print >> sys.stderr, "%d (%d)" % (count+1, disp[4]+1),
  disp_fractional = get_displacement_fractional(npy.array([disp[1], disp[2], disp[3]]), cell_lengths)
  print "%-5d %15.10f %15.10f %15.10f" % ((disp[0],) + tuple(disp_fractional))
  vasprun = etree.parse(sys.argv[3+disp[4]])
  read_vasprun(vasprun)


