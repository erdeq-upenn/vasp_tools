#!/usr/bin/env perl
#Version 0.91
$Options::versionString='Version 0.91';

use FindBin qw($Bin);
use lib "$Bin";
use Vasp;
use Math::Trig;
$fact=180/pi;

@args=@ARGV;
@args>=1 || die "usage: cif2pos.pl <POSCAR>\n";
$inputfilename=$args[0];

while (<>) {
	$_ =~ s/^\s+//;
	@F = split(/\s+/,$_);
	if ($F[0] =~ /^_cell_length_a/) {
		@temp = split(/\(/,$F[1]);
		$box[0] = $temp[0];
	}
	if ($F[0] =~ /^_cell_length_b/) {
		@temp = split(/\(/,$F[1]);
		$box[1] = $temp[0];
	}
	if ($F[0] =~ /^_cell_length_c/) {
		@temp = split(/\(/,$F[1]);
		$box[2] = $temp[0];
	}
	if ($F[0] =~ /alpha/) {
		$ang[2] = $F[1];
	}
	if ($F[0] =~ /beta/) {
		$ang[1] = $F[1];
	}
	if ($F[0] =~ /gamma/) {
		$ang[0] = $F[1];
	}
	if (@F >= 6) {
		push(@atom_symbols, $F[1]);
		push(@coords,$F[3],$F[4],$F[5]);
	}
}
$scale = $box[0];
for($i=0;$i<3;$i++){
	$box[$i] = $box[$i]/$scale;
	$arad[$i]=$ang[$i]/$fact;
}

$orthogonal=($ang[0]==90 && $ang[1]==90 && $ang[2]==90)?1:0;
#if(!$orthogonal){print "non-orthogonal\n";} 
$v2[0]=$ang[0]==90?0:cos($arad[0]);
$v2[1]=$ang[0]==90?1:sin($arad[0]);
$v3[0]=$ang[1]==90?0:cos($arad[1]);
$v3[1]=($ang[1]==90 && $ang[2]==90)?0:(cos($arad[2])-$v2[0]*$v3[0])/$v2[1];
$v3[2]=sqrt(1.0-$v3[0]**2-$v3[1]**2);

$v2[0]*=$box[1];
$v2[1]*=$box[1];
$v3[0]*=$box[2];
$v3[1]*=$box[2];
$v3[2]*=$box[2];

$var = 0;
$count[$var] = 1;
$atom_types[$var] = $atom_symbols[0];
for ($i = 1; $i < @atom_symbols; $i++){
	if ($atom_symbols[$i] eq $atom_symbols[$i-1]){
		$count[$var] += 1;
	}else{
		$var += 1;
		$count[$var] = 1;
		$atom_types[$var] = $atom_symbols[$i];
	}
}
########################
# Write POSCAR
######################
@outfile = split(/\./,$inputfilename);
open(OUT, ">$outfile[0]");
print OUT ("@atom_types\n");
print OUT ($scale . "\n");
print OUT ("1.00000"."\t"."0.00000"."\t"." 0.00000\n");
print OUT ($v2[0]."\t".$v2[1]."\t"." 0.00000\n");
print OUT ($v3[0]."\t".$v3[1]."\t"." $v3[2]\n");
print OUT ("@count\n");
print OUT ("Selective Dynamics\n");
print OUT ("Direct\n");
$k = @coords / 3;
$j = 0;
for ($i = 0; $i < $k; $i++){
	print OUT ("$coords[$j]   $coords[$j+1]   $coords[$j+2]   ");
	print OUT ("T "."T "."T \n");
	$j = $j + 3;
}

