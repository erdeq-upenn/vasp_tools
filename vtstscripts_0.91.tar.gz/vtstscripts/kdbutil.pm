#===================================================================================================
#Version 0.91

package kdbutil;

#===================================================================================================
# Exports
#---------------------------------------------------------------------------------------------------

use Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(stdatStatus stdatQuality stdatBarrier stdatMin1 stdatMin2 crossProduct dotProduct);
push @EXPORT, qw(centerOnAtom clumpSelected clumpSelectedAroundSelected correlateCars);
push @EXPORT, qw(matchDescription correlateCarsSelected carDropAtom interCarDistanceTableNoBox);
push @EXPORT, qw(%covalentRadii %vdwRadii %NON_METALS %INVERSE_NON_METALS appendXYZ appendXYZs);
push @EXPORT, qw(rotatePointXYZ rotatePointAxis CarElementTable elementType);
push @EXPORT, qw(getProcessDirs kdbHome DirKar KarDir loadXYZ2CAR writeXYZ carElementCountHash);
push @EXPORT, qw(nthAtomElement centerOfMass carNumComponents carComponentCount nthAtomComponent);
push @EXPORT, qw(POSCAR_TOTAL_ATOMS @rotationVectors unitVector);


#===================================================================================================
# Imports
#---------------------------------------------------------------------------------------------------

use Storable qw(dclone);
use Carp;
use Vasp;

#===================================================================================================
# Constants
#---------------------------------------------------------------------------------------------------

# The indices of the read_poscar data format.
use constant POSCAR_COORDINATES      => 0;
use constant POSCAR_BASIS            => 1;
use constant POSCAR_LATTICE          => 2;
use constant POSCAR_NUM_ATOMS        => 3;
use constant POSCAR_TOTAL_ATOMS      => 4;
use constant POSCAR_SELECTIVE_FLAG   => 5;
use constant POSCAR_SELECTIVE        => 6;
use constant POSCAR_DESCRIPTION      => 7;

#===================================================================================================
# Data
#---------------------------------------------------------------------------------------------------

# A list of covalent radii.
our %covalentRadii = (Ac => 1.88, Ag => 1.59, Al => 1.35, Am => 1.51, Ar => 1.51, As => 1.21, At => 1.21, Au => 1.5, B => 0.83, Ba => 1.34, Be => 0.35, Bh => 1.5, Bi => 1.54, Bk => 1.54, Br => 1.21, C => 0.68, Ca => 0.99, Cd => 1.69, Ce => 1.83, Cf => 1.83, Cl => 0.99, Cm => 0.99, Co => 1.33, Cr => 1.35, Cs => 1.67, Cu => 1.52, Db => 1.5, Ds => 1.5, Dy => 1.75, Er => 1.73, Es => 1.5, Eu => 1.99, F => 0.64, Fe => 1.34, Fm => 1.5, Fr => 1.5, Ga => 1.22, Gd => 1.79, Ge => 1.17, H => 0.23, He => 1.5, Hf => 1.57, Hg => 1.7, Ho => 1.74, Hs => 1.5, I => 1.4, In => 1.63, Ir => 1.32, K => 1.33, Kr => 1.5, La => 1.87, Li => 0.68, Lr => 1.5, Lu => 1.72, Md => 1.5, Mg => 1.1, Mn => 1.35, Mo => 1.47, Mt => 1.5, N => 0.68, Na => 0.97, Nb => 1.48, Nd => 1.81, Ne => 1.5, Ni => 1.5, No => 1.5, Np => 1.55, O => 0.68, Os => 1.37, P => 1.05, Pa => 1.61, Pb => 1.54, Pd => 1.5, Pm => 1.8, Po => 1.68, Pr => 1.82, Pt => 1.5, Pu => 1.53, Ra => 1.9, Rb => 1.47, Re => 1.35, Rf => 1.5, Rh => 1.45, Rn => 1.5, Ru => 1.4, S => 1.02, Sb => 1.46, Sc => 1.44, Se => 1.22, Sg => 1.5, Si => 1.2, Sm => 1.8, Sn => 1.46, Sr => 1.12, Ta => 1.43, Tb => 1.76, Tc => 1.35, Te => 1.47, Th => 1.79, Ti => 1.47, Tl => 1.55, Tm => 1.72, U => 1.58, V => 1.33, W => 1.37, Xe => 1.5, Y => 1.78, Yb => 1.94, Zn => 1.45, Zr => 1.56);
our %vdwRadii = (Ac => 2, Ag => 1.72, Al => 2, Am => 2, Ar => 1.88, As => 1.85, At => 2, Au => 1.66, B => 2, Ba => 2, Be => 2, Bh => 2, Bi => 2, Bk => 2, Br => 1.85, C => 1.7, Ca => 2, Cd => 1.58, Ce => 2, Cf => 2, Cl => 1.75, Cm => 2, Co => 2, Cr => 2, Cs => 2, Cu => 1.4, Db => 2, Ds => 2, Dy => 2, Er => 2, Es => 2, Eu => 2, F => 1.47, Fe => 2, Fm => 2, Fr => 2, Ga => 1.87, Gd => 2, Ge => 2, H => 1.09, He => 1.4, Hf => 2, Hg => 1.55, Ho => 2, Hs => 2, I => 1.98, In => 1.93, Ir => 2, K => 2.75, Kr => 2.02, La => 2, Li => 1.82, Lr => 2, Lu => 2, Md => 2, Mg => 1.73, Mn => 2, Mo => 2, Mt => 2, N => 1.55, Na => 2.27, Nb => 2, Nd => 2, Ne => 1.54, Ni => 1.63, No => 2, Np => 2, O => 1.52, Os => 2, P => 1.8, Pa => 2, Pb => 2.02, Pd => 1.63, Pm => 2, Po => 2, Pr => 2, Pt => 1.72, Pu => 2, Ra => 2, Rb => 2, Re => 2, Rf => 2, Rh => 2, Rn => 2, Ru => 2, S => 1.8, Sb => 2, Sc => 2, Se => 1.9, Sg => 2, Si => 2.1, Sm => 2, Sn => 2.17, Sr => 2, Ta => 2, Tb => 2, Tc => 2, Te => 2.06, Th => 2, Ti => 2, Tl => 1.96, Tm => 2, U => 1.86, V => 2, W => 2, Xe => 2.16, Y => 2, Yb => 2, Zn => 1.39, Zr => 2);

 # A list of nonmetals and its inverse. 
our %NON_METALS = ('H' => 1, 'He' => 2, 'B' => 3, 'C' => 4, 'N' => 5, 'O' => 6, 'F' => 7, 'Ne' => 8, 'Si' => 9, 'P' => 10, 'S' => 11, 'Cl' => 12, 'Ar' => 13, 'As' => 14, 'Se' => 15, 'Br' => 16, 'Kr' => 17, 'Te' => 18, 'I' => 19, 'Xe' => 20, 'At' => 21, 'Rn' => 22);
our %INVERSE_NON_METALS = (1 => 'H', 2 => 'He', 3 => 'B', 4 => 'C', 5 => 'N', 6 => 'O', 7 => 'F', 8 => 'Ne', 9 => 'Si', 10 => 'P', 11 => 'S', 12 => 'Cl', 13 => 'Ar', 14 => 'As', 15 => 'Se', 16 => 'Br', 17 => 'Kr', 18 => 'Te', 19 => 'I', 20 => 'Xe', 21 => 'At', 22 => 'Rn');

#===================================================================================================
# Subroutine unitVector($data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    Returns a 3-component unit vector
#
#   INPUT:          $data: the vector to normalize
#
#   OUTPUT:         a unit vector
#---------------------------------------------------------------------------------------------------
    sub unitVector
    {
        my $data = shift;
        my @data = @$data;
        my $x = $data[0];
        my $y = $data[1];
        my $z = $data[2];
        my $mag = sqrt($x * $x + $y * $y + $z * $z);
        if($mag == 0)
        {
            confess "divide by zero imminent.";
        }
        $x /= $mag;
        $y /= $mag;
        $z /= $mag;
		return ($x, $y, $z);
    }


#===================================================================================================
# Subroutine rotatePointAxis(x, y, z, xa, ya, za, theta)
#---------------------------------------------------------------------------------------------------
#   Rotate a point (x, y, z) around the (xa, ya, za) axis by theta.
#---------------------------------------------------------------------------------------------------
    sub rotatePointAxis
    {
        my $x = shift;
        my $y = shift;
        my $z = shift;
        my $xa = shift;
        my $ya = shift;
        my $za = shift;
        my $theta = shift;
        my $magnitude = sqrt($xa*$xa + $ya*$ya + $za*$za);
        if($magnitude > 0)
        {
            $xa /= $magnitude;
            $ya /= $magnitude;
            $za /= $magnitude;
            my $t = 1.0 - cos($theta);
            my $c = cos($theta);
            my $s = sin($theta);
            my @R = ();
            $R[0][0] = $t * $xa*$xa + $c;
            $R[0][1] = $t * $xa * $ya + $s * $za;
            $R[0][2] = $t * $xa * $za - $s * $ya;
            $R[1][0] = $t * $xa * $ya - $s * $za;
            $R[1][1] = $t * $ya*$ya + $c;
            $R[1][2] = $t * $ya * $za + $s * $xa;
            $R[2][0] = $t * $xa * $za + $s * $ya;
            $R[2][1] = $t * $ya * $za - $s * $xa;
            $R[2][2] = $t * $za*$za + $c;
            my $xp = $R[0][0] * $x + $R[0][1] * $y + $R[0][2] * $z;
            my $yp = $R[1][0] * $x + $R[1][1] * $y + $R[1][2] * $z;
            my $zp = $R[2][0] * $x + $R[2][1] * $y + $R[2][2] * $z;
            return ($xp, $yp, $zp);
        }
        else
        {
            return ($x, $y, $z);
        }
    }

#===================================================================================================
# Subroutine rotatePointXYZ(x, y, z, phi, theta, psi)
#---------------------------------------------------------------------------------------------------
#   Rotate a point (x, y, z) around the X, then Y, then Z axes, by phi, theta, and psi, respectively.
#---------------------------------------------------------------------------------------------------
    sub rotatePointXYZ
    {
        my $x = shift;
        my $y = shift;
        my $z = shift;
        my $phi = shift;
        my $theta = shift;
        my $psi = shift;
        # Rotate around the x-axis.
        my $zp = $z * cos($phi) - $y * sin($phi);
        my $yp = $z * sin($phi) + $y * cos($phi);
        $z = $zp;
        $y = $yp;
        # Rotate around the y-axis.
        my $xp = $x * cos($theta) - $z * sin($theta);
        my $zp = $x * sin($theta) + $z * cos($theta);
        $z = $zp;
        $x = $xp;
        # Rotate around the z-axis.
        my $xp = $x * cos($psi) - $y * sin($psi);
        my $yp = $x * sin($psi) + $y * cos($psi);
        $x = $xp;
        $y = $yp;
        # Update the coordinates.
        return ($x, $y, $z);
    }
    
#===================================================================================================
# Subroutine crossProduct(a, b).
#---------------------------------------------------------------------------------------------------
#   Returns a 3D vector representing the cross product between vectors a and b.
#
#---------------------------------------------------------------------------------------------------
    sub crossProduct
    {
        my $a = shift;
        my @a = @$a;
        my $b = shift;
        my @b = @$b;
        return ($a[1] * $b[2] - $a[2] * $b[1], $a[2] * $b[0] - $a[0] * $b[2], $a[0] * $b[1] - $a[1] * $b[0]);
    }

#===================================================================================================
# Subroutine dotProduct(a, b).
#---------------------------------------------------------------------------------------------------
#   Returns the dot product between vectors a and b.
#
#---------------------------------------------------------------------------------------------------
    sub dotProduct
    {
        my $a = shift;
        my @a = @$a;
        my $b = shift;
        my @b = @$b;
        return $a[0] * $b[0] + $a[1] * $b[1] + $a[2] * $b[2];
    }

#===================================================================================================
# Subroutine interCarDistanceTable(data1, data2).
#---------------------------------------------------------------------------------------------------
#   Returns a 2D array of distances between atoms of 2 different POSCARS. $table[$j][$k] is the
#   distance between atom $j of data1 and atom $k of data2.
#
#---------------------------------------------------------------------------------------------------
    sub interCarDistanceTableNoBox
    {
        my $data1 = shift;
        my @data1 = @$data1;
        my $data2 = shift;
        my @data2 = @$data2;
        my @table = ();
        for(my $i = 0; $i < $data1[POSCAR_TOTAL_ATOMS]; $i++)
        {
            for(my $j = 0; $j < $data2[POSCAR_TOTAL_ATOMS]; $j++)
            {
                my $x = $data1[POSCAR_COORDINATES][$i][0] - $data2[POSCAR_COORDINATES][$j][0];
                my $y = $data1[POSCAR_COORDINATES][$i][1] - $data2[POSCAR_COORDINATES][$j][1];
                my $z = $data1[POSCAR_COORDINATES][$i][2] - $data2[POSCAR_COORDINATES][$j][2];
                $table[$i][$j] = sqrt($x*$x + $y*$y + $z*$z);
            }
        }
        return @table;
    }

#===================================================================================================
# Subroutine writeXYZ(data, fileName).
#---------------------------------------------------------------------------------------------------
#   Write out an xyz file of a config already in cartesian coordinates.
#
#---------------------------------------------------------------------------------------------------
    sub writeXYZ
    {
        my $data = shift;
        my @data = @$data;
        my $filename = shift;
        open (xyz, ">$filename");
        print xyz $data[POSCAR_TOTAL_ATOMS] . "\n";
        print xyz $data[POSCAR_DESCRIPTION] . "\n";
        for(my $a = 0; $a < $data[POSCAR_TOTAL_ATOMS]; $a++)
        {
            print xyz nthAtomElement($a, \@data) . " ";
            print xyz $data[POSCAR_COORDINATES][$a][0] . " ";
            print xyz $data[POSCAR_COORDINATES][$a][1] . " ";
            print xyz $data[POSCAR_COORDINATES][$a][2] . "\n";
        }
        close xyz;
    }

#===================================================================================================
# Subroutine appendXYZ(data, fileName).
#---------------------------------------------------------------------------------------------------
#   Append to an xyz file of a config already in cartesian coordinates.
#
#---------------------------------------------------------------------------------------------------
    sub appendXYZ
    {
        my $data = shift;
        my @data = @$data;
        my $filename = shift;
        open (xyz, ">>$filename");
        print xyz $data[POSCAR_TOTAL_ATOMS] . "\n";
        print xyz $data[POSCAR_DESCRIPTION] . "\n";
        for(my $a = 0; $a < $data[POSCAR_TOTAL_ATOMS]; $a++)
        {
            print xyz nthAtomElement($a, \@data) . " ";
            print xyz $data[POSCAR_COORDINATES][$a][0] . " ";
            print xyz $data[POSCAR_COORDINATES][$a][1] . " ";
            print xyz $data[POSCAR_COORDINATES][$a][2] . "\n";
        }
        close xyz;
    }

#===================================================================================================
# Subroutine appendXYZs(data, fileName, comment).
#---------------------------------------------------------------------------------------------------
#   Append to an xyz file of a config already in cartesian coordinates.
#
#---------------------------------------------------------------------------------------------------
    sub appendXYZs
    {
        ($data, $filename, $comment) = @_;
        @data = @$data;
        open (xyz, ">>$filename");
        $totalatoms = 0;
        for(my $i = 0; $i < @data; $i++)
        {
            $totalatoms += $data[i][POSCAR_TOTAL_ATOMS];
        }
        print xyz "$totalatoms\n";
        print xyz "$comment\n";
        for $dr (@data)
        {
            @d = @$dr;
            for(my $a = 0; $a < $d[POSCAR_TOTAL_ATOMS]; $a++)
            {
                print xyz nthAtomElement($a, \@d) . " ";
                print xyz $d[POSCAR_COORDINATES][$a][0] . " ";
                print xyz $d[POSCAR_COORDINATES][$a][1] . " ";
                print xyz $d[POSCAR_COORDINATES][$a][2] . "\n";
            }
        }
        close xyz;
    }

#===================================================================================================
# Subroutine carElementCountHash(@data)                                                             
#---------------------------------------------------------------------------------------------------
#   Returns a hash that contains each element of the poscar pointing to the number of atoms of that
#   element.
#
#---------------------------------------------------------------------------------------------------
    sub carElementCountHash
    {
        my $data = shift;
        my @data = @$data;
        my %hash = ();
        for(my $i = 0; $i < $data[POSCAR_TOTAL_ATOMS]; $i++)
        {
            my $e = nthAtomElement($i, \@data);
            if($hash{$e})
            {
                $hash{$e} += 1;
            }
            else
            {
                $hash{$e} = 1;
            }
        }
        return %hash;
    }

#===================================================================================================
# Subroutine carDropAtom(selected, data).
#---------------------------------------------------------------------------------------------------
#   Remove selected atom from a POSCAR.
#
#---------------------------------------------------------------------------------------------------
    sub carDropAtom
    {
        my $selected = shift;
        my $data = dclone(shift);
        my @data = @$data;
        my $component = nthAtomComponent($selected, \@data);
        my $element = nthAtomElement($selected, \@data);
        my @desc = carDescArray(\@data);
        # Fix the coords.
        splice(@{@data[POSCAR_COORDINATES]}, $selected, 1);
        # Fix the frozen atoms.
        splice(@{@data[POSCAR_SELECTIVE]}, $selected, 1);
        # Fix num_atoms.
        if(carComponentCount($component, \@data) <= 1)
        {
            # Remove the component.
            splice(@{$data[POSCAR_NUM_ATOMS]}, $component, 1);
            
            # Fix the desc.
            splice(@desc, $component, 1);
            $data[POSCAR_DESCRIPTION] = join(" ", @desc);
        }
        else
        {
            # Reduce the component count.
            $data[POSCAR_NUM_ATOMS][$component] -= 1;
        }
        # Reduce the total atom count.
        $data[POSCAR_TOTAL_ATOMS] -= 1;
        return @data;        
    }

#===================================================================================================
# Subroutine centerOfMass(data).
#---------------------------------------------------------------------------------------------------
#   Get the center of mass of all the atoms.
#
#---------------------------------------------------------------------------------------------------
    sub centerOfMass
    {
        my $data = shift;
        my @data = @$data;
        my $xTotal = 0;
        my $yTotal = 0;
        my $zTotal = 0;
        for(my $a = 0; $a < $data[POSCAR_TOTAL_ATOMS]; $a++)
        {
            $xTotal += $data[POSCAR_COORDINATES][$a][0];
            $yTotal += $data[POSCAR_COORDINATES][$a][1];
            $zTotal += $data[POSCAR_COORDINATES][$a][2];
        }
        my $x = $xTotal / $data[POSCAR_TOTAL_ATOMS];
        my $y = $yTotal / $data[POSCAR_TOTAL_ATOMS];
        my $z = $zTotal / $data[POSCAR_TOTAL_ATOMS];
        return ($x, $y, $z);
    }


#===================================================================================================
# Subroutine loadXYZ2CAR(fileName)
#---------------------------------------------------------------------------------------------------
#       Returns an XYZ loaded into POSCAR format.
#---------------------------------------------------------------------------------------------------
    sub loadXYZ2CAR
    {
        # The xyz file filename.
        my $fileName = shift;
        
        # Open the file and get the number of atoms and comment.
        open (XYZ, $fileName);
        my $numAtoms = <XYZ>; chomp $numAtoms;
        my $comment = <XYZ>; chomp $comment;
        
        # Create a square (cartesian) basis.
        my @basis = ([1, 0, 0], [0, 1, 0], [0, 0, 1]);

        # Get the atom type and coordinates.
        my @types = ();
        my @coordinates = ();
        for(my $i = 0; $i < $numAtoms; $i++)
        {
            my $line = <XYZ>;
            chomp $line;
            my @data = split(" ", $line);
            $types[$i] = $data[0];
            $coordinates[$i] = [$data[1], $data[2], $data[3]];
        }
    
        # Create a hash of atom types and the number of atoms of each.
        my %atomTypes = ();
        my $numAtomTypes = 0;
        for(my $i = 0; $i < $numAtoms; $i++)
        {
            if(!$atomTypes{$types[$i]})
            {
                $atomTypes{$types[$i]} = 1;
                $numAtomTypes++;
            }
            else
            {
                $atomTypes{$types[$i]}++;
            }
        }

        # Create an array containing unique descriptions, i.e., ['Cu', 'C', 'O', 'H'].
        my @descArray = ();
        foreach my $key(keys %atomTypes)
        {
            push @descArray, $key;
        }
        
        # Sort @descArray and store it in $desc.
        @descArray = sort @descArray;
        my $desc = join(" ", @descArray);
        
        # Create an array of the number of atoms of each element sorted by @descArray.
        my @numAtomsEachType = ();
        foreach my $type(@descArray)
        {
            push @numAtomsEachType, $atomTypes{$type};
        }
        
        # Sort the coordinates by $descArray and create a hash that points from the old atom number
        # to the new atom number.
        my @tempCoords = ();
        my $tempIndex = 0;
        my %switch = ();
        foreach my $type(@descArray)
        {
            for(my $i = 0; $i < $numAtoms; $i++)
            {
                if($types[$i] eq $type)
                {
                    push @tempCoords, $coordinates[$i];
                    $switch{$i} = $tempIndex;
                    $tempIndex++;
                }
            }
        }
        @coordinates = @tempCoords;
        
        # Fill selective array with zeros.
        my @selective = ();
        for(my $i = 0; $i < $numAtoms; $i++)
        {
            $selective[$i] = 0;
        }
            
        # Return the POSCAR array.
        return (\@coordinates, \@basis, 1.0, \@numAtomsEachType, $numAtoms, 0, \@selective, $desc, \%switch);
    }        

#===================================================================================================
# Subroutine kdbHome()
#---------------------------------------------------------------------------------------------------
#       Returns the directory. The environment variable VTST_KDB holds this if it is defined, 
#       otherwise the default of "userhome/kdb" is retured.
#---------------------------------------------------------------------------------------------------
    sub kdbHome
    {
        # If the VTST_KDB environment variable is not set, return the default (userhome/kdb).
        if (!$ENV{'VTST_KDB'}) 
        {
            my $userdir = $ENV{'HOME'};
            if(! -d "$userdir/kdb")
            {
                mkdir("$userdir/kdb", 0777);
            }
            return "$userdir/kdb";
        }
        # Otherwise, return the value of the VTST_KDB environment variable.
        else
        {
            return $ENV{'VTST_KDB'};
        }
    }
    
#===================================================================================================
# Subroutine getProcessDirs()
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    Get the list of kdb process subdirectories that match the global $Desc 
#                   description of the process we're trying to match.
#   INPUT:          The kdb directory (from kdbHome).
#                   The description string we are trying to match, i.e., "C Cu H O".
#   OUTPUT:         All matching directories.
#---------------------------------------------------------------------------------------------------
    sub getProcessDirs
    {
        my $kdbDir = shift;
        my $desc = shift;
        my @procDirs;
        my @allSystemDirs = glob("$kdbDir/*");
        foreach my $dir (@allSystemDirs) 
        {
            if(-d $dir)
            {
                if (matchDescription($desc, dir2desc($dir)))
                {
                    my $i = 0;
                    while (-e "$dir/$i")
                    {
                        push(@procDirs, "$dir/$i");
                        $i++;
                    }
                }
            }
        }
        return @procDirs;
    }

#===================================================================================================
# Subroutine dir2desc()
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    Converts kdb subdirectory into a description, e.g. "/kdb/C_Cu_H_O" returns 
#                   "C Cu H O"
#---------------------------------------------------------------------------------------------------
    sub dir2desc
    {
        my $desc = shift;
        $desc = substr($desc, rindex($desc, "/"));
        $desc =~ s/_/ /g;
        $desc =~ s#/##;
        return $desc;
    }

#===================================================================================================
# Subroutine elementType (desc)
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    Returns the atom type for nonmetals, and "Metal" for metals.
#
#---------------------------------------------------------------------------------------------------
    sub elementType
    {
        my $desc = shift;
        if($NON_METALS{$desc})
        {
            return $desc;
        }
        else
        {
            return "Metal";
        }
    }


#===================================================================================================
# Subroutine matchDescription (desc1, desc2)
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    Determines whether or not two kdb descriptions match according to 
#                   THE RULES.
#
#   INPUT:          Two strings representing kdb descriptions, i.e., ("H O C Ag", "H O C Cu")
#
#   OUTPUT:         A 1 or 0 representing true or false for a positive or negative match.
#
#   THE RULES:      The number of elements must be the same.
#                   The nonmetal elements must match in each description.
#---------------------------------------------------------------------------------------------------
    sub matchDescription
    {
        # Get the descriptions.
        my $desc1 = shift;
        my $desc2 = shift;
        # Get the individual elements.
        my @atoms1 = split(/ /, $desc1);
        my @atoms2 = split(/ /, $desc2);
        # Get the number of elements in each description.
        my $len1 = @atoms1;
        my $len2 = @atoms2;
        # If the number of elements does not match, return false (no match).
        if($len1 != $len2)
        {
            return 0;
        }
        # Store the elements inside a hash so that we can perform an array.contains() operation. 
        my %isAtoms1;
        my %isAtoms2;
        foreach(@atoms1)
        {
            $isAtoms1{$_} = 1;
        }
        foreach(@atoms2)
        {
            $isAtoms2{$_} = 1;
        }
        # Check to see if each nonmetal in desc1 matches a nonmetal in desc2.
        foreach(@atoms1)
        {
            if($NON_METALS{$_})
            {
                if(!$isAtoms2{$_})
                {
                    return 0;
                }
            }
        }
        # Check to see if each nonmetal in desc2 matches a nonmetal in desc1.
        # This is repeated in case there are more NonMetals in desc2 than in desc1.
        foreach(@atoms2)
        {
            if($NON_METALS{$_})
            {
                if(!$isAtoms1{$_})
                {
                    return 0;
                }
            }
        }
        # Return true (successful match).
        return 1;
    }

#===================================================================================================
# Subroutine CarElementTable(@data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns an array where the nth element is the element of atom n.
#
#   INPUT:          @data: the data list from the read_poscar
#
#   OUTPUT:         I already told you. 
#---------------------------------------------------------------------------------------------------
    sub CarElementTable
    {
        my $data = shift;
        my @data = @$data;
        my @table = ();
        for(my $i = 0; $i < $data[4]; $i++)
        {
            push(@table, nthAtomElement($i, \@data));
        }
        return @table;
    }

#===================================================================================================
# Subroutine nthAtomElement($a, $data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns the nth atom element name from a read_poscar data 
#                   structure.
#
#   INPUT:          $a: the integer representing the atom desired
#                   $data: the data list from the read_poscar
#
#   OUTPUT:         $type: A string representing the symbol of this atom's element, e.g., "H", 
#---------------------------------------------------------------------------------------------------
    sub nthAtomElement
    {
        my $a = shift;
        my $data = shift;
        my @desc = carDescArray($data);
        return $desc[nthAtomComponent($a, $data)];
    }

#===================================================================================================
# Subroutine carDescArray(\@data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns the POSCAR desc in an array of strings
#
#   INPUT:          $data: the data list from the read_poscar
#
#   OUTPUT:         @desc: the desc in an array, e.g., ["Mg", "O", "Cu"];
#---------------------------------------------------------------------------------------------------
    sub carDescArray
    {
        my $data = shift;
        my @data = @$data;
        my $description = $data[7];
        my @types = split(" ", $description);
        return @types;
    }

#===================================================================================================
# Subroutine carComponentCount($component, \@data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns the number of atoms of component $component.
#
#   INPUT:          $component: the component we want the count of.
#                   $data: the data list from the read_poscar
#
#   OUTPUT:         The number of atoms in component $component.
#---------------------------------------------------------------------------------------------------
    sub carComponentCount
    {
        my $component = shift;
        my $data = shift;
        my @data = @$data;
        return $data[POSCAR_NUM_ATOMS][$component];
    }

#===================================================================================================
# Subroutine carNumComponents(\@data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns the number of components.
#
#   INPUT:          $data: the data list from the read_poscar
#
#   OUTPUT:         the number of components
#---------------------------------------------------------------------------------------------------
    sub carNumComponents
    {
        my $data = shift;
        my @data = @$data;
        return int(scalar(@{$data[POSCAR_NUM_ATOMS]}));
    }

#===================================================================================================
# Subroutine nthAtomComponent($a, $data).
#---------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This routine returns the nth atom component number from a read_poscar data 
#                   structure.
#
#   INPUT:          $a: the integer representing the atom desired
#                   $data: the data list from the read_poscar
#
#   OUTPUT:         $component: the component number of this atom.
#---------------------------------------------------------------------------------------------------
    sub nthAtomComponent
    {
        my $a = shift;
        my $data = shift;
        my @data = @$data;
        my @num_atoms = @{$data[3]};
        my $len = carNumComponents(\@data);
        my $atomTotal = 0;
        my $component = 0;
        for(my $component = 0; $component < $len; $component++)
        {
            $atomTotal += $num_atoms[$component];
            if($a < $atomTotal)
            {
                return $component;
            }
        }
        die "Failed in nthAtomComponent.";
    }

#=========================================================================================================
# Subroutine DirKar($data).
#---------------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This converts a poscar data structure to cartesian coordinates from direct 
#                   coordinates.  Does not alter incoming data.
#
#   INPUT:          $data: the data list from the read_poscar
#                   
#   OUTPUT:         The poscar data, now in cartesian coords.
#---------------------------------------------------------------------------------------------------------
    sub DirKar
    {
        my $data = dclone(shift);
        my @data = @$data;
        dirkar($data[0], $data[POSCAR_BASIS], $data[POSCAR_LATTICE], $data[POSCAR_TOTAL_ATOMS]);
        return @data;
    }

#=========================================================================================================
# Subroutine KarDir($data).
#---------------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This converts a poscar data structure to direct coordinates from cartesian 
#                   coordinates.  Does not alter incoming data.
#
#   INPUT:          $data: the data list from the read_poscar
#                   
#   OUTPUT:         The poscar data, now in direct coords.
#---------------------------------------------------------------------------------------------------------
    sub KarDir
    {
        my $data = dclone(shift);
        my @data = @$data;
        kardir($data[0], $data[POSCAR_BASIS], $data[POSCAR_LATTICE], $data[POSCAR_TOTAL_ATOMS]);
        return @data;
    }

#=========================================================================================================
# Subroutine KarDirRef($data, $reference).
#---------------------------------------------------------------------------------------------------------
#   DESCRIPTION:    This converts a poscar data structure to direct coordinates from cartesian 
#                   coordinates.  Does not alter incoming data.
#
#   INPUT:          $data: the data list from the read_poscar
#                   $reference: the poscar structure that contains the BASIS and LATTICE information
#                   
#   OUTPUT:         The poscar data, now in direct coords.
#---------------------------------------------------------------------------------------------------------
    sub KarDirRef
    {
        my ($data, $reference) = @_;
        $data = dclone($data);
        $reference = dclone($reference);
        my @data = @$data;
        my @reference = @$reference;
        kardir($data[0], $reference[POSCAR_BASIS], $reference[POSCAR_LATTICE], $data[POSCAR_TOTAL_ATOMS]);
        return @data;
    }

#=========================================================================================================
# CAR Manipulation.

sub centerOnAtom
{
    my $atom = shift;
    my $data = dclone(shift);
    my @data = @$data;
    my @atomCoords = $data[POSCAR_COORDINATES][$atom];
    for($a = 0; $a < $data[POSCAR_TOTAL_ATOMS]; $a++)
    {
        if($a != $atom)
        {
            my @aCoords = $data[POSCAR_COORDINATES][$a];
            my @diff = pbc_difference(\@aCoords, \@atomCoords, 1);
            $data[0][$a][0] = $data[0][$atom][0] + $diff[0][0][0];
            $data[0][$a][1] = $data[0][$atom][1] + $diff[0][0][1];
            $data[0][$a][2] = $data[0][$atom][2] + $diff[0][0][2];
        }
    }
    return \@data;
}

#---------------------------------------------------------------------------------------------------------
sub clumpSelected
{
    my $dataRef = dclone(shift);
    my $selectedRef = shift;
    my @data = @$dataRef;
    my @selected = @$selectedRef;
    for(my $i = 0; $i < @selected; $i++)
    {
        my $atom = $selected[$i];
        my $minDist = 99999999999;
        my $minDistAtom = 0;
        for(my $j = 0; $j < @selected; $j++)
        {
            if($i != $j)
            {
                my $dist = intraCarAtomDistance(\@data, $atom, $selected[$j]);
                if($dist < $minDist)
                {   
                    $minDist = $dist;
                    $minDistAtom = $selected[$j];
                }
            }
        }
        my $diff = pbc_difference([$data[0][$atom]], [$data[0][$minDistAtom]], 1);
        $data[0][$atom][0] = $data[0][$minDistAtom][0] + $diff->[0][0];
        $data[0][$atom][1] = $data[0][$minDistAtom][1] + $diff->[0][1];
        $data[0][$atom][2] = $data[0][$minDistAtom][2] + $diff->[0][2];
    }
    return \@data;
}

#---------------------------------------------------------------------------------------------------
sub clumpSelectedAroundSelected
{
    my $dataRef = dclone(shift);
    my $selected1Ref = shift;
    my $selected2Ref = shift;
    my @data = @$dataRef;
    my @selected1 = @$selected1Ref;
    my @selected2 = @$selected2Ref;
    for(my $i = 0; $i < @selected1; $i++)
    {
        my $atom1 = $selected1[$i];
        my $minDist = 99999999999;
        my $minDistAtom = $selected2[0];
        for(my $j = 0; $j < @selected2; $j++)
        {
            my $atom2 = $selected2[$j];
            if($i != $j)
            {
                my $dist = intraCarAtomDistance(\@data, $atom1, $atom2);
                if($dist < $minDist)
                {   
                    $minDist = $dist;
                    $minDistAtom = $atom2;
                }
            }
        }
        my $diff = pbc_difference([$data[0][$atom1]], [$data[0][$minDistAtom]], 1);
        $data[0][$atom1][0] = $data[0][$minDistAtom][0] + $diff->[0][0];
        $data[0][$atom1][1] = $data[0][$minDistAtom][1] + $diff->[0][1];
        $data[0][$atom1][2] = $data[0][$minDistAtom][2] + $diff->[0][2];
    }
    return \@data;
}

#---------------------------------------------------------------------------------------------------
# Makes each atom in carA move as little as possible from carB.
sub correlateCars
{
    my $dataARef = dclone(shift);
    my $dataBRef = dclone(shift);
    my @dataA = @$dataARef;
    my @dataB = @$dataBRef;
    for(my $i = 0; $i < $dataA[POSCAR_TOTAL_ATOMS]; $i++)
    {
        my $diff = pbc_difference([$dataA[0][$i]], [$dataB[0][$i]], 1);
        $dataA[0][$i][0] = $dataB[0][$i][0] + $diff->[0][0];
        $dataA[0][$i][1] = $dataB[0][$i][1] + $diff->[0][1];
        $dataA[0][$i][2] = $dataB[0][$i][2] + $diff->[0][2];
    }
    return \@dataA;
}

#---------------------------------------------------------------------------------------------------
# Makes selected atoms in carA move as little as possible from carB.
sub correlateCarsSelected
{
    my $dataARef = dclone(shift);
    my $dataBRef = dclone(shift);
    my $selectedRef = shift;
    my @dataA = @$dataARef;
    my @dataB = @$dataBRef;
    my @selected = @$selectedRef;
    for(my $i = 0; $i < @selected; $i++)
    {
        my $atom = $selected[$i];
        my $diff = pbc_difference([$dataA[0][$atom]], [$dataB[0][$atom]], 1);
        $dataA[0][$atom][0] = $dataB[0][$atom][0] + $diff->[0][0];
        $dataA[0][$atom][1] = $dataB[0][$atom][1] + $diff->[0][1];
        $dataA[0][$atom][2] = $dataB[0][$atom][2] + $diff->[0][2];
    }
    return \@dataA;
}

#---------------------------------------------------------------------------------------------------
sub intraCarAtomDistance
{
    my $dataRef = shift;
    my @data = @$dataRef;
    my $atom1 = shift;
    my $atom2 = shift;
    my $diff = pbc_difference([$data[0][$atom1]], [$data[0][$atom2]], 1);
    my $distance = sqrt(($diff->[0][0] * $diff->[0][0]) + 
                        ($diff->[0][1] * $diff->[0][1]) + 
                        ($diff->[0][2] * $diff->[0][2]));
    return $distance;
}

sub interCarAtomDistance
{
    my $data1Ref = shift;
    my $atom1 = shift;
    my $data2Ref = shift;
    my $atom2 = shift;
    my @data1 = @$data1Ref;
    my @data2 = @$data2Ref;
    my $diff = pbc_difference([$data1[0][$atom1]], [$data2[0][$atom2]], 1);
    my $distance = sqrt(($diff->[0][0] * $diff->[0][0]) + 
                        ($diff->[0][1] * $diff->[0][1]) + 
                        ($diff->[0][2] * $diff->[0][2]));
    return $distance;
}

#===================================================================================================
# Deal with akmc st.dat

sub stdatStatus
{
    my $fileName = shift;
    my $process = shift;
    eval
    {
        open(file, $fileName);
    };
    if($@)
    {
        return -1;
    }
    while(<file>)
    {
        my @values = split(" ", $_);
        if($values[0] eq $process)
        {
            return $values[1];
        }
    }
    return -1;
}

#---------------------------------------------------------------------------------------------------
sub stdatQuality
{
    my $fileName = shift;
    my $process = shift;
    eval
    {
        open(file, $fileName);
    };
    if($@)
    {
        return -1;
    }
    while(<file>)
    {
        my @values = split(' ', $_);
        if($values[0] eq $process)
        {
            return $values[2];
        }
    }
    return -1;
}

#---------------------------------------------------------------------------------------------------
sub stdatBarrier
{
    my $fileName = shift;
    my $process = shift;
    eval
    {
        open(file, $fileName);
    };
    if($@)
    {
        return;
    }
    while(<file>)
    {
        my @values = split(' ', $_);
        if($values[0] eq $process)
        {
            return $values[3];
        }
    }
    return -1;
}

#---------------------------------------------------------------------------------------------------
sub stdatMin1
{
    my $fileName = shift;
    my $process = shift;
    eval
    {
        open(file, $fileName);
    };
    if($@)
    {
        return;
    }
    while(<file>)
    {
        my @values = split(' ', $_);
        if($values[0] eq $process)
        {
            return $values[4];
        }
    }
    return -1;
}

#---------------------------------------------------------------------------------------------------
sub stdatMin2
{
    my $fileName = shift;
    my $process = shift;
    eval
    {
        open(file, $fileName);
    };
    if($@)
    {
        return -1;
    }
    while(<file>)
    {
        my @values = split(' ', $_);
        if($values[0] eq $process)
        {
            return $values[5];
        }
    }
    return -1;
}

our @rotationVectors = (
[[0.762924446507, -0.247710085697, -0.597148224787],[-0.27092046761, -0.18621520024, -0.944418339207],[-0.627909173871, 0.666212212875, -0.402357250195],[-0.289868470815, 0.733021643199, 0.61534993315],[0.43384490805, 0.78151248603, -0.448349004613],[-0.223007788138, -0.320544907068, 0.920607673758],[-0.217998383434, -0.960848936623, -0.171014694722],[-0.969748257925, -0.213007897671, 0.119230666279],[0.650021127722, -0.655286283162, 0.384801793934],[0.75018781899, 0.401644283217, 0.525261940367]],
[[0.522597960951, 0.670744853446, -0.526300971674],[0.403415577399, -0.679375379388, -0.612947767589],[-0.924975705622, -0.122740288554, 0.359659235354],[-0.371601800539, 0.490386575677, -0.788310286773],[0.900006362736, -0.0180486172816, -0.435502921286],[-0.802288747345, 0.594755620518, 0.0509756583576],[-0.885302749746, -0.0107639667586, -0.464890501421],[-0.143677952652, 0.968745786334, -0.202208425595],[0.371551271243, -0.490666111527, 0.788160148597],[-0.250170979524, 0.764718703865, 0.59381797292],[-0.393802714459, 0.05548781281, 0.917518678128],[-0.33083898853, -0.465935770183, -0.820639641824],[0.260199152175, 0.0549464908739, -0.963990292663],[0.931092333668, 0.131485974703, 0.340262405564],[-0.372439640803, -0.687802284703, 0.623070406227],[0.367598024506, 0.293810987264, 0.882352988402],[0.529365119144, 0.809424700871, 0.254173610459],[0.071391942087, -0.996915543585, 0.0325973858453],[0.77305867482, -0.622104503522, 0.123960767916],[-0.655166008309, -0.740092610973, -0.151724845493]],
[[0.292966075746, -0.167418881949, 0.941351048456],[-0.64615713863, 0.760387064194, -0.0655169047138],[0.849197135726, 0.519997034677, 0.0920179797736],[-0.245188521382, -0.966468561571, -0.0762961891414],[0.775000215815, 0.105257987192, 0.623133550387],[0.38261570759, -0.92328932847, 0.0337940266721],[0.82492683015, 0.140063249221, -0.547611186077],[0.330316994332, 0.937420162076, 0.110154995294],[-0.975466736118, 0.212786481934, -0.0564496220866],[-0.84904828725, -0.52034046334, -0.0914483905195],[0.990748333794, -0.13094848374, 0.035640337971],[-0.144294473132, 0.367172586659, 0.918892483716],[0.529447980599, 0.69820032241, -0.481872540851],[0.407772407419, -0.201728109163, -0.890520877757],[0.745411508606, -0.551974780534, -0.373745266849],[-0.36348441846, -0.245972956776, 0.898541252293],[-0.235076186789, -0.126877183886, -0.963660400044],[-0.50682288799, -0.733274465121, 0.453253923326],[0.169546943238, -0.760719908688, -0.626545333208],[-0.456224293276, -0.642891242364, -0.615264369776],[-0.219023854116, 0.877359563157, 0.426929441789],[-0.697272888916, 0.440157094752, 0.565749282211],[-0.798771204751, -0.0686280826067, -0.597707912561],[0.126155516005, 0.426908309989, -0.895451886281],[0.397180526548, 0.61178721939, 0.684078962929],[-0.102397580806, 0.915744782772, -0.388492249949],[0.102262780195, -0.758370995136, 0.643751316522],[-0.52276720702, 0.499114492067, -0.691085501999],[-0.863234387361, -0.167595131164, 0.476170415385],[0.701644450295, -0.545771809717, 0.458070078797]],
[[0.632508844094, 0.733129622219, -0.249907021046],[-0.832139305871, 0.496159807427, 0.247728926687],[0.637256014676, -0.373888225035, 0.673878599556],[-0.0649218958488, -0.863304170925, -0.500490815003],[0.894808777011, 0.415313932431, 0.163803510686],[-0.285460526274, 0.103806358703, 0.952752080991],[0.9524071758, -0.157773232667, 0.260822120492],[-0.318851731424, 0.847604596481, -0.424146226426],[0.150126611567, 0.983219802901, -0.103637925888],[0.123039098855, -0.460246604341, -0.879223773192],[-0.803807875193, 0.0515465809679, 0.592651541606],[-0.303034271751, -0.843398636612, 0.443676650169],[-0.379938243041, 0.44334488416, -0.811844963749],[0.879843240319, -0.391420392277, -0.269566223728],[0.60783286862, 0.366810986543, -0.704264796775],[-0.511258244683, -0.399520575176, 0.760919389459],[0.274420154627, -0.806181800896, 0.524179818993],[0.699123439917, 0.256081304892, 0.667569308045],[-0.999819399637, 0.0189996087674, -0.000427757707069],[0.0203295812406, -0.473521664464, 0.880547523652],[-0.799145569503, 0.018498586759, -0.600852861382],[0.935609824552, 0.153425567043, -0.317954165848],[0.166633374706, 0.716130564272, -0.677783397075],[-0.336897840606, -0.104651605845, -0.935707158458],[0.289386415185, -0.000245254329264, 0.957212328878],[0.162651811541, 0.533685479436, 0.829894087966],[-0.452846041357, 0.569930228357, 0.685645679366],[-0.464543150143, 0.879290011801, 0.105112971616],[0.134296608763, -0.990883058132, 0.0107324732591],[-0.78980999238, 0.514099632549, -0.334517180052],[-0.479840683984, -0.872756300011, -0.0897182187988],[0.484682067531, -0.750920959482, -0.448554351248],[-0.0322206273388, 0.895262097293, 0.444373275889],[0.156199892489, 0.165025639097, -0.973841944069],[-0.814107593807, -0.499297008984, 0.296532161029],[-0.850001768108, -0.455828029155, -0.264041288532],[0.681047919777, -0.717877404114, 0.144311342695],[0.513036730603, 0.77416358824, 0.370761448503],[-0.491396518938, -0.559194063568, -0.667706118323],[0.614800826125, -0.214619849657, -0.758919142155]],
[[0.470161166905, -0.862770181515, -0.185946473544],[0.465758051117, 0.48511983768, 0.740086603655],[0.0581562837883, 0.765994623685, 0.640210967683],[0.471437424336, 0.246368676042, -0.846787594619],[0.80361022527, -0.569695164888, 0.172215054348],[-0.513304653609, -0.640168241103, -0.571579352029],[-0.846821205794, 0.521877326857, 0.102654279645],[0.842808624888, -0.190606205819, 0.503331795258],[0.193224483858, -0.182464417868, -0.964038917809],[-0.456793227542, 0.796782666363, 0.395572155056],[0.514648308533, -0.0132290968537, 0.857299311513],[-0.883705483528, -0.426199849836, -0.193438120292],[0.678212706656, 0.550221799279, -0.48711753831],[0.0607107071994, -0.299711266002, 0.95209630136],[0.466739463713, 0.870044342861, -0.158672979644],[-0.757044466927, 0.339820407989, 0.558037422947],[0.838483209571, 0.311237152673, 0.447300058197],[-0.329905551806, -0.173647910479, -0.927905560967],[-0.341381380897, 0.499642472812, 0.796125713778],[0.534596951997, 0.779336905651, 0.326864018217],[0.833455035961, -0.455887995131, -0.312280064887],[0.998074318224, -0.0504389025973, 0.0361050191434],[-0.0607115410021, 0.299709288889, -0.952096870567],[-0.454472609187, 0.885679288144, -0.095009715562],[-0.296608388153, 0.692834621308, -0.657269846862],[-0.771471543611, -0.161561147177, 0.615410150323],[-0.984707340928, -0.0155479308319, 0.173521510396],[0.407908525319, -0.655802655421, -0.635242876477],[0.0715598981523, 0.245066058735, 0.966861834924],[-0.0115908043198, -0.995870575437, 0.0900413806782],[-0.0435668563879, -0.915082837285, -0.400905637191],[0.412719670096, -0.851810877741, 0.322615409546],[0.226520992021, 0.684017838672, -0.693403083749],[0.897930129899, 0.0993038572149, -0.42878925565],[0.0318236336932, -0.755438730521, 0.654446010583],[0.870338069266, 0.492188601693, -0.016187203296],[-0.74955092955, -0.198053270703, -0.631623547673],[-0.411265282065, -0.497143172356, 0.764008857245],[-0.791918555409, -0.541112409037, 0.282952933163],[-0.391396753413, 0.0031092924826, 0.920216775395],[-0.394421382119, -0.837288756892, 0.37865460635],[0.0302004392136, 0.981070857694, 0.191279653007],[0.494780473925, -0.51348137895, 0.701091403523],[-0.0059726779598, 0.947977715668, -0.318280658718],[-0.719854282853, 0.573840838724, -0.390533613496],[0.648517681289, -0.221671568008, -0.728207754004],[-0.57482188579, 0.264001943916, -0.774520995987],[-0.944495086802, 0.130573312613, -0.301462503539],[-0.521230290102, -0.845324921012, -0.117238059501],[-0.0653642514245, -0.595810160531, -0.800460971718]],
[[0.114860911498, -0.225594319947, 0.96742657283],[-0.169383468974, 0.175325821581, -0.969829931857],[0.0682715914853, 0.557633571688, -0.82727491774],[0.197315052331, 0.795503768705, 0.572922790697],[0.501759011755, -0.0025056520128, 0.865003824171],[-0.550158704104, -0.559157556529, 0.620216274597],[0.628926436522, -0.693079666336, 0.352267105412],[-0.290428897046, -0.34032270876, -0.894332997078],[-0.639852117335, -0.463565336459, -0.61294081833],[-0.575617053073, 0.810194326853, 0.110680445192],[0.351573868462, 0.446264158335, 0.822948428518],[-0.0255853750798, 0.212587091495, 0.976807103328],[0.823314833732, 0.455992182226, -0.337970138186],[-0.887052169039, -0.102486064832, -0.450150037119],[-0.501145966678, 0.259204622732, 0.825630476447],[-0.203185903127, -0.976658103409, -0.0696737957596],[0.252789880964, -0.964464763921, 0.0768439668234],[-0.646951803584, -0.737072446108, 0.195390821247],[0.843110033349, -0.360921569994, -0.398623998249],[0.98195490525, 0.0293466018538, -0.18682435873],[0.634078786343, -0.764383684886, -0.116883168124],[0.772228833773, -0.274787563973, 0.572847643771],[0.153676535381, -0.911434648474, -0.38166792377],[0.198962490049, -0.839119736717, 0.506252896294],[-0.597138165185, 0.020807138287, -0.801868489639],[0.54928912605, -0.268520640494, -0.791314173784],[0.90703624932, -0.41391873447, 0.0771785182177],[-0.342743831532, -0.194976748918, 0.918972651023],[0.391488937941, 0.219881465205, -0.893525910497],[-0.212710605564, 0.899900952261, 0.380699979513],[-0.877532887119, 0.479309031264, 0.0141026442092],[0.50020868871, 0.600096609009, -0.624239799753],[-0.566940268083, -0.781310787717, -0.261021427133],[-0.181895780372, 0.607852797076, 0.772935250955],[-0.589241215261, 0.732024236497, -0.341958049209],[0.960172425035, 0.00960149253443, 0.279243129806],[0.770550394362, 0.103042842401, -0.628994644157],[0.240521414461, 0.894603552597, -0.376608460959],[-0.880217519801, -0.452090047584, -0.144331932401],[0.887907373899, 0.442310366816, 0.126420072709],[0.137029356164, -0.158582022348, -0.977790722873],[-0.826568343785, 0.343331599379, -0.445991239736],[0.23056435422, 0.964721266334, 0.127094283296],[0.599592753308, 0.698578744064, 0.39048209757],[0.750127205777, 0.289308430079, 0.594650996332],[0.605152887035, 0.790042236204, -0.0980981565979],[-0.89673713915, -0.321329947342, 0.304318202232],[-0.244278750642, -0.89023872447, 0.384451434435],[-0.459779065136, 0.478165264835, -0.748305546397],[-0.999563532053, 0.0272261332873, -0.0114666061211],[-0.729866850149, -0.11943450865, 0.673074868939],[-0.881094657548, 0.225672076919, 0.415625213551],[-0.10908381121, -0.611620185945, 0.783595220938],[-0.248068943641, -0.766040475753, -0.592995605978],[0.128862708272, -0.592010273802, -0.795561586635],[-0.179626178189, 0.977727488949, -0.10855134022],[-0.612814051032, 0.597541925306, 0.517109839743],[0.411374661972, -0.506900706855, 0.757510766179],[-0.179810241379, 0.814135388333, -0.552133902744],[0.512609346003, -0.665675765134, -0.542316728586]],
[[-0.820207187427, 0.386865866737, 0.421420183245],[0.109570931826, -0.993534708354, -0.0297152182474],[0.415327509209, 0.901297283654, -0.123151396953],[0.287344722613, 0.683549923846, 0.670963867877],[0.836560909668, -0.543702448701, 0.0674795650027],[-0.593638493068, -0.468367483887, 0.654389211086],[-0.150581832236, 0.532517912728, 0.832916433037],[0.794915273543, 0.0463940166691, -0.604944049566],[-0.519809969862, -0.697145753972, -0.493746283986],[-0.328296373537, 0.713627503549, -0.618835420206],[-0.649986939327, -0.0453048533281, -0.758593731169],[-0.724134832943, 0.599215857807, -0.341422171908],[0.453537537114, -0.120060679885, -0.883113319781],[-0.221211459688, -0.946275069559, 0.235857971742],[0.560684637446, -0.700516536522, 0.441485355806],[-0.621858881678, 0.374477363897, -0.687792290744],[-0.795118766585, -0.0458439994757, 0.604718508677],[-0.54005622593, 0.3072417226, 0.783544380829],[0.820489710421, -0.347907129444, 0.453604744657],[0.347841843536, -0.577138827113, -0.738861845086],[-0.789837951367, -0.353989157006, -0.500846969944],[0.242656627588, 0.925888104719, 0.289566881096],[-0.873788151827, -0.388802018744, 0.292108294896],[0.639375980558, 0.438739778136, 0.631431518509],[0.90009426498, 0.375343633708, 0.221240752995],[0.849060599538, 0.0691073271702, 0.523755931368],[0.178330164447, -0.895300118367, 0.40821079175],[0.98741352344, -0.0897875523991, 0.130202646527],[0.92868457002, -0.255249804942, -0.269058555865],[-0.713227070557, 0.69294615711, 0.105511938524],[0.437369742674, 0.732673751764, -0.521437322859],[0.76060399649, 0.640864729559, -0.103797682689],[-0.60644304422, -0.733092562674, 0.307899543144],[-0.27418577164, -0.0371345257011, -0.960959515084],[0.0338976066364, 0.8913768804, -0.451993594372],[0.693607691593, -0.369885724403, -0.618136652404],[-0.894184877347, 0.132619840154, -0.427604236557],[-0.238831256825, -0.74726779167, 0.620121341591],[0.293431826586, -0.860698387245, -0.416048133441],[-0.410556540267, 0.882090885425, -0.230995664667],[-0.974391531374, 0.0301638732939, 0.222825681495],[-0.0751578178083, -0.694024414579, -0.71601774726],[0.750107702392, 0.454202786983, -0.480664397588],[0.484879698559, 0.337299807991, -0.806920391026],[0.508231907869, -0.860359532559, 0.0384941886279],[-0.509492084991, 0.668840633814, 0.541359420248],[0.114963772243, 0.598191359846, -0.793063949551],[-0.0142251065015, 0.998969009105, -0.0431110796946],[-0.146946374935, -0.920183678953, -0.362861901945],[0.185687606412, -0.173923000918, 0.967094050533],[-0.170995412952, -0.408958637969, 0.896389090284],[-0.973220091697, -0.181817143142, -0.140659800856],[-0.469759663161, -0.11331169515, 0.875492043715],[-0.476067700263, -0.874256818827, -0.0950502998489],[0.554475856831, 0.0402256551905, 0.831227057341],[-0.40684689687, -0.425659725137, -0.808263200266],[0.617912040464, 0.725556729089, 0.302906162242],[0.247147608703, 0.322854180255, 0.913610003122],[-0.0976452385445, 0.840582680819, 0.532809688441],[0.128372732864, 0.154437868406, -0.979627166967],[-0.246746523188, 0.380070401641, -0.891438524572],[-0.352845133746, 0.913537065454, 0.202361907563],[-0.801539095895, -0.588073475815, -0.108188099139],[0.0528406092376, -0.320698501988, -0.945706265623],[-0.936891761171, 0.34558303282, -0.0529735337443],[-0.134688452206, 0.117108647417, 0.983943385334],[0.181713472913, -0.630023316734, 0.755017108503],[0.526028104733, -0.379780512884, 0.760960705335],[0.670078088019, -0.668576008195, -0.322492600261],[0.960175416513, 0.202189687566, -0.192827642642]],
[[-0.178123926213, 0.769113279355, 0.613788750655],[0.138235209342, -0.706727284834, 0.69384981932],[-0.24155031139, -0.967675231742, 0.0725127088224],[0.873188427565, -0.262933887486, -0.410375122027],[0.846925882306, -0.525801067427, -0.0790555967226],[-0.328328684712, -0.495258126267, -0.80431316237],[-0.838134748331, -0.527434415021, 0.139079407145],[-0.165922834544, 0.976431609273, -0.138025089712],[0.717449054629, 0.0364000532697, -0.695659320454],[-0.73858360862, 0.609726940748, -0.287623557456],[0.18126107022, -0.983020143971, -0.0285625799039],[0.0721850757135, 0.891153087227, -0.447923531387],[-0.161561424148, -0.935031836327, -0.315615860314],[0.235225093521, 0.896312439142, 0.375889833352],[-0.15432590188, 0.954415183789, 0.25549006431],[0.954853516904, 0.297035014302, -0.00499615203756],[0.725286238782, -0.602182920017, 0.33366990076],[0.622045638113, -0.373344581239, -0.688239092006],[0.513594202385, -0.511908476474, 0.688600542398],[-0.38413688681, 0.147115192906, 0.911480099733],[0.0380835128627, 0.0341317969393, -0.998691477127],[-0.676331314287, -0.344559333992, -0.651041334075],[-0.48486197296, -0.711035063368, -0.509252398952],[0.558431864832, -0.829319708307, -0.0195620487885],[-0.531342494777, 0.847127653842, -0.00706338025019],[-0.98356344289, -0.180497882911, 0.00484438587884],[0.485242399401, -0.0727304253962, 0.871349584865],[-0.732916693149, 0.0994521515934, 0.673009948253],[-0.316791035315, 0.286071838686, -0.90432645823],[0.900340232344, 0.196876126325, -0.388107274998],[0.416483027419, -0.82641527086, 0.378919104771],[-0.818479118139, -0.501729673271, -0.279927255068],[0.0714320838703, 0.420918695033, -0.904281432722],[0.111963976641, 0.0773996144521, 0.990693377195],[-0.556515479753, -0.237717527682, 0.7961035723],[-0.86464523323, -0.236904924134, 0.443017694425],[0.185742198984, 0.673547121966, 0.715425824253],[-0.621547108372, -0.545631161748, 0.562108376921],[-0.562030199012, -0.788387050682, 0.250135790552],[0.436938171573, 0.270868956772, -0.857738329841],[0.543655497948, 0.637450283029, 0.545981534684],[-0.826790394213, 0.553202780769, 0.101903519993],[0.629293692388, -0.666720058554, -0.399341723643],[0.472592225941, 0.819720290261, -0.323597332676],[0.571005736837, 0.811279802201, 0.12560864238],[0.667146268469, 0.484032100717, -0.566240922173],[0.992420624193, -0.094448617791, -0.0786178305132],[-0.52187142723, 0.763286842537, 0.380845650428],[0.044980935341, -0.384849253029, -0.921882730014],[-0.548749917569, 0.503945215373, -0.667017801764],[-0.761453799283, 0.442530509343, 0.47366112344],[-0.399383620643, 0.813620987875, -0.422508711924],[0.384655121617, -0.147786461259, -0.911152895667],[0.0488508273141, -0.935572776727, 0.349738725505],[0.776117968177, 0.605030321295, -0.177705401682],[-0.175590896029, -0.185061986583, 0.966912559828],[-0.831595893095, 0.271338684209, -0.484585997568],[-0.15835225788, 0.679206888389, -0.71666070437],[-0.650370906608, 0.052306354154, -0.757813782636],[0.379996955005, 0.349023472642, 0.856612473486],[0.761876565672, -0.196905404831, 0.617067549162],[-0.573729038178, -0.806112123435, -0.144976671237],[0.928197795745, 0.10864449002, 0.355872486662],[0.924221297775, -0.281958029642, 0.257516333967],[-0.232789813774, -0.538094728511, 0.810100589897],[0.806760685719, 0.514560299937, 0.290456354221],[0.192524558525, -0.3615281556, 0.912267333117],[-0.334325021728, -0.127744194206, -0.933760247972],[0.272842189816, -0.875728987307, -0.398316306779],[-0.949067334582, 0.132557336889, 0.285831675756],[0.710790239379, 0.247949905464, 0.658253811219],[-0.910172911734, -0.115456842035, -0.397812755419],[-0.0565096705854, -0.753655238659, -0.654836192014],[-0.273818592538, -0.804438200228, 0.527164642587],[0.315190791893, 0.660558432545, -0.681408337122],[-0.462963575213, 0.497753314808, 0.733421001624],[-0.967226409024, 0.228533184913, -0.110660097055],[-0.0780401072473, 0.426165154616, 0.901272990082],[0.223676056436, 0.974186953067, -0.0304762571707],[0.316812389857, -0.613708933354, -0.723181342924]],
[[0.618779132162, 0.760261964725, 0.197772926847],[-0.383805244102, 0.923400644267, -0.00497843010443],[-0.191451343664, -0.940590772349, 0.280420009951],[-0.969615281879, 0.0904863363836, -0.227284905073],[-0.615977445169, -0.508428944055, -0.601724019706],[0.933055586701, -0.335905735313, 0.1287424138],[0.172219282181, 0.892824649282, -0.41617864491],[0.733281289086, -0.527901782856, 0.428507011301],[-0.811547896247, 0.475952688418, -0.338908616717],[-0.803500784367, 0.484550540008, 0.345828373185],[0.882595832229, -0.150744702872, 0.445309590608],[0.428995725654, 0.893603136038, -0.13204583535],[0.492732495336, 0.695146148455, -0.523437217179],[-0.305594272641, -0.00369281375936, 0.952154663726],[0.99888915253, -0.00920079844202, -0.0462147840571],[0.417116950317, -0.637042651291, 0.648220726446],[0.736182973293, -0.302086789388, -0.605622160684],[0.105953008673, 0.361039810093, -0.926511853934],[0.720165119201, 0.659438202376, -0.215646605199],[-0.491933832643, 0.140339080344, -0.859247372315],[0.456520556445, 0.691917532625, 0.559320220973],[-0.460255004246, -0.78884212792, -0.407300169759],[0.117156114844, -0.635825413367, -0.762889565056],[-0.247844442147, 0.429763434267, -0.868260630838],[-0.602424335367, -0.797215244729, -0.0391506542677],[-0.980534040255, 0.0574614604083, 0.187752966605],[-0.24523310109, 0.720504087569, 0.648640567593],[0.0324614117699, -0.31495929371, -0.948549893285],[0.0389986867287, 0.998505643661, -0.0382829206103],[-0.963971769376, -0.265349879208, -0.0186512586708],[-0.245895839851, 0.398259688001, 0.883699302284],[0.414450477375, -0.29105157793, -0.862275930772],[-0.126648568259, 0.0434513741841, -0.990995518779],[0.454215125216, 0.38493799505, 0.803437215961],[-0.876305628417, -0.24301995238, 0.415968446339],[-0.283329180018, -0.72716059414, 0.625269578726],[-0.271370809781, -0.957885999124, -0.0938738317184],[0.725585523519, 0.123958798239, 0.676875072963],[0.410517521424, 0.0176760633444, 0.911681370539],[-0.836946345976, 0.144671112688, 0.527817281937],[-0.351380941087, -0.266969359515, -0.897362131651],[0.280479272037, 0.928228122572, 0.244384799905],[0.924706337557, 0.319425302766, -0.207088544431],[-0.341783191895, -0.394814146254, 0.852822396315],[0.106513993738, 0.819484237604, 0.563116642852],[-0.795116063484, -0.55511779062, -0.244202137842],[0.00527461137527, -0.195228728185, 0.980743555761],[-0.517384533785, 0.783623206735, 0.343871944285],[0.464266858351, -0.881252340852, -0.0886035889834],[-0.26724162439, -0.605170703254, -0.749900216106],[0.171577788578, -0.967737307354, 0.184514407083],[0.320429696711, -0.354200786452, 0.878559396024],[-0.799286560914, 0.169258688106, -0.576621617738],[0.640766343872, 0.0498309053326, -0.766117075541],[0.753976229683, -0.655518548603, 0.0426060736434],[0.283534170171, 0.0367934487257, -0.958256028667],[-0.193242883327, 0.922801977591, -0.333307212939],[0.902599777893, -0.346685448029, -0.255191773129],[-0.150774066705, 0.940406134114, 0.304800727903],[0.741743573788, 0.457102664791, 0.490788777974],[-0.572762595198, 0.490896111266, -0.656478497352],[-0.0973603689855, -0.860575304221, -0.499931099569],[-0.543555546967, 0.758079093655, -0.360365724126],[-0.233719531797, 0.72865304776, -0.643770080422],[0.077442731644, 0.191178901017, 0.978495401687],[0.643419619201, -0.269668847768, 0.716442535149],[-0.814260573063, -0.548293852257, 0.190666123714],[0.481988890016, -0.584563545133, -0.652665436194],[0.304095851514, -0.839536038138, -0.450227668807],[-0.922909590818, 0.384835200541, 0.0118218273172],[0.748109245248, 0.382810050636, -0.542023082818],[-0.881266469484, -0.226057472586, -0.41505111595],[-0.670357280819, -0.161605055889, -0.724227120428],[-0.707376182241, 0.706836813373, 0.000809975092617],[-0.630056931581, -0.51756549417, 0.578925057509],[0.459066827605, 0.399592787676, -0.793462823218],[0.862305448884, 0.492795178971, 0.11654280076],[0.942355197209, 0.17221871123, 0.286892659012],[0.491595270191, -0.813189703887, 0.311539075909],[0.103202359554, -0.834655922658, 0.541016417269],[0.0828660142972, -0.981044263699, -0.175172418887],[0.0129073104815, -0.574039841312, 0.818725632873],[0.89361688742, 0.0137640226936, -0.448619449196],[0.140538452337, 0.67524172869, -0.724083939368],[-0.527380128896, -0.784937828432, 0.325181188174],[0.679792939142, -0.651166148007, -0.337437709189],[-0.56826050701, 0.523945544198, 0.634476999495],[-0.648794116307, -0.17206240749, 0.741256178776],[0.113041125314, 0.549680474199, 0.827691416092],[-0.57562609906, 0.195669458307, 0.793957213688]],
[[0.612837103115, -0.654989682755, 0.442062439629],[0.558091180534, -0.807562745605, -0.190726626668],[0.494260196659, -0.46544724441, 0.734210951069],[-0.461430016193, 0.756657771878, 0.46319688731],[0.720024235559, -0.685484352253, 0.108056943433],[-0.536214759973, -0.351964451105, 0.76719929376],[-0.647320621887, -0.562348758359, -0.51452880041],[-0.666611419934, -0.709765308254, 0.227733225537],[-0.339686758879, -0.0978756891125, 0.935432122243],[-0.0967776388949, 0.867769535666, -0.487452686505],[0.672723258522, 0.575394888985, 0.465149587953],[-0.174611518775, -0.137949363346, -0.974926043689],[-0.449552387718, 0.717996959305, -0.531397231011],[0.973075632435, -0.175996081886, -0.148826048535],[-0.749045003453, 0.160146733143, -0.642872154216],[0.575570672399, 0.795971871427, 0.187475814361],[0.0754116732518, -0.954906709417, 0.287169385289],[-0.506433344578, 0.00741656568348, -0.862247216321],[0.422136156881, -0.886296116555, 0.190473774658],[-0.483996144558, -0.674336454726, 0.557689947804],[-0.758015075203, 0.545334879648, 0.35780303912],[-0.0684911174816, -0.931723548119, -0.356651365771],[-0.463355866816, -0.886071065313, -0.0133943235295],[-0.916825145382, -0.0294928438817, -0.398198223193],[-0.508219205923, 0.414734199797, -0.75479055522],[0.824288050351, 0.561604527373, 0.0717604687973],[-0.582099879212, 0.804142927263, 0.120473578653],[0.732360066327, -0.00400053804903, -0.680905815033],[-0.0835216280139, -0.799847691045, 0.594363364268],[0.980229268719, -0.0414165334025, 0.193481915195],[-0.844021368352, 0.536259483014, 0.00732779938908],[0.292571997522, -0.784374286267, 0.546953933443],[-0.585453935059, 0.124959243994, 0.801017401349],[0.561158628367, -0.316783904854, -0.764688793847],[-0.127647414103, -0.991780751049, -0.00877949432849],[-0.238900790458, -0.548326297611, 0.801414177355],[-0.0656504214169, -0.474371926622, -0.877873167035],[0.78736693302, -0.349468340041, 0.50786335967],[0.0822956425994, 0.422386430098, -0.902672216742],[0.420956818581, 0.516816068571, 0.745450540383],[0.61099227279, -0.603682331755, -0.512109446229],[-0.0473552650899, -0.295448129059, 0.954184406655],[-0.310997953428, -0.893990644651, 0.322584872924],[0.889567741344, 0.312887020343, 0.332822694631],[0.452679509703, 0.0484811030147, -0.890354336287],[0.273373210065, 0.881668713296, -0.38461327072],[0.359586187732, 0.804471840341, 0.472782012868],[0.151787029827, -0.569198621461, 0.808067835582],[-0.438269707421, -0.363355589826, -0.822126741385],[0.0820394029592, 0.409544390228, 0.908593929539],[-0.275327352774, 0.284367741169, 0.918329917076],[-0.240325564353, 0.247538354579, -0.938599161586],[0.110701341998, 0.0825780330399, -0.990417124922],[0.0111017156596, -0.756967095735, -0.653358682413],[-0.329680091026, -0.669688891872, -0.665453098035],[-0.00591692664999, 0.991022784973, -0.133562081608],[0.382283751151, 0.169473431451, 0.908371008805],[-0.941651643395, -0.123149347967, 0.313251369649],[-0.937823179551, 0.272197941988, -0.215397224388],[-0.770915242862, -0.445261332894, 0.455447070198],[-0.767300443814, -0.122937762993, 0.629393625129],[0.905269652073, -0.390464823068, 0.167403939567],[0.61758066779, -0.107550652573, 0.779119359215],[0.226038941344, -0.262821397147, -0.937993235689],[-0.18827916748, 0.617096652635, -0.764030546771],[-0.723463280748, -0.672175485604, -0.157419814389],[0.713653383529, 0.340789020583, -0.612014453773],[0.186474337077, 0.700748666601, -0.688606293806],[-0.959116623146, 0.226709126504, 0.169405652695],[0.311198806918, -0.581447795281, -0.751713884358],[-0.72960401903, -0.230733831041, -0.643770047942],[0.423222009143, 0.401359037195, -0.81227707972],[0.126511980696, 0.961521547876, 0.243866831919],[-0.570800496421, 0.463804939834, 0.677548353309],[-0.417607050962, -0.834269840093, -0.359997479016],[-0.354180869905, 0.912285754703, -0.205646816554],[0.308423388805, -0.835663367934, -0.454468644387],[0.226009277274, -0.968274266546, -0.106605587705],[0.0232822774232, 0.0612965711446, 0.997848017447],[0.109401473244, 0.704289334585, 0.701432712982],[0.619831226548, 0.758984712093, -0.199377675292],[0.828382774225, -0.288356160688, -0.480242338783],[0.301548036679, -0.205591143984, 0.931021515912],[-0.657383037488, 0.717655235285, -0.229822769307],[0.919099725345, 0.101062323894, -0.380843933337],[-0.995243307051, -0.0864070138364, -0.0449954189901],[0.827215026988, -0.524039292893, -0.202726709217],[0.533284556001, 0.652790110695, -0.538026629182],[0.678751646645, 0.26687903746, 0.684157716862],[-0.251411913907, 0.955228135925, 0.155984800169],[0.854183947289, -0.00267803912364, 0.519964049046],[-0.882661957291, -0.371602046534, -0.287784273656],[-0.118243167249, 0.865497771488, 0.48675677802],[0.971876422281, 0.231622840928, -0.0425097562302],[-0.896498385043, -0.433560635359, 0.0911911239219],[-0.830561190806, 0.220597942987, 0.511375259351],[-0.243182851709, 0.609377859177, 0.754665969406],[-0.754813405545, 0.467735221117, -0.459870074843],[0.342852677922, 0.93874882645, -0.0346797070393],[0.828933643211, 0.473992114558, -0.296985673881]],
[[-0.171756220156, 0.969616903472, 0.174192024326],[-0.93345005415, -0.253397464323, 0.253891160699],[0.169553667172, 0.963679738358, 0.20633205235],[0.289747715108, 0.396275513282, 0.871212935604],[0.954455724364, -0.145144452969, -0.260667140239],[-0.913271532827, 0.05123226973, 0.404116767612],[0.826094029889, -0.541025646369, 0.157670237372],[0.513385968353, 0.552213017809, 0.656883270042],[-0.524709529465, -0.427695129641, 0.736041293522],[0.0256674197205, -0.839084826662, 0.543394734269],[-0.670902397071, 0.17433724006, 0.720761056337],[-0.942055829911, -0.32252234428, -0.0922504784334],[0.015304915748, 0.40397312713, -0.914642811217],[-0.548994482532, -0.823571440425, 0.142601334728],[0.610160165983, 0.731310255447, -0.304778414796],[0.498096536907, 0.83912275076, 0.21857000956],[-0.405834456113, 0.779279349323, -0.477516586047],[0.11907416733, 0.658391580875, 0.74319705927],[0.592803464392, -0.78854005156, 0.163672354696],[-0.821959298047, -0.375865309633, -0.427911417666],[0.565366138817, -0.344055190198, -0.749658025487],[0.155858388218, 0.674849048973, -0.721309173602],[-0.169119797904, 0.0205380176489, 0.985381491499],[-0.272697896961, -0.680389075977, 0.680225376096],[0.801058911414, -0.345601384889, -0.488737458362],[-0.233966046356, -0.89302113448, -0.384412724198],[0.327030026215, -0.876609116613, 0.35299832666],[-0.797638654895, 0.370167263266, 0.476181450104],[0.289572420855, 0.853595972265, -0.4330377919],[-0.0547226260642, 0.882916286417, -0.466330639543],[-0.479377271998, -0.0874586679346, 0.873240180302],[-0.200573648806, 0.104890968501, -0.974047276128],[-0.260389931104, -0.897613307883, 0.355650718109],[-0.799152580064, 0.601099804496, 0.00584626486454],[0.337111950073, -0.417678015837, 0.843742027047],[-0.592827303759, -0.40053420689, -0.698661675654],[0.901240728828, 0.384051327363, 0.200673183692],[0.484284971147, -0.00589340584201, -0.874890469995],[-0.224306010485, 0.629101758131, 0.744256536133],[-0.269897952565, 0.947268073369, -0.1727376403],[0.889463584277, 0.43114532809, -0.151552757519],[0.0613802734061, -0.817387004271, -0.572809695523],[0.766065434927, -0.0366881872216, 0.641714676728],[0.480189766756, 0.607710664656, -0.632538960038],[-0.331446833103, 0.394066860427, -0.857236435494],[0.902213438909, 0.16070366125, -0.400231487908],[-0.539937160217, 0.531482061578, 0.652682680357],[0.632694434869, -0.360705961476, 0.685265613788],[0.753716097881, 0.468088687924, -0.46130794924],[-0.797894865354, -0.581573391476, 0.15854391874],[0.992678440335, 0.118193028259, -0.0248982361823],[-0.454340013417, -0.114496695339, -0.883439674774],[0.352377768472, -0.852201398905, -0.386759206732],[0.970814869944, -0.225075911363, 0.0828210264378],[0.0305385622745, -0.555014522068, -0.831279902625],[-0.759359441543, -0.0941108247237, -0.643829473703],[-0.0371217009036, 0.866911144337, 0.497078512054],[0.344748208451, -0.687161395781, 0.63949815396],[0.854151785468, -0.488840324432, -0.177369288748],[-0.38607484293, 0.291984008949, 0.87503803013],[0.0292213194681, -0.584182184882, 0.811096350229],[0.0689636069187, 0.987777812739, -0.13978202167],[0.351685352814, 0.361452273109, -0.863521665553],[-0.569702565824, 0.518196734453, -0.637895862109],[-0.239438307638, -0.970892964004, -0.00601242740147],[-0.588812070433, 0.182873950808, -0.787310271639],[0.322945936237, 0.800243606831, 0.505288127699],[0.0814871321858, -0.235160554764, 0.968534646139],[0.402138911846, 0.910366549537, -0.0975553230942],[0.610075455383, -0.624451302711, -0.48771765324],[0.635721744588, -0.617956292756, 0.462588244231],[-0.293213610589, -0.420584455365, -0.858565369946],[-0.936929505501, 0.294337827218, -0.188489642129],[-0.0582136159177, -0.20816039051, -0.976360807665],[0.696058592989, 0.611626034476, 0.376053226388],[-0.272137791392, -0.696443086711, -0.664009073334],[-0.757070902417, 0.548156345843, -0.355483149004],[0.567656770609, 0.215654249466, 0.794518115255],[-0.816841668076, 0.240972010635, -0.524120386348],[0.787929480933, 0.306619700821, 0.533995779146],[0.0549504309175, -0.974993860873, -0.215330957833],[0.465317227368, -0.0974465481189, 0.879763631991],[-0.495069216149, 0.859274763798, 0.128659828703],[-0.56841277751, -0.664392144323, -0.485273111687],[0.269189046584, -0.297388588037, -0.916022535151],[0.764662928329, -0.046682104457, -0.642737416962],[-0.929394610196, 0.330096447717, 0.165112064195],[-0.682730755152, 0.652293695438, 0.329228873068],[0.94274205042, 0.0437124657268, 0.330645802498],[-0.765136785915, -0.618754807518, -0.178067928088],[0.190195501113, 0.0910160073951, 0.977518162365],[0.857513237253, -0.302526959907, 0.41611114677],[-0.507147902568, -0.840058852754, -0.192619128931],[-0.234817708685, -0.356056530516, 0.904480177099],[0.164179407897, 0.0728027703303, -0.983740249586],[-0.94283372983, -0.0437158637162, -0.330383839124],[0.647596371879, 0.268973044465, -0.712932283236],[-0.376509676585, 0.802882742399, 0.462190183146],[-0.188733903979, 0.667932772115, -0.719892579086],[-0.0559700564461, 0.367771705747, 0.928230211334],[0.731852673351, 0.681254705826, 0.016843108348],[-0.759404431936, -0.444750354063, 0.47487054164],[-0.540318956107, -0.70186586411, 0.464154860439],[-0.583617723757, 0.789494569306, -0.18997020175],[-0.999543471344, 0.0125989744103, 0.0274611495954],[0.0479854297801, -0.982388206242, 0.180584636016],[-0.754327174461, -0.149233990159, 0.639311919215],[0.3412199618, -0.623558082845, -0.703380590426],[0.632000505387, -0.755937544415, -0.170686232998],[0.339919593309, -0.940040099972, -0.0279155965059]],
[[-0.754092189839, -0.324596272297, 0.570948534664],[0.0331054534024, -0.999450478916, 0.00166407610293],[-0.285140983337, -0.844807075901, 0.45276442454],[-0.989284662964, -0.0793899267779, -0.122527936206],[-0.428032674492, 0.516366082323, 0.741723734684],[-0.277129360408, -0.953659422142, 0.117187986417],[-0.73931467142, -0.192092459793, -0.645379193586],[0.814563930827, -0.23581341201, -0.529978902704],[0.956968512587, -0.14990672862, -0.248473818805],[-0.252180639723, -0.0323347032506, -0.967139799571],[0.759354804585, 0.647434962671, -0.0648710248478],[0.840008793923, -0.0458384215924, 0.540633022703],[-0.544970321857, -0.629359930579, 0.55399767696],[0.148837479203, 0.371337403953, 0.916491100453],[0.873650826589, 0.402522385414, -0.273331232101],[0.676007362596, -0.720661146519, -0.153823137443],[-0.0072848076376, 0.928905904985, -0.37024417789],[-0.522740237837, 0.538993416974, -0.660476146583],[0.870038420474, -0.322773994691, 0.372625945486],[0.0556461732797, 0.752299170943, -0.656467410309],[0.392222116675, -0.913212535299, -0.110474777948],[-0.877910658938, -0.310856483896, -0.36419928795],[0.863521653808, -0.456979578728, -0.21330733234],[-0.228864624577, -0.662921645752, 0.712850527958],[0.915547843522, 0.393856318833, 0.0815435241884],[-0.462991098614, -0.767947381007, -0.442601471538],[-0.626941541296, -0.502634636464, -0.59523333746],[0.198545833921, 0.955323713348, 0.218943267873],[0.153228488897, 0.504899694992, -0.849468850628],[0.508768158606, 0.852612596868, 0.119191947923],[-0.928677577353, 0.361598151862, 0.0824908109556],[0.407269945701, -0.583019473429, -0.703007457238],[-0.277860684889, 0.765192816455, 0.580752437307],[0.593655978819, -0.785867391727, 0.173161835957],[-0.179776387192, 0.388070726066, 0.90392563974],[-0.809123760094, 0.566868828633, -0.154849836861],[0.026313849084, -0.605829311759, -0.795159371674],[0.216970830883, 0.199778970857, -0.955516625365],[0.183856857186, -0.790002945549, -0.584886315526],[-0.860407981607, -0.00371042520868, 0.509592325228],[0.127407631852, -0.534156315985, 0.835729816052],[0.58506926277, -0.0319577834103, 0.810353415395],[0.378013703802, -0.795024259243, 0.474385989415],[0.527682160312, 0.822930465371, -0.210563498387],[0.579791570126, -0.309335652781, -0.75375937084],[-0.12989075078, 0.935092869716, 0.329741895835],[0.382241312794, -0.288770002395, 0.877783267391],[-0.450900628537, -0.3241699893, -0.831626383193],[-0.346870882679, 0.934085149255, 0.0846494222745],[-0.859097571852, 0.318668155627, 0.400502145596],[0.0738927839354, -0.0910430002824, -0.993101721165],[0.295380013854, -0.934503187509, 0.198631417331],[-0.890025799481, 0.0320992493125, -0.454778753298],[0.988463299067, 0.125409030252, -0.0849286849575],[-0.735811638066, -0.606892216184, -0.300438132103],[0.421738313444, -0.0593091570313, -0.904775783753],[-0.496385003649, 0.799833738746, 0.337443207839],[-0.130432633981, -0.354258602002, -0.926006571737],[0.857653274614, 0.332766809848, 0.392042230898],[0.244957152065, -0.3633299417, -0.898881164068],[0.249449597643, 0.959736925274, -0.12915081301],[0.719432665837, 0.357734746866, -0.595350728741],[-0.194961176151, 0.560442934915, -0.804918540287],[0.0693110069132, -0.20857747727, 0.975546728915],[0.286630001313, 0.0523077829102, 0.956612323877],[0.670636716773, -0.595653630471, 0.442089523312],[0.308819849625, 0.619083594313, 0.72205664856],[0.31521318733, 0.827790976829, -0.464115012916],[0.0786334501818, -0.777695227845, 0.623704187175],[0.651746556357, 0.62574921021, -0.428560791718],[-0.220617478864, -0.946686885558, -0.234759171773],[-0.98236729322, 0.0572350143243, 0.177984983489],[-0.325838656162, 0.910681788444, -0.253944581251],[-0.581413668452, 0.717732142189, -0.383169307494],[-0.782861895072, 0.428912890702, -0.450733829919],[0.717674013169, 0.229035167775, 0.657637364164],[-0.709249997355, 0.214854276497, -0.671417963062],[-0.052009933668, 0.998301253887, -0.0262597274684],[-0.0657976077352, 0.0917838005193, 0.993602741934],[0.430040042811, 0.789511276362, 0.437878414719],[-0.756537778757, 0.622177682946, 0.201359181956],[0.828383750846, -0.547455984614, 0.118626751807],[-0.314940978559, -0.610170157365, -0.726983190373],[-0.646806816196, 0.562981995411, 0.514482473331],[-0.516381372779, -0.848610634105, -0.114935936635],[0.682933032727, -0.543470318514, -0.488100897054],[0.120786151395, -0.943380209917, -0.308940908862],[0.967854418816, 0.0475965611279, 0.246966376956],[0.46370762769, -0.785253885216, -0.41030668015],[-0.946965303138, 0.239082229084, -0.214700727499],[-0.143051247219, -0.828642732528, -0.541190874366],[-0.931411373906, -0.248136766505, 0.266272412517],[0.671736997931, -0.328253253853, 0.664092769834],[-0.321602459218, -0.120837092789, 0.939132714387],[0.693991141115, 0.0289862065606, -0.719399816433],[-0.0339340173282, 0.643551744687, 0.764650007768],[0.611271923269, 0.539582549413, 0.578962268366],[-0.548782977151, -0.798518053561, 0.247398791684],[-0.751716290857, -0.659216813127, 0.018862962431],[-0.489640364157, -0.391652801468, 0.779012449766],[0.42455216457, 0.598523439079, -0.679356425179],[-0.920843341159, -0.388545747083, -0.032859450187],[-0.633587797189, -0.0752140408461, 0.770006072257],[-0.100213680069, 0.266982800736, -0.958476605055],[-0.60280293691, 0.796573003485, -0.0458265138388],[-0.279529066784, 0.779154360989, -0.561054349038],[0.107065621228, 0.837376770422, 0.536038335484],[0.429533204648, -0.571384298952, 0.699300514097],[0.490054484486, 0.29799090561, -0.819175208615],[-0.175034593995, -0.408250619872, 0.895932096913],[-0.779492452419, -0.538860068448, 0.319407800867],[-0.432126489106, 0.182554682021, 0.883142392531],[0.459703882644, 0.321916294331, 0.827672785421],[0.889287507072, 0.109673538695, -0.444003879121],[0.0056680527242, -0.937842441566, 0.347015025577],[-0.684995746732, 0.257661954391, 0.681462503897],[-0.548344445351, -0.00978495714216, -0.836195326384],[-0.41649477176, 0.296182769698, -0.859539337105],[0.969983443542, -0.233400906368, 0.0682358861718],[0.721995704719, 0.634617324635, 0.275650237875]],
[[0.46167151522, -0.247647690535, -0.851780507764],[0.632965391945, -0.0484239229949, 0.772664180794],[0.410050550297, -0.28344364664, 0.866901520001],[-0.518492668785, -0.578882434556, -0.629333361088],[-0.338947986844, -0.810793648318, 0.477208468136],[0.489938604884, -0.829587622496, -0.267851712791],[0.515529401226, -0.505546120112, -0.691847206334],[-0.652614338058, -0.748268698697, -0.119115407531],[-0.167009192818, -0.900870235738, -0.400675364697],[0.967213002136, -0.161226509025, 0.196226963707],[-0.610901288688, -0.641038819113, 0.464616882894],[0.381669163378, 0.581397800865, 0.718543837824],[0.550793612016, 0.720234944237, -0.421767734732],[-0.96493152478, -0.0749239235802, 0.251582110179],[-0.749079354086, 0.199032411061, 0.631875162218],[0.356552539234, 0.0371189887301, -0.933537609013],[0.146662801276, -0.52332976336, 0.839414070351],[0.669767441458, -0.601769078983, -0.435069592069],[-0.246021559604, 0.930605322429, -0.271011302487],[-0.802852596418, -0.0204541738467, -0.595826598263],[-0.608401948262, -0.0299795605156, 0.793062604908],[0.594824730157, -0.658406206352, 0.461177631538],[0.169600089757, 0.794030230297, 0.583739499202],[0.151601414118, -0.246312506321, -0.957260236543],[0.390724523532, 0.581482374986, -0.713591335633],[0.367179981021, -0.747462279712, -0.553605456932],[-0.420203070287, -0.265711548159, 0.867655895442],[-0.649488356777, -0.356626804343, 0.671552080509],[-0.244858883746, -0.710025138905, -0.660233617118],[-0.909167704326, 0.214668810437, 0.356835238221],[-0.806096978151, 0.302626770277, -0.508551570371],[-0.349767356688, 0.875960513668, 0.332198697603],[0.495551084211, 0.744891127724, 0.446728475446],[0.83994582779, -0.128251801247, 0.527297337234],[0.364913713919, 0.0338924046374, 0.930424250706],[-0.832540411307, -0.0977496120898, 0.545271929296],[-0.15743928989, 0.987061138226, 0.0303838674808],[-0.743700949315, 0.666928602405, -0.0459906216709],[0.522338061988, -0.849573543804, 0.0734012443152],[0.87393025, -0.382531492942, -0.299859258723],[-0.0695603381163, 0.368221170003, -0.927132422754],[-0.232452425966, 0.617127153095, -0.751744601959],[-0.0802150584508, -0.506133952449, -0.858716464601],[-0.213625591545, -0.95864665816, 0.188044386874],[-0.925507768893, -0.356055663867, 0.12907259177],[0.984927487605, -0.115452482809, -0.128796616312],[-0.544631965313, 0.402097557396, 0.735998353731],[-0.726094801829, -0.558136217897, -0.401584737047],[-0.863442218215, -0.484859258887, -0.139208602017],[-0.756824771876, -0.63207146651, 0.166438955471],[0.123530172061, -0.973015200799, 0.194888982766],[-0.290443568633, 0.083344737463, -0.953255573378],[0.244426306186, 0.349949844938, -0.904317912502],[0.269380289811, -0.960110419277, -0.0749816127885],[0.0417027354773, 0.0698417170955, -0.996686016962],[0.163194479243, 0.986361140652, 0.0214304026029],[0.428466198737, -0.565616272444, 0.704623976946],[0.668948489766, -0.0254788807131, -0.742871957121],[0.930772864949, 0.113653486142, 0.34748346574],[0.894090001592, -0.0776434541764, -0.441106067831],[-0.16643457582, -0.201693144564, -0.965204334536],[0.541049972373, 0.26569228093, -0.797917626857],[0.0598648521762, -0.760192351158, -0.646934145578],[0.66530751043, -0.365567197434, 0.650942809105],[-0.470019062022, -0.79207452662, -0.389486874767],[0.710427449163, 0.669756873738, 0.216144788408],[0.085621795832, 0.631250628344, -0.770838214085],[-0.150533899836, -0.417596137032, 0.896076453957],[-0.820697602393, -0.3943063514, 0.413494796428],[-0.571661932013, 0.505273575079, -0.646452821028],[0.154437954624, -0.916138875821, -0.369916853334],[0.832965404106, -0.412961160171, 0.368282114353],[-0.0552010327002, -0.993114463823, -0.103327187776],[-0.483629336311, 0.678952597572, 0.552382146081],[-0.159032687105, 0.788194508296, 0.594523356584],[-0.691134068898, -0.3120032512, -0.651910783812],[-0.40298832784, 0.751483365681, -0.522372624406],[-0.740057549746, 0.486729297916, 0.464122196857],[-0.945969230427, 0.0875826028395, -0.312204264488],[0.85646160202, 0.410063153761, 0.313562966872],[0.882744938148, 0.469816418645, -0.00582296707927],[-0.887025192651, -0.256091083733, -0.384192223289],[-0.207463869765, -0.0687074237116, 0.975826845639],[-0.397625428221, 0.175924213013, 0.900524674902],[0.943579559415, 0.203298428519, -0.261395034412],[0.684290840849, 0.719087060657, -0.121077844079],[-0.512848566772, -0.837330483429, 0.189377952995],[-0.46337327006, 0.885259023903, 0.0400209094207],[0.73485693389, -0.652189904459, 0.186101088754],[-0.985274836074, -0.141266253188, -0.0963189654755],[0.0693976090828, 0.957499499702, -0.279961925846],[-0.371228670386, -0.922407691237, -0.106551984641],[-0.0283138758308, -0.89075167794, 0.453607509508],[-0.718519857733, 0.585157484548, -0.375925434522],[0.49009289588, 0.867005859489, 0.0900543892289],[-0.525306172851, -0.107846607275, -0.844051262699],[-0.537054931863, 0.806521684421, -0.247173568006],[-0.899799377726, 0.395614754019, -0.183983820608],[-0.279137187087, 0.554357403793, 0.784072891793],[-0.381187635892, 0.358646643122, -0.852096574116],[0.270761889234, 0.911837828886, 0.30860941844],[-0.985537230598, 0.167558943982, 0.0253054815759],[-0.622489348674, 0.181445352511, -0.761304534887],[0.65565928155, 0.474087571313, -0.587666471091],[0.214680187293, -0.767591511735, 0.603916954801],[0.73903525642, -0.660618776589, -0.131945904772],[0.374293381668, -0.858913907486, 0.349530204656],[0.228283932374, 0.353310692703, 0.907225440914],[0.769029251581, 0.201661737296, 0.606569496367],[0.0606384448707, 0.0896416173998, 0.994126430306],[-0.0770505522428, 0.831989719241, -0.549414524267],[-0.383902087738, -0.393241230365, -0.835452285754],[0.229901154534, -0.531299074446, -0.815393618222],[0.528853810165, 0.290446080658, 0.797467693204],[-0.87349027792, 0.461581526422, 0.154781228983],[0.106364360934, -0.22340079395, 0.968905933507],[-0.104525945553, -0.697584271352, 0.708837436278],[0.811782987224, 0.490125534736, -0.317467072077],[0.250648041267, 0.814187172482, -0.52371252379],[0.663114133402, 0.501790340863, 0.55541524997],[-0.0389012891339, 0.943805297249, 0.328204586482],[0.90775121859, -0.418947248545, 0.021700877504],[0.739987454979, -0.302994907818, -0.600510326564],[0.804512725951, 0.202819888513, -0.558232358975],[-0.401593347162, -0.57294449392, 0.714463008421],[0.984793754549, 0.167221654875, 0.0470975492136],[-0.646755494636, 0.717308541735, 0.259182920179],[0.0450413893147, 0.595060485065, 0.802417779192],[0.386738111192, 0.896766424143, -0.21504328374],[-0.124142814718, 0.329147945149, 0.936082363768]],
[[0.332890177332, 0.796509208378, -0.504734792544],[-0.569050661166, -0.680528019306, -0.4615874348],[-0.731912417311, 0.394195441229, 0.555800474541],[-0.514258584863, 0.725346322424, -0.457614270364],[-0.532101534891, 0.644074095049, 0.549578489984],[-0.421651773542, -0.386955591268, 0.820045823266],[-0.603462834018, -0.700097108077, 0.381702301829],[-0.346030711579, -0.865833949345, 0.361378359625],[0.668409148895, -0.733356233251, 0.124168614492],[-0.928932014773, -0.213882163298, -0.302224638561],[0.864076726337, -0.469811466362, 0.180689227894],[0.0463590261691, -0.882033940443, -0.468899742588],[-0.0490974017236, -0.946538789049, 0.318831877281],[0.684170306883, 0.289059799105, -0.669593476463],[0.8945107479, 0.434784013599, 0.103987419485],[-0.43492787372, 0.527639979422, -0.729680612855],[-0.965409632173, 0.0201605988904, 0.259957289494],[0.880569280622, 0.133714714432, -0.454662641052],[0.545595155817, -0.625471877279, -0.557773122948],[0.461382869679, -0.886151399336, -0.0431456257635],[0.982741837736, -0.0242210017472, -0.183389812797],[-0.62795376586, -0.0488481843546, -0.776716114695],[-0.706508495912, -0.684551214751, -0.179542138751],[0.0576128785805, 0.608246988909, 0.791654190101],[-0.403882959586, -0.591097105017, -0.698199661556],[-0.114957166634, 0.990427291734, -0.0764109261063],[-0.427714970018, -0.273608639107, -0.861509266943],[-0.113284671362, -0.801110498282, 0.587697671236],[-0.560942195325, 0.255640750296, -0.787395491664],[0.754914061608, 0.227672734079, 0.615036491392],[-0.0572524711699, 0.0973290716193, -0.993604149731],[-0.407430738577, -0.669321898457, 0.621295734339],[-0.638996946681, -0.384778619069, -0.666054289408],[0.109348204615, -0.488787360334, -0.865522897747],[0.309524372519, 0.699388918811, 0.644243589849],[0.737505274792, -0.0423949232309, -0.674009376892],[-0.905331157064, 0.315130190622, 0.284725234232],[-0.0654741274948, 0.0227499805702, 0.997594896244],[0.237596203794, -0.708583353421, -0.664422813573],[-0.996202219881, -0.0771332619691, -0.0403930315938],[-0.53341661986, 0.794240935412, 0.290943372793],[0.689257109453, -0.588162159057, 0.423071993544],[-0.68957355259, 0.471510984938, -0.549696012948],[0.198282441271, -0.961244612529, -0.191553826293],[-0.0405598867767, 0.968342009076, 0.246310066874],[-0.205748060936, 0.4643803609, 0.861405024266],[-0.0812450676887, -0.709076417815, -0.700435487876],[-0.89702827016, -0.430547993754, -0.0998434154492],[0.371941128047, 0.904911614776, -0.206868960241],[0.0345554754012, 0.309062486809, 0.950413751146],[0.673546910176, -0.34413378716, -0.654145623182],[0.0928262743548, 0.947179730042, -0.306975311364],[0.182233163132, 0.982782887672, 0.0304773678817],[0.0336224523729, 0.811950645539, -0.582756964699],[0.201837627369, -0.85259066327, 0.482027730616],[-0.561686205044, -0.82261760049, 0.0883679264607],[-0.172546378265, -0.575089678358, 0.799687194591],[-0.639198892535, -0.449582738237, 0.623939209587],[0.402350902423, -0.466595453767, -0.787656291693],[-0.814390136557, -0.13932840356, -0.563343857196],[0.714156595571, 0.675986113734, 0.181722676187],[-0.316889759491, 0.192710770829, 0.928678329206],[-0.783645617295, -0.610195346869, 0.116452501706],[-0.941659087427, -0.288549712592, 0.173254802039],[0.783389615448, 0.445253288622, -0.433647575087],[-0.855302658366, -0.185816224961, 0.483662788658],[0.742907858849, 0.508380772473, 0.435473194858],[0.880209769414, -0.192139833048, -0.433950511445],[0.182181761537, -0.209695408907, -0.960644388547],[-0.756607362237, 0.581961323703, 0.298104540595],[0.909604122142, -0.022898622072, 0.414844542074],[0.313163010459, 0.425659377088, 0.848965855366],[0.601572083176, 0.703503278427, -0.37841005006],[-0.217551438262, 0.907578923012, -0.359126537887],[0.0779687751443, -0.436510937013, 0.896314159194],[0.899401988814, 0.264029058494, 0.348374394565],[0.634201500085, -0.380150271128, 0.673256436027],[-0.721547353607, 0.642561591729, -0.257844948248],[-0.253254686956, 0.693194809485, 0.67479109333],[0.940097783544, 0.286716878161, -0.184416889557],[0.014821718369, 0.82685749106, 0.562216156067],[-0.614453995015, 0.147114166185, 0.775115288275],[0.373281789871, -0.422287139879, 0.826035275786],[0.554387424702, 0.487380021883, 0.674622337016],[0.475738792905, -0.186369575993, -0.859615601341],[0.00160971349204, -0.999695767118, 0.0246126396135],[0.73221418156, -0.0775916304765, 0.676640178531],[-0.0962196199626, 0.583111551666, -0.80667385172],[-0.830372930378, 0.108890623803, 0.546464663581],[-0.41637518891, -0.0854090629305, 0.905172355979],[-0.784737810126, -0.465002073563, -0.40982879467],[0.0831290385401, 0.36739722413, -0.926341644672],[0.240357936967, 0.895891856867, 0.373638652894],[0.524596819578, 0.561970892282, -0.63952083087],[0.541527441787, 0.184141031394, 0.820268316071],[0.938032909533, -0.319127752074, -0.135098995146],[0.274898720623, 0.117993499193, 0.95420554785],[0.838529342277, -0.309745909499, 0.448247714651],[-0.149666170224, -0.958539508381, -0.242491336678],[0.259844732746, -0.949571916833, 0.17548187834],[0.444943111075, -0.65000193881, 0.616054467925],[-0.268298696534, 0.866076331897, 0.421814647406],[0.807104097963, 0.570324706993, -0.152684981726],[0.988866101354, 0.117246519747, 0.0916356218906],[-0.873566013369, 0.381220004206, -0.30257846698],[0.611687389277, 0.786967771254, -0.0807481566805],[-0.668239403314, -0.154988811622, 0.727622545095],[-0.285181554381, -0.821362867071, -0.493998503679],[0.38575860257, 0.373471073642, -0.843628862531],[0.476246278564, -0.810767808148, 0.340360167211],[0.246728070296, 0.0873741175991, -0.965137825858],[0.149624193753, -0.673831147846, 0.723577352352],[0.219020201149, 0.621240552742, -0.752389744161],[0.804832279661, -0.585316420606, -0.0982328325167],[0.187102748003, -0.168049112293, 0.967859523664],[-0.293503823927, -0.954020336861, 0.0608333970478],[0.614162968171, -0.743832738666, -0.263660208252],[-0.162328545259, -0.260432356479, 0.951748092245],[-0.973754875671, 0.226653883357, -0.0207233990128],[0.524679879311, 0.103928600276, -0.844931873165],[-0.124146318869, -0.193855718089, -0.973143181693],[-0.259897530465, 0.746647383302, -0.612348723087],[0.972189062406, -0.182869552415, 0.146311837309],[-0.450325819454, -0.866357595875, -0.215942521062],[-0.25807823546, 0.332006457051, -0.907285697484],[0.521583461371, 0.735618830032, 0.432221736759],[-0.490206902613, 0.425464703754, 0.760708208507],[-0.344313136823, 0.933268032778, 0.10227043955],[-0.801932991679, -0.462865098096, 0.377702763852],[-0.363559148026, 0.0335921790374, -0.930965257888],[0.781826383475, -0.484389675584, -0.392573748855],[0.446949444559, 0.881320469957, 0.153331090267],[-0.941898908688, 0.0905984446403, -0.323447627354],[-0.86142342515, 0.507854422447, 0.00579380738688],[-0.187891696434, -0.466151273152, -0.864522816905],[0.363428016096, -0.837822153615, -0.407399209656],[-0.658089098305, 0.752628115946, 0.0216715892149],[0.488941658932, -0.129635460684, 0.862630106995],[-0.792492903989, 0.180305045112, -0.582619161918],[-0.458822221987, 0.870089365494, -0.180074053281]],
[[-0.165481500224, -0.845146559722, 0.508274695094],[0.107483553382, 0.733192750435, -0.671472766731],[-0.630119635436, 0.669920251518, -0.392627178943],[-0.717556590077, 0.683940595178, 0.131673088761],[-0.0517621479745, -0.962387341412, 0.266704490265],[-0.464882991828, 0.86616366767, 0.183423839012],[-0.938352743411, -0.340397455979, -0.0601971834539],[-0.814069689402, 0.413601958899, -0.407705727692],[0.845182215951, -0.0485055213786, 0.532272708521],[0.55624127677, -0.668868856111, -0.493163355636],[-0.0633637380111, 0.0314963715602, -0.997493366035],[-0.796872615491, -0.600546476875, 0.0658632203387],[-0.0838686327971, 0.962138362526, -0.259337278052],[0.798856990802, 0.368815477001, -0.47518696549],[0.367120350772, -0.551431475565, -0.749096773325],[0.943760875573, 0.214656085044, -0.251472016121],[0.373801471558, -0.873822266778, -0.310977661488],[0.631316916331, -0.748998530506, -0.20109737058],[0.440962987847, -0.835960918871, 0.326681780132],[-0.175248349505, -0.938736100539, -0.296753347987],[-0.983812464925, -0.126473211657, 0.126954954968],[0.244009552594, -0.511976714386, 0.823613490765],[0.945399647816, -0.307440684889, 0.108165295652],[-0.620539314309, 0.466126822435, -0.630600305109],[-0.190981552466, -0.784398119427, -0.590123408159],[-0.336490734843, -0.91433895578, 0.225295937175],[0.140066536397, -0.977627424079, -0.15692668693],[0.0639121895085, -0.891953688263, -0.447586695542],[0.212002869755, -0.965746315765, 0.149628997195],[-0.60134269441, -0.0824747953605, -0.794723141735],[0.411077260322, 0.313917135448, -0.855845498976],[0.465846671971, 0.842801584971, -0.269578127051],[-0.320292387254, 0.945583945268, -0.0573043551535],[0.761943282944, 0.211048319366, 0.612291630246],[0.773397170154, -0.514866092633, -0.369823909253],[0.626625313303, -0.420329424952, -0.656249869522],[0.527338655243, 0.674853318486, 0.516223731744],[-0.34196758658, -0.0243990605035, -0.939394941212],[-0.800328725234, -0.371769865606, -0.470383990578],[-0.87559407906, 0.206826596747, 0.436529228797],[0.854049516709, -0.324216724576, 0.406795942106],[0.49304315144, 0.238629821192, 0.836638667081],[-0.811832050785, -0.53604323118, -0.231487312016],[-0.457876384443, -0.761414592308, 0.45890852595],[-0.109785196922, -0.262140710854, -0.958764547869],[0.351613133618, 0.5291338813, 0.77226002093],[-0.908697368331, 0.129469410135, -0.396871219198],[-0.505584499107, 0.205745681858, -0.837886047539],[0.352835681165, -0.718841563964, 0.598977285057],[-0.0947142394741, 0.362166123455, 0.927289012046],[0.205462328285, 0.310090533025, 0.928239782052],[0.17615892309, 0.182830933138, -0.967233624159],[0.443246592292, 0.0186281623961, -0.896206142574],[0.58335854175, 0.493127954213, -0.645381772706],[0.41401402872, 0.731360878968, -0.541944322545],[-0.398311569436, -0.913799301527, -0.0794904408187],[-0.379778486592, 0.85932101712, -0.342542976366],[0.967278095092, 0.248439138356, 0.0514886520312],[0.667216701928, -0.113910739651, -0.73610204188],[0.0466175987929, -0.715005097775, 0.697563265689],[-0.118993814916, -0.198901804714, 0.972768494603],[-0.379337749967, 0.463614400093, -0.80072751887],[0.607972128058, 0.441226282202, 0.660067617293],[0.431908843845, -0.901749300319, -0.0174054584055],[-0.63028642158, -0.758749343767, -0.164433755978],[-0.617994839377, -0.372472416915, -0.692348667321],[0.0587998536419, -0.685445339236, -0.725746005246],[-0.583890858412, 0.803654470595, -0.114938928806],[-0.424124513844, -0.814735265579, -0.39537936691],[0.835271307064, 0.0740698174256, -0.544826124321],[0.851069653923, 0.510602129189, 0.122335235478],[0.516098177747, -0.501716514472, 0.694206892816],[-0.703797542644, -0.60403811075, 0.373907715524],[-0.554986066682, 0.0932858746048, 0.826612491672],[-0.887068727707, -0.38520825723, 0.254408472512],[-0.247522655718, 0.114310815498, 0.962115155461],[0.822439769929, -0.251283140213, -0.51034263812],[-0.406456153668, 0.351416685791, 0.843385859553],[0.389892277589, 0.856112461136, 0.339198269105],[-0.526423194263, 0.552467997708, 0.646264444366],[0.475955394706, 0.878955583051, 0.0300590298186],[-0.99257421879, 0.0333855354398, -0.116969338786],[0.172874001092, 0.886542529026, -0.429135088258],[-0.687330244218, 0.30280620724, 0.660216279897],[-0.0589337827282, 0.996921234569, 0.0517190614571],[-0.88457944026, 0.443497923505, 0.144321882322],[0.926370410975, -0.324558649851, -0.191048539585],[0.653519371238, 0.721026870838, 0.230288260549],[-0.171225949937, -0.535821564676, -0.826787109779],[-0.0619746088373, 0.788236824187, 0.612243298743],[-0.394665213447, -0.132160904257, 0.909270512378],[-0.935373804446, -0.176422965955, -0.306513919813],[0.338924165297, 0.0112189278289, 0.940746802193],[0.653632608511, 0.203416578316, -0.728962350713],[-0.937519100585, 0.321131313222, -0.133912716746],[-0.244111988877, 0.594444571647, 0.766188611326],[0.13167492992, -0.432386844933, -0.892022045221],[0.167593241587, -0.246633019163, 0.954507548023],[0.804071087549, -0.545585408105, 0.23623346213],[-0.805689560975, -0.0958230756921, -0.584535943721],[-0.798556049917, 0.583918522841, -0.14610747354],[0.702246129065, -0.295495652344, 0.647713434829],[-0.194435629725, 0.284530917613, -0.938742213185],[-0.0533523692114, -0.482304393064, 0.874377491208],[0.964056406464, -0.0412598607545, 0.262474511231],[-0.348437339508, -0.412400148607, 0.841734838216],[-0.97204914561, 0.168660809167, 0.163321737594],[-0.553645565483, -0.533240476989, 0.639633630699],[-0.417917989585, -0.606230680055, -0.676630561342],[0.640560923273, -0.757334503536, 0.12698879214],[-0.141931626303, 0.620527564536, -0.771233398594],[-0.628828167731, -0.62161305648, -0.467089224327],[-0.338697918444, 0.782376161415, 0.522657882453],[0.453549260051, -0.255953709927, 0.853686574266],[-0.612284300363, -0.246281364986, 0.751301154524],[-0.777810928907, -0.338522034549, 0.529540358233],[-0.40102320225, 0.693726013813, -0.598268007682],[0.670297683075, 0.636722087307, -0.381164006169],[0.211699629511, 0.967684216488, 0.13700556202],[0.291551455352, -0.767261166526, -0.57123379734],[-0.910504430282, -0.0930058959974, 0.40290394109],[-0.770270066327, 0.48149546338, 0.418146079338],[-0.267970879885, -0.657261306981, 0.704414069904],[0.638020603419, -0.619348978467, 0.457533116271],[-0.205028726527, 0.930785637368, 0.302657097337],[-0.388768159708, -0.321863967482, -0.863286108097],[0.156578923345, -0.876448803752, 0.455324648099],[-0.136632159799, 0.837066941256, -0.529764654129],[-0.112344881378, -0.993606675004, -0.0111536099824],[0.063776469701, 0.585919433858, 0.807855790931],[0.908066009586, 0.239407810405, 0.34365683836],[0.82008990811, -0.56906044445, -0.0601893111625],[0.243513852105, 0.759530355908, 0.60317049189],[-0.590816883591, -0.792188921577, 0.152879438102],[0.208233301431, 0.966133991283, -0.152394235661],[0.631277717021, -0.0212049283711, 0.775266918555],[0.857454283725, 0.481902271912, -0.180394987869],[0.0580233361044, 0.442371868216, -0.894952748853],[0.99890687332, -0.0357298812222, -0.0301402392399],[0.69731403972, 0.712216542156, -0.0806270865637],[0.429750602186, -0.282534012502, -0.857606524987],[0.0462380430323, 0.0603985432422, 0.997102832887],[0.768502326707, 0.491697778059, 0.409435549138],[0.187417172156, -0.140199284881, -0.972223721219],[-0.765693278528, -0.0100387130013, 0.64312753592],[0.304992280898, 0.55915190783, -0.770927268011],[-0.737870702106, 0.191913655908, -0.647082665237],[-0.587538581107, 0.705352417267, 0.396580865861],[0.946112219197, -0.0668525771738, -0.316863380041],[0.075770813558, 0.917991151923, 0.389295554565]],
[[0.507305217596, -0.00207270485102, 0.861763958457],[-0.311672136845, -0.537930605092, 0.78325675434],[0.499628302728, -0.717887569385, 0.484777265181],[-0.596384068657, 0.114350548601, -0.79451242576],[-0.899872070056, -0.104741647962, -0.423390416419],[0.952222643132, -0.3026901351, -0.0406290538949],[-0.19661922921, 0.353013568093, 0.914725258997],[0.217687467637, -0.522706991766, 0.824250912764],[-0.257167408156, 0.947870574949, -0.188165611437],[-0.283979817049, 0.59683379255, -0.7504298019],[-0.284076959408, 0.0674489751607, 0.956426116793],[0.66236704199, -0.6888511351, -0.29454034589],[-0.807679905974, 0.284314156723, 0.516544896183],[0.00644542063565, -0.865906221755, 0.500164844505],[-0.337995268347, 0.818539049499, -0.464492220623],[-0.655236733988, -0.680907508044, 0.327154073674],[-0.203087902751, -0.137408326751, -0.969471121538],[-0.149480531788, 0.372202237118, -0.916035515305],[0.234217415498, 0.91375046179, -0.331967311427],[-0.52660395895, -0.0684277888511, 0.84735229281],[-0.480468836534, -0.152207609545, -0.863702808098],[-0.07740153835, -0.423204890862, 0.902721785608],[0.862834692634, 0.452934932612, -0.22442424113],[0.246281504917, -0.736438691565, 0.630082116792],[0.198876129203, 0.87047199422, 0.450251921164],[-0.0670624260727, -0.107217006976, 0.991971342542],[0.712104442917, 0.683507682859, -0.160388621327],[0.943903202791, 0.329646278657, 0.0194955053582],[0.443082755329, -0.745705977985, -0.4975944798],[0.33329734734, -0.942286003931, 0.0317799473248],[-0.973006406679, 0.23001668794, -0.0187311460013],[0.8383244615, 0.440044067344, 0.321828084612],[0.110722345957, -0.158626578317, -0.981110682215],[-0.184241907364, 0.97833753302, 0.0943959271069],[-0.803665675298, 0.123649635191, -0.582092990909],[0.0207948235041, 0.181581148913, 0.98315607188],[0.168579131335, 0.786084437097, -0.594686753033],[0.405306626058, 0.876162024501, 0.260895852203],[0.95191950757, 0.177127474275, -0.249950212972],[0.668049101983, -0.524178249492, -0.528154863747],[-0.938732372425, 0.164514232502, -0.302847486809],[0.953375032815, 0.174613024103, 0.246142923152],[-0.694194562231, 0.114356686042, 0.71064509998],[-0.545444696916, 0.67381978232, 0.498454595285],[-0.472766004536, 0.255033712677, 0.843475020586],[-0.853631003117, 0.509123552631, 0.110033261665],[0.325467781615, 0.944931194759, -0.0342893613656],[-0.0191715530647, 0.794487297638, 0.606978076577],[0.340431946934, 0.254041129901, 0.905300609646],[-0.388373640497, 0.867215791591, 0.311613039171],[0.0388442526318, 0.993476759286, -0.107214984005],[0.658952116899, -0.282922872659, 0.696948172937],[0.426371973163, 0.49652897972, 0.756085916281],[-0.425182664239, -0.821818965265, 0.379253596372],[-0.10429238206, 0.925070378507, 0.365195692545],[-0.464937395316, 0.884895027615, 0.0281781571239],[-0.571706045422, -0.40782621356, -0.711919923279],[0.309449532305, 0.570170638308, -0.761016708206],[-0.871297644503, 0.460245026476, -0.170337694851],[0.126615819795, 0.44086394796, 0.888598567165],[0.840584954404, -0.268227142225, 0.470607197781],[-0.642372254603, 0.73587975489, 0.214100146799],[-0.292373862505, 0.762899926393, 0.576629193532],[-0.886239471752, 0.0203812101916, 0.462778786225],[-0.0477093738019, 0.921683114166, -0.384998769756],[0.170554692733, -0.887816564603, -0.427425834974],[-0.769676828828, -0.560064928151, -0.306471622535],[0.199501592379, -0.480776481126, -0.853846057457],[-0.343891397166, -0.643872161712, -0.683496412812],[0.877624546301, -0.424749638391, 0.222177632575],[0.602309172493, 0.263907807897, 0.753376618738],[0.571279649499, 0.483305251088, -0.663366864065],[0.187457063377, -0.722167746506, -0.665833008566],[-0.984054972136, -0.0126445477691, 0.177414563175],[0.818858595674, -0.266252484641, -0.508507831516],[0.505055298822, -0.00145041726804, -0.86308576713],[-0.114539177962, -0.94258147288, -0.313721124081],[-0.780475646619, -0.362542710778, -0.50933343489],[0.596747724143, -0.319667896685, -0.736005835275],[0.256936893967, 0.0818152153559, -0.962958827289],[-0.374446293192, 0.540732540698, 0.753258450298],[-0.250227368913, -0.766326687668, 0.591717560678],[0.261559001257, -0.890385841442, 0.372558642661],[0.429130506267, 0.301177670049, -0.851550949536],[0.120467499262, -0.981376780854, -0.149623512933],[0.951408653199, -0.137165844886, -0.275693862126],[-0.0525245888226, -0.378455066954, -0.924128199908],[0.120814467554, 0.976481823814, 0.178569628412],[-0.716984562596, -0.139420431067, -0.68300445123],[-0.813995019953, 0.381872564465, -0.437704754373],[0.727962842768, -0.00684991317952, 0.6855823643],[-0.648645631524, 0.384455140112, -0.65685088867],[-0.070775985587, -0.621861678577, -0.779922311888],[-0.517163583584, -0.618499403371, 0.591608245247],[0.492746563313, 0.831689154481, -0.2559179061],[-0.332805177666, 0.1170197147, -0.935706738295],[0.650820892623, 0.512236357546, 0.560398143942],[0.238086181877, -0.00646049304675, 0.971222545058],[-0.14326167755, -0.989669104274, -0.00558173735539],[0.966603380859, -0.143628724295, 0.212246775402],[0.434947134646, 0.730538836516, -0.526435179679],[-0.0939082575274, 0.598092858691, 0.795905881088],[-0.690648922877, 0.625182444495, -0.363525757579],[0.211090187198, 0.669670842091, 0.712026611948],[-0.517042182218, 0.818155048188, -0.251574440141],[-0.584360884029, -0.625837872345, -0.516574597474],[0.426088527535, -0.276276288289, 0.861463858343],[-0.315117180449, -0.252345647084, 0.914889521737],[0.36784148526, -0.252255975042, -0.895019309723],[0.650192155417, 0.689543982132, 0.319028615863],[0.022319690912, 0.592744657922, -0.805081115107],[0.999677828463, 0.0174668779692, -0.0184159564963],[-0.429345765978, 0.367702823913, -0.824898082507],[0.40854797681, -0.879200150635, -0.245144132641],[-0.0930591487251, -0.815664423549, -0.570991718849],[0.673334716061, 0.211071546193, -0.708568389455],[0.158760926136, -0.273960251701, 0.94854665084],[-0.598012899705, -0.7669029465, -0.232895775908],[0.814296338985, -0.579309567005, -0.0363579137489],[-0.928176456503, 0.266047090302, 0.260206478274],[0.60729690532, -0.793622562236, -0.0367926283337],[0.890476216236, 0.00380048654598, 0.455013916952],[0.674492510998, 0.602232830944, -0.427054410983],[-0.761697702459, 0.525597257261, 0.37889857908],[-0.514394751886, 0.627372000625, -0.584638702161],[-0.026290297371, -0.669160150595, 0.74265302337],[0.481686467162, -0.525013146278, 0.70166897009],[0.0828885940664, -0.981214845112, 0.174203641481],[-0.11154565834, 0.774799141145, -0.622289206869],[-0.832958410065, -0.552195606281, -0.0355006972506],[0.703992165581, -0.514337859913, 0.489746461611],[0.869326882001, 0.0510817634627, -0.491590709505],[0.433216851765, -0.550809221201, -0.713394954557],[-0.732316634991, -0.439175182991, 0.520420507629],[0.148347118838, 0.3550466208, -0.923003266187],[-0.919485651712, -0.321369609691, -0.226423740502],[0.80070243621, 0.260631753059, 0.539394751499],[0.84906970252, -0.44357977052, -0.28691048682],[-0.323936136502, -0.408196374712, -0.853487609248],[-0.710760129923, 0.700264233186, -0.0667086308718],[0.499039056716, -0.836283480364, 0.227134234192],[0.715602080302, -0.658233445424, 0.233757126079],[0.804389620511, 0.339922552232, -0.487247367256],[0.443262924339, 0.721863525904, 0.531442405042],[0.717192799387, -0.071939186291, -0.693151673145],[-0.0360429088676, 0.111763926336, -0.99308092998],[-0.991106979442, -0.0556080589615, -0.12089126966],[-0.746767424293, -0.170002102108, 0.642991212454],[-0.65313725144, -0.755629138511, 0.0493592525752],[-0.897785620534, -0.242858246764, 0.367424620216],[-0.835638788372, -0.494351681106, 0.239424791442],[0.581222855745, 0.812006129866, 0.0531604836367],[-0.549033130415, -0.358745682781, 0.754893473805],[-0.418936161456, -0.901608567706, 0.107677682291],[-0.955805437327, -0.286185050507, 0.0673355986339],[0.807201355696, 0.584249927239, 0.0841308141148],[-0.17733532696, -0.93893355396, 0.294882965021],[-0.367149873022, -0.816387887848, -0.445771003223],[-0.616466735228, 0.433230720678, 0.657479967008],[-0.370657813502, -0.913112282162, -0.169819744011]],
[[-0.560015719719, 0.82314034492, 0.0939274519581],[-0.138954920953, 0.685069784667, -0.715102034733],[-0.67748608127, -0.735392933108, -0.0144859801384],[0.20352777153, -0.22903104943, -0.951903999683],[0.960152475843, 0.226850894848, 0.163235702712],[0.757252743569, -0.326271885458, 0.565787008615],[0.593043964544, -0.52255492146, -0.612564453894],[0.542103226927, 0.394189964498, 0.742117486147],[0.0466401329216, -0.963569977374, -0.263358304796],[0.562438312353, -0.79443514931, -0.229207195215],[-0.194807549398, 0.953481751349, -0.230049056817],[0.855336479028, -0.0610362404394, 0.514464853024],[0.823788527365, 0.19040435895, -0.53396501971],[0.715183671615, -0.563490193989, 0.413510721909],[-0.611659172044, 0.259727668047, 0.747271433755],[0.96658312288, -0.0465507816426, 0.252091434388],[-0.646266494118, 0.52473785396, 0.554066605384],[-0.05624029713, 0.472741878432, -0.879404426505],[-0.405634715304, -0.280720486943, 0.869860038138],[0.067828897335, 0.949345798935, -0.306825348904],[-0.0151794262252, -0.718836489057, 0.695013443769],[0.55887959937, 0.704399788993, -0.437578028098],[0.880453810296, 0.473533410897, -0.023815891754],[0.20053592265, -0.838968175922, -0.505883132271],[-0.74268498987, 0.0183594106278, 0.669389227478],[-0.333361971647, 0.460060410346, -0.822930261135],[0.8830794858, 0.206665601674, 0.421259956374],[0.501290027525, 0.141648515226, 0.853606470476],[-0.831043854823, 0.504999429969, -0.233113035012],[-0.538500335184, -0.816144691139, 0.209583472949],[0.318451059949, -0.912976772535, -0.255073195825],[-0.408293836419, -0.912614138316, -0.0207744479368],[0.257139206534, 0.0407355537116, -0.965515428736],[0.316082616906, 0.555975410286, 0.76875426662],[0.15005706223, 0.617580722917, -0.772060184673],[0.738817941694, 0.441359868179, 0.50926369966],[0.329605672158, 0.873526568832, -0.358205854817],[-0.445551276669, 0.883321945643, -0.145692828249],[-0.653151799495, -0.256352999931, 0.712513765651],[0.808318952318, -0.372452996283, -0.455959687783],[-0.941605723084, 0.242935421494, -0.23315454797],[0.464714602158, 0.176674999879, -0.867655624634],[0.00826566530175, 0.999718447915, -0.0222419350454],[0.617347357826, -0.753653768162, 0.225584213811],[0.417298496172, -0.393749774103, -0.819037899298],[-0.894205316077, 0.0603042847086, 0.443576651714],[0.0687691807359, 0.82527968976, -0.560521394284],[-0.563809414495, -0.670631414497, 0.482050256733],[-0.36762578009, -0.305201473968, -0.87846647409],[-0.969193672413, -0.0879790483391, 0.230050673566],[0.0531795049318, -0.968444359097, 0.243490171439],[-0.892061523568, -0.369616793141, 0.260018584717],[-0.501913144515, -0.500294864243, 0.705541100273],[0.71197122182, -0.605582550449, -0.355481017626],[-0.0136894418171, -0.0332674782098, 0.999352727557],[-0.935895072025, 0.246582515973, 0.251589898397],[0.333027874831, -0.439291815529, 0.834335145727],[-0.373698844093, -0.798183751422, -0.472495368114],[0.471828591264, -0.881541664485, 0.0161887072874],[0.185382705609, -0.850315521947, 0.492541130869],[0.749839305915, 0.617687304229, -0.237072582767],[0.682145560711, 0.0204808827775, -0.730929522898],[-0.450707235721, 0.485909949742, 0.748835434799],[0.953430214768, -0.297513327901, 0.0495645567823],[-0.60995954499, -0.336981483832, -0.717211846688],[-0.0937876006945, -0.995317603427, -0.0233827770703],[-0.0911491102962, -0.876645685611, 0.472423730979],[-0.751816473452, -0.106494427753, -0.650715703748],[-0.4549594223, 0.795640607288, -0.399959933112],[-0.857480776763, -0.514396359037, 0.0110951922111],[-0.235776339665, -0.950567536096, 0.202066516215],[0.327768954484, -0.632400667798, -0.701880978404],[0.875356152693, 0.366663697803, -0.315133842447],[0.337049055402, -0.90613875985, 0.255559155872],[-0.298409557421, -0.704873328855, 0.643510160222],[0.728403486745, 0.193083045617, 0.657379112835],[-0.275802407315, 0.959391135597, 0.0591750036553],[-0.357225545302, -0.837565090162, 0.413369845933],[-0.75992608204, -0.417385957325, -0.498298417078],[-0.845211043614, -0.206822187997, 0.492790903228],[-0.794187459558, 0.299835109236, 0.528550079321],[-0.91836632668, 0.39540996822, 0.0159451262952],[0.299140406411, 0.753840414346, 0.585012518628],[-0.0831037725402, -0.868328563505, -0.488977779446],[-0.878492592942, 0.096634163634, -0.467880970509],[-0.409818081801, 0.65572715306, -0.634090719511],[0.10020611243, 0.266555403267, -0.958596344673],[-0.374277447633, 0.873086242405, 0.312468887279],[0.270016527641, -0.671377902957, 0.690175909621],[0.541041870394, 0.62429244541, 0.563500343465],[-0.205684701538, 0.427193830631, 0.880453993474],[0.484401214452, 0.537004253708, -0.690638758641],[-0.750005244381, -0.606665028126, -0.263533066332],[0.41634788225, 0.836899660947, 0.355321542343],[0.166296242179, -0.246815728562, 0.954687150836],[-0.296094613482, -0.0384767069717, -0.95438332073],[-0.994747525797, 0.100281086322, 0.020519835429],[-0.772171546958, 0.632703010952, 0.0586344779276],[0.998826679702, -0.0392359958405, -0.0283866261801],[-0.21613280511, 0.656187847965, 0.722982792837],[-0.252704208103, -0.933568656957, -0.254145914693],[0.635024851795, 0.30724197684, -0.708763575017],[-0.219513065221, -0.705195308771, -0.674176231177],[-0.4680727559, 0.206194583991, -0.859297206278],[0.535999032333, -0.55860635845, 0.632980231632],[0.941871488712, -0.224283885278, -0.250149630334],[-0.899743865922, -0.370842303796, -0.23008033695],[0.42137066148, -0.13336357588, 0.897028941714],[-0.0179670912137, 0.00151378796736, -0.999837432826],[-0.125248848553, -0.290295681422, 0.948704982217],[0.0592320138022, -0.50687769351, 0.859980565108],[-0.433377950719, -0.543920038093, -0.718564223986],[-0.54669777658, -0.0674618313622, -0.834607957302],[0.310739519758, 0.407074205898, -0.858913000107],[-0.533165463634, -0.0183273658216, 0.845812447325],[0.664184823046, -0.267430006357, -0.698097208514],[0.969287869916, 0.222316321333, -0.105149790785],[0.0538554894689, 0.504860525452, 0.861519260431],[0.656977717791, 0.685160897107, 0.314539064985],[0.568204992065, -0.318041636507, 0.758941766172],[-0.666768645252, 0.720826026321, -0.189286590878],[0.548442660631, 0.818241867152, -0.172310460621],[0.214928007806, 0.959594327129, 0.18161684614],[0.946424608437, 0.0503468442259, -0.318975948656],[-0.885108549415, -0.182543876236, -0.428089463782],[0.721167923061, -0.69185345858, -0.0354347089571],[-0.627875906664, 0.70426054107, 0.331344135488],[0.476067732475, -0.123801054122, -0.870650798595],[0.718710132759, 0.693898996437, 0.0442710719688],[0.84211350825, 0.476477421409, 0.252614540578],[-0.228043974802, -0.516793528513, 0.825179007515],[-0.36827563394, 0.218665545267, 0.903636230327],[-0.653162124952, 0.601664697776, -0.459759534951],[-0.0313417786604, 0.234624378506, 0.9715807192],[-0.0821342567919, 0.963735524752, 0.253905104699],[0.0542404898191, -0.701856539293, -0.710250214724],[-0.743567464403, -0.61716795066, 0.25731526686],[0.269175195264, 0.320670289401, 0.908138359365],[0.198159868213, -0.980168455566, -0.00157014128642],[-0.198276970651, 0.849772386653, -0.488439488362],[-0.97665617853, -0.0482565650901, -0.209317970718],[0.8648633327, -0.477816963686, -0.153955724038],[-0.815730322345, 0.492856048651, 0.30278202806],[-0.197490226725, 0.23012187546, -0.952912132772],[0.842842885998, -0.106541453168, -0.527508093094],[0.462133332653, -0.757109949056, 0.461754597044],[0.325085458316, 0.733685468409, -0.596678370847],[-0.538464820606, -0.804560940627, -0.250474209823],[0.714102431563, 0.483600816633, -0.506150143128],[0.674700666091, -0.0649681130774, 0.735226601436],[-0.971762607679, -0.235944854558, 0.00273128623838],[-0.15480101505, -0.504312295134, -0.849532668422],[-0.0844142140247, -0.263441444528, -0.960974945446],[-0.275415859096, -0.0285740707063, 0.960900425144],[0.493599158612, 0.864214956028, 0.0974288478568],[0.831354826285, -0.532811198071, 0.157991708712],[-0.58753059159, 0.42836275299, -0.686522509315],[-0.699894191464, 0.168464423901, -0.694094992515],[-0.796929859438, 0.361229049388, -0.484165646256],[0.131193331915, -0.479347650747, -0.867763873058],[0.237320095747, 0.0620563895122, 0.96944735632],[0.0453202875893, 0.726530443528, 0.685638086864],[0.287523325033, 0.953318550351, -0.0922717677264],[-0.165267815776, 0.845266280149, 0.508145121705],[0.89226322398, -0.309750500088, 0.328513267356],[-0.589563766037, -0.630214132551, -0.5052174907],[-0.731791469876, -0.45554006704, 0.506916651864],[0.465081177326, -0.742253993658, -0.482450523261],[-0.431565079135, 0.716917979994, 0.547521864799],[0.113137017866, 0.891893422461, 0.437865433849]]
);

#===================================================================================================
# Perl modules must return 1.
    1;
    
    
    
    
    
