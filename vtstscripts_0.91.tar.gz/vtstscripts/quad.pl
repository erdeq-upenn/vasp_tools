#!/usr/bin/env perl
#Version 0.91
$Options::versionString='Version 0.91';
#;-*- Perl -*-

@args=@ARGV;
(@args==1||@args==2) || die "usage: quad.pl <inputfile> <outputfile>\n";
$inputfile=@args[0];
if(@args==2){$outputfile=@args[1];}
else{$outputfile="ciPOSCAR";}

open (IN,"<$inputfile");
@poscar=<IN>;
close(IN);
open (OUT,">$outputfile");

for($index=0; $index<5; $index++){$out=$poscar[$index]; print OUT "$out";}

$line = $poscar[5] ;
$line=~s/^\s+//;
@line=split(/\s+/,$line);
#  if ($line=~/^s/i) {
if ($line[0]=~ /^\d+$/) {
  $index = 5;
} else {
  $atomtypeflag= 1;
  $out=$poscar[$index]; print OUT "$out";
  $index = 6;
}


$natoms=$poscar[$index];
$natoms=~s/^\s+//g;
@natoms=split(/\s+/,$natoms);
$totatoms=0;
for($i=0; $i<@natoms; $i++){
  $totatoms+=$natoms[$i];
  @natoms[$i]*=4;}
$natoms=join("  ",@natoms);
print OUT "$natoms\n";
$index+=1;

for($line=$index; $line<$index+2; $line++){$out=$poscar[$line]; print OUT "$out";}
$index=$line;

for($i=$index; $i<$index+$totatoms; $i++){
  $_=$poscar[$i];
  $_=~s/^\s+//g;

  @out=split(/\s+/,$_);
  $out=join("  ",@out);
  print OUT "$out\n";
	
  @out=split(/\s+/,$_); 
  @out[0]-=1;
  $out=join("  ",@out);
  print OUT "$out\n";

  @out=split(/\s+/,$_); 
  @out[1]-=1;
  $out=join("  ",@out);
  print OUT "$out\n";

  @out=split(/\s+/,$_); 
  @out[0]-=1; @out[1]-=1;
  $out=join("  ",@out);
  print OUT "$out\n";
}

